<!DOCTYPE html>
<html lang="fr">
<body>

<form method="get" action="controleurFrontal.php">
    <fieldset>
        <legend>Mon formulaire :</legend>
        <p>
            <label for="login_id">Login</label> :
            <input type="text" name="login" id="login_id" value="<?php echo $login ?>" readonly required/>

            <label for="nom_id">Nom</label> :
            <input type="text" name="nom" id="nom_id" value="<?php echo $nom ?>" />

            <label for="prenom_id">Prenom</label> :
            <input type="text" name="prenom" id="prenom_id" value="<?php echo $prenom ?>" />

        </p>

        <p>
            <input type='hidden' name='action' value='mettreAjour'>
            <input type="submit" value="Mettre à jour" />
        </p>
    </fieldset>
</form>

</body>
</html>