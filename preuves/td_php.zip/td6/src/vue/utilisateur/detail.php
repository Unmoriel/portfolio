<!DOCTYPE html>
<html lang="fr">
<body>
<h1>Détails de l'utilisateur </h1>

<?php
// Vérifiez si la variable $voiture existe et n'est pas vide
if (isset($utilisateur)) {
    echo "<p>Nom : " . htmlspecialchars($utilisateur->getNom()) . "</p>";
    echo "<p>Prenom : " . htmlspecialchars($utilisateur->getPrenom()) . "</p>";
    echo "<p>Login : " . htmlspecialchars($utilisateur->getLogin()) . "</p>";
} else {
    echo "<p>Utilisateur inconnue.</p>";
}
?>
</body>
</html>
<?php
