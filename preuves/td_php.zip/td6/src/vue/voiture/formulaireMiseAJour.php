<!DOCTYPE html>
<html lang="fr">
<body>

<form method="get" action="controleurFrontal.php">
    <fieldset>
        <legend>Mon formulaire :</legend>
        <p>
            <label for="immat_id">Immatriculation</label> :
            <input type="text" name="immatriculation" id="immat_id" value="<?php echo $immatriculation ?>" readonly required/>

            <label for="marque_id">Marque</label> :
            <input type="text" name="marque" id="marque_id" value="<?php echo $marque ?>" />

            <label for="couleur_id">Couleur</label> :
            <input type="text" name="couleur" id="couleur_id" value="<?php echo $couleur ?>" />

            <label for="nbSieges_id">Nombre de sièges</label> :
            <input type="number" name="nbSiege" id="nbSieges_id" min=0 value="<?php echo $nbSiege ?>"/>
        </p>

        <p>
            <input type='hidden' name='action' value='mettreAjour'>
            <input type="submit" value="Mettre à jour" />
        </p>
    </fieldset>
</form>

</body>
</html>