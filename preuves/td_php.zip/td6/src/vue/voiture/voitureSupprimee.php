<!doctype html>
<html lang="fr">
<body>
<p>
    <?php
    /** @var string $immatriculation */
        echo "La voiture d’immatriculation $immatriculation a bien été supprimée!"
     ?>
</p>

<?php
    require __DIR__ . '/liste.php';
?>
</body>
</html>


