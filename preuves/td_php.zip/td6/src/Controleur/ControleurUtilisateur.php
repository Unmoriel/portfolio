<?php

namespace App\Covoiturage\Controleur;

use App\Covoiturage\Modele\DataObject\Utilisateur;
use App\Covoiturage\Modele\Repository\UtilisateurRepository;
use App\Covoiturage\Modele\Repository\VoitureRepository;

class ControleurUtilisateur
{
    public static function afficherListe(): void
    {
        $utilisateurs = (new UtilisateurRepository())->recuperer();
        $pagetitle = 'Liste des utilisateurs';
        ControleurUtilisateur::afficherVue('utilisateur/liste.php', ['utilisateurs' => $utilisateurs, 'pagetitle' => $pagetitle]);
    }

    private static function afficherVue(string $cheminVue, array $parametres = []): void
    {
        $parametres["cheminVueBody"] = $cheminVue;
        extract($parametres); // Crée des variables à partir du tableau $parametres
        require __DIR__ .  "/../vue/vueGenerale.php"; // Charge la vue générale
    }
    public static function afficherDetail(): void
    {
        $login = $_GET["login"];
        $utilisateur = (new UtilisateurRepository())->recupererParClePrimaire($login);
        if ($utilisateur === null) {
            // Redirige vers la vue d'erreur
            echo "WIP";
        } else {
            ControleurUtilisateur::afficherVue('utilisateur/detail.php', ['utilisateur' => $utilisateur]);
        }
    }

    public static function supprimer(): void{
        if(!isset($_GET["login"])){
            ControleurUtilisateur::afficherErreur("Login non rentré");
        } elseif (!in_array((new UtilisateurRepository())->recupererParClePrimaire(($_GET["login"])), (new UtilisateurRepository())->recuperer())){
            ControleurUtilisateur::afficherErreur("Login inconnus");
        } else{
            $login = $_GET['login'];
            (new UtilisateurRepository())->supprimerParCleePrimaire($login);
            ControleurUtilisateur::afficherVue("utilisateur/utilisateurSupprime.php", ['login' => $login, 'pagetitle' => 'Utilisateur supprimer', 'utilisateurs' => (new UtilisateurRepository())->recuperer()]);
        }
    }

    public static function afficherFormulaireCreation(): void
    {
        ControleurUtilisateur::afficherVue('utilisateur/formulaireCreation.php', ["pagetitle" => "Création de voiture"]);
    }

    public static function creerDepuisFormulaire(): void
    {
        $login = $_GET['login'];
        $nom = $_GET['nom'];
        $prenom = $_GET['nom'];
        $utilisateur = new Utilisateur($login, $nom, $prenom);
        (new UtilisateurRepository())->
        ControleurUtilisateur::afficherVue("utilisateur/voitureCreee.php", ['voitures' => (new VoitureRepository())->recuperer(), 'pagetitle' => 'Liste des voitures']);
    }

    public static function afficherErreur(String $messageErreur = ""): void    {
        if ($messageErreur == ""){
            $messageErreur = "Problème avec la voiture";
        }
        ControleurUtilisateur::afficherVue("utilisateur/erreur.php", ["messageErreur"=>$messageErreur, "pagetitle" => "Erreur"]);
    }

    public static function formulaireMiseAJour(): void
    {
        if (!isset($_GET["login"])) {
            ControleurVoiture::afficherErreur("login non rentré");

        } elseif (!in_array((new UtilisateurRepository())->recupererParClePrimaire($_GET["login"]), (new UtilisateurRepository())->recuperer())){
            ControleurVoiture::afficherErreur("login non valide");
        } else{
            $utilisateur = (new UtilisateurRepository())->recupererParClePrimaire($_GET["login"]);
            $login = $utilisateur->getLogin();
            $nom =  $utilisateur->getNom();
            $prenom = $utilisateur->getPrenom();

            ControleurUtilisateur::afficherVue("utilisateur/formulaireMiseAJour.php", ["pagetitle" => "Modifier un utilisateur", "login" => $login, "nom"=>$nom, "prenom" => $prenom]);
        }

    }



}