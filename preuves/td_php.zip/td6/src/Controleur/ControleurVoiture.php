<?php

namespace App\Covoiturage\Controleur;


use App\Covoiturage\Modele\Repository\AbstractRepository;
use App\Covoiturage\Modele\Repository\VoitureRepository;
use App\Covoiturage\Modele\DataObject\Voiture;

class ControleurVoiture
{
    // Déclaration de type de retour void : la fonction ne retourne pas de valeur
    public static function afficherListe(): void
    {
        $voitures =  (new VoitureRepository())->recuperer();
        $cheminVueBody = 'voiture/liste.php';
        $pagetitle = 'Liste des voitures';
        ControleurVoiture::afficherVue('voiture/liste.php', ['voitures' => $voitures, 'cheminVueBody' => $cheminVueBody, 'pagetitle' => $pagetitle]);
    }

    public static function afficherDetail(): void
    {
        $immatriculation = $_GET["immat"];
        $voiture = (new VoitureRepository())->recupererParClePrimaire($immatriculation);
        // Vérifiez si $voiture est null (aucune voiture trouvée)
        if ($voiture === null) {
            // Redirige vers la vue d'erreur
            ControleurVoiture::afficherVue('voiture/erreur.php', ['messageErreur' => "Voiture introuvable"]);
        } else {
            ControleurVoiture::afficherVue('voiture/detail.php', ['voiture' => $voiture]);
        }
    }

    public static function afficherFormulaireCreation(): void
    {
        ControleurVoiture::afficherVue('voiture/formulaireCreation.php', ["pagetitle" => "Création de voiture"]);
    }

    public static function creerDepuisFormulaire(): void
    {
        $immatriculation = $_GET['immatriculation'];
        $marque = $_GET['marque'];
        $couleur = $_GET['couleur'];
        $nbSieges = $_GET['nbSieges'];
        $voiture = new Voiture($immatriculation, $marque, $couleur, $nbSieges);
        (new VoitureRepository())->sauvegarder($voiture);
        ControleurVoiture::afficherVue("voiture/voitureCreee.php", ['voitures' => (new VoitureRepository())->recuperer(), 'pagetitle' => 'Liste des voitures']);
    }

    private static function afficherVue(string $cheminVue, array $parametres = []): void
    {
        $parametres["cheminVueBody"] = $cheminVue;
        extract($parametres); // Crée des variables à partir du tableau $parametres
        require __DIR__ .  "/../vue/vueGenerale.php"; // Charge la vue générale
    }

    public static function afficherErreur(String $messageErreur = ""): void    {
        if ($messageErreur == ""){
            $messageErreur = "Problème avec la voiture";
        }
        ControleurVoiture::afficherVue("voiture/erreur.php", ["messageErreur"=>$messageErreur, "pagetitle" => "Erreur"]);
    }

    public static function supprimer(): void{
        if(!isset($_GET["immat"])){
            ControleurVoiture::afficherErreur("Immatriculation non rentrée");
        } elseif (!in_array((new VoitureRepository())->recupererParClePrimaire(($_GET["immat"])), (new VoitureRepository())->recuperer())){
            ControleurVoiture::afficherErreur("Immatriculation non valide");
        } else{
            $immatriculation = $_GET['immat'];
            (new VoitureRepository())->supprimerParCleePrimaire($immatriculation);
            ControleurVoiture::afficherVue("voiture/voitureSupprimee.php", ['immatriculation' => $immatriculation, 'pagetitle' => 'Voiture supprimer', 'voitures' => (new VoitureRepository())->recuperer()]);
        }
    }

    public static function formulaireMiseAJour(): void
    {
        if (!isset($_GET["immat"])) {
            ControleurVoiture::afficherErreur("Immatriculation non rentrée");

        } elseif (!in_array((new VoitureRepository())->recupererParClePrimaire($_GET["immat"]), (new VoitureRepository())->recuperer())){
            ControleurVoiture::afficherErreur("Immatriculation non valide");
        } else{
            $voiture = (new VoitureRepository())->recupererParClePrimaire($_GET["immat"]);
            $immatriculation = $voiture->getImmatriculation();
            $marque =  $voiture->getMarque();
            $couleur = $voiture->getCouleur();
            $nbSiege = $voiture->getNbSieges();

            ControleurVoiture::afficherVue("voiture/formulaireMiseAJour.php", ["pagetitle" => "Modifier une voiture", "immatriculation" => $immatriculation, "marque"=>$marque, "couleur" => $couleur, "nbSiege"=>$nbSiege]);
        }

    }

    public static function mettreAjour(): void{
        $immatriculation = $_GET["immatriculation"];
        $marque = $_GET["marque"];
        $couleur = $_GET["couleur"];
        $nbSiege = $_GET["nbSiege"];

        $voiture = new Voiture($immatriculation, $marque, $couleur, $nbSiege);

        (new VoitureRepository())->mettreAJour($voiture);
        ControleurVoiture::afficherVue("voiture/voitureModifiee.php", ["pagetitle" => "Voiture Modifié !", 'immatriculation' => $voiture->getImmatriculation(), 'voitures' => (new VoitureRepository())->recuperer()]);
    }
}

