<?php

namespace App\Covoiturage\Modele\DataObject;

abstract class AbstractDataObject
{
    public abstract function formatTableau(): array;
}