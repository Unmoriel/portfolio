<?php

namespace App\Covoiturage\Modele\DataObject;

class Trajet extends AbstractDataObject
{

}