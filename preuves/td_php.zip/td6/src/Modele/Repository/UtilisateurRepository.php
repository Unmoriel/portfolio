<?php

namespace App\Covoiturage\Modele\Repository;
use App\Covoiturage\Modele\DataObject\Utilisateur;

class UtilisateurRepository extends AbstractRepository
{
    protected function getNomTable(): string
    {
        return "Utilisateur";
    }

    protected function getNomClePrimaire(): string
    {
        return "login";
    }

    protected function getNomsColonnes(): array
    {
        return ["login", "nom", "prenom"];
    }

    protected function construireDepuisTableau(array $objetFormatTableau) : Utilisateur {
        return new Utilisateur(
            $objetFormatTableau["login"],
            $objetFormatTableau["nom"],
            $objetFormatTableau["prenom"]
        );
    }

    protected function sauvegarder($objet): void
    {
        $sql = "INSERT INTO ". $this->getNomTable() ." (login, nom, prenom) VALUES (:login, :nom, :prenom)";
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);

        $values = array(
            "immatriculation" => $objet->getLogin(),
            "marque" => $objet->getNom(),
            "couleur" => $objet->getPrenom()
        );

        $pdoStatement->execute($values);
    }
}