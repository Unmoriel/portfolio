<?php

namespace App\Covoiturage\Modele\Repository;

use App\Covoiturage\Modele\DataObject\AbstractDataObject;

class TrajetRepository extends AbstractRepository
{
    protected function getNomTable(): string
    {
        return "Trajet";
    }

    protected function getNomClePrimaire(): string
    {
        return "id";
    }

    protected function construireDepuisTableau(array $objetFormatTableau): AbstractDataObject
    {
        // TODO: Implement construireDepuisTableau() method.
    }

}