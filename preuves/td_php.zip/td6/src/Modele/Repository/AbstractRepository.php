<?php

namespace App\Covoiturage\Modele\Repository;

use App\Covoiturage\Modele\DataObject\AbstractDataObject;
use App\Covoiturage\Modele\DataObject\Voiture;
use MongoDB\Driver\Exception\ConnectionException;

abstract class AbstractRepository
{
    protected abstract function getNomTable(): string;
    protected abstract function construireDepuisTableau(array $objetFormatTableau) : AbstractDataObject;
    protected abstract function getNomClePrimaire(): string;
    protected abstract function getNomsColonnes(): array;

    public function recupererParClePrimaire(string $valeurClePrimaire): ?AbstractDataObject{
        $sql = "SELECT * from ".$this->getNomTable() ." WHERE ".$this->getNomClePrimaire(). " = :nomCleePrimaire";

        // Préparation de la requête
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);

        $values = array(
            "nomCleePrimaire" => $valeurClePrimaire,
            //nomdutag => valeur, ...
        );
        // On donne les valeurs et on exécute la requête
        $pdoStatement->execute($values);

        // On récupère les résultats comme précédemment
        // Note: fetch() renvoie false si pas de voiture correspondante
        $objetFormatTableau = $pdoStatement->fetch();

         // Si aucune voiture trouvée, renvoyer null
        if (!$objetFormatTableau) {
            return null;
        }

        return $this->construireDepuisTableau($objetFormatTableau);

    }

    public function recuperer(): array
    {
        $tab = [];

        // Obtenir l'objet PDO en utilisant la méthode statique ConnexionBaseDeDonnee::getPdo()
        $pdo = ConnexionBaseDeDonnee::getPdo();

        $sql = "SELECT * FROM ". $this->getNomTable();

        try {
            // Exécuter la requête SQL en utilisant la méthode query de PDO
            $pdoStatement = $pdo->query($sql);

            // Utiliser un foreach pour parcourir les résultats et créer des objets Voiture
            foreach ($pdoStatement as $objetFormatTableau) {
                // Utilisez la méthode statique construireDepuisTableau pour créer une instance de Voiture
                $element = $this->construireDepuisTableau($objetFormatTableau);

                // Ajoutez l'objet Voiture au tableau
                $tab[] = $element;
            }

        } catch (PDOException $e) {
            // Gérer les erreurs de base de données ici
            echo "Erreur SQL : " . $e->getMessage();
        }

        return $tab;
    }

    public function supprimerParCleePrimaire(string $cleePrimaire): void{
        $sql = "DELETE FROM ". $this->getNomTable() . " WHERE " . $this->getNomClePrimaire() . " = :cleePrimaire";

        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);
        $values = array(
            "cleePrimaire" => $cleePrimaire
        );
        $pdoStatement->execute($values);
    }
    public function mettreAJour(AbstractDataObject $object): void{

        $colonneETtag = [];
        foreach ($this->getNomsColonnes() as $indice){
            $colonneETtag[] = $indice." = :".$indice."Tag";
        }

        $sql = "UPDATE ". $this->getNomTable()." SET ";
        $sql = $sql .  implode(",", $colonneETtag);
        echo $sql;

        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);
        $values = $object->formatTableau();
        $pdoStatement->execute($values);
    }

    //insère l'objet courante ($this) dans la BDD
    public function sauvegarder(AbstractDataObject $object): void
    {
        $colonneETtag = [];
        foreach ($this->getNomsColonnes() as $indice){
            $colonneETtag[] = $indice." = :".$indice."Tag";
        }

        $sql = "INSERT INTO ".$this->getNomTable() . " VALUES (" . implode(",", $colonneETtag).")";
        echo $sql;
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);
        $values = $object->formatTableau();
        var_dump($values);
        $pdoStatement->execute($values);
    }
}