<?php


require_once __DIR__ . '/../src/Lib/Psr4AutoloaderClass.php';

// initialisation
$loader = new App\Covoiturage\Lib\Psr4AutoloaderClass();
$loader->register();

// enregistrement d'une association "espace de nom" → "dossier"
$loader->addNamespace('App\Covoiturage', __DIR__ . '/../src');

use App\Covoiturage\Controleur\ControleurVoiture;

$controleur = "";
$action = "";


if(isset($_GET['controleur'])){
    $controleur = $_GET['controleur'];
}else{
    $controleur = "voiture";
}

$nomDeClasseControleur = "App\Covoiturage\Controleur\Controleur" .ucfirst($controleur);

if(class_exists($nomDeClasseControleur)){
    if (isset($_GET['action'])) {
        $action = $_GET['action'];

        if (in_array($action, get_class_methods(new ControleurVoiture()))) {
            $nomDeClasseControleur::$action();

        } else {
            ControleurVoiture::afficherErreur($action . " n'est pas une action valide");
        }
    } else {
        ControleurVoiture::afficherListe();
    }
}else{
    ControleurVoiture::afficherErreur($nomDeClasseControleur." n'est pas un controleur valide");
}



?>
