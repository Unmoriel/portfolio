<?php

namespace App\Covoiturage\Controleur;


use App\Covoiturage\Modele\ModeleVoiture;

class ControleurVoiture
{
    // Déclaration de type de retour void : la fonction ne retourne pas de valeur
    public static function afficherListe(): void
    {
        $voitures = ModeleVoiture::getVoitures(); //appel au modèle pour gérer la BD
        $cheminVueBody = 'voiture/liste.php';
        $pagetitle = 'Liste des voitures';
        self::afficherVue('vueGenerale.php', ['voitures' => $voitures, 'cheminVueBody' => $cheminVueBody, 'pagetitle' => $pagetitle]);
    }

    public static function afficherDetail($immatriculation): void
    {
        $voiture = ModeleVoiture::getVoitureParImmat($immatriculation);
        // Vérifiez si $voiture est null (aucune voiture trouvée)
        if ($voiture === null) {
            // Redirige vers la vue d'erreur
            self::afficherVue('voiture/erreur.php');
        } else {
            self::afficherVue('voiture/detail.php', ['voiture' => $voiture]);
        }
    }

    public static function afficherFormulaireCreation(): void
    {
        self::afficherVue('voiture/formulaireCreation.php');
    }

    public static function creerDepuisFormulaire(): void
    {
        $immatriculation = $_GET['immatriculation'];
        $marque = $_GET['marque'];
        $couleur = $_GET['couleur'];
        $nbSieges = $_GET['nbSieges'];
        $voiture = new ModeleVoiture($immatriculation, $marque, $couleur, $nbSieges);
        $voiture->sauvegarder();
        extract(['voitures' => ModeleVoiture::getVoitures()]);
        require __DIR__ . '/../vue/voiture/voitureCreee.php';
    }

    private static function afficherVue(string $cheminVue, array $parametres = []): void
    {
        extract($parametres); // Crée des variables à partir du tableau $parametres
        require __DIR__ .  "/../vue/$cheminVue"; // Charge la vue
    }
}

