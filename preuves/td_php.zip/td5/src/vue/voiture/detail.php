<!DOCTYPE html>
<html lang="fr">
<body>
<h1>Détails de la voiture</h1>

<?php
// Vérifiez si la variable $voiture existe et n'est pas vide
if (isset($voiture)) {
    echo "<p>Marque : " . htmlspecialchars($voiture->getMarque()) . "</p>";
    echo "<p>Immatriculation : " . htmlspecialchars($voiture->getImmatriculation()) . "</p>";
    echo "<p>Couleur : " . htmlspecialchars($voiture->getCouleur()) . "</p>";
    echo "<p>Nombre de sièges : " . htmlspecialchars($voiture->getNbSieges()) . "</p>";
} else {
    echo "<p>Aucune voiture à afficher.</p>";
}
?>
</body>
</html>
