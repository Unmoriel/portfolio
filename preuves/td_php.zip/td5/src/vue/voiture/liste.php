<!DOCTYPE html>
<html lang="fr">
<body>
<?php
/** @var array $voitures */
echo "<h1>Liste des voitures</h1>";

if (isset($voitures)) {
    foreach ($voitures as $voiture) {
        $immatriculation = $voiture->getImmatriculation();
        $immatriculationHTML = htmlspecialchars($immatriculation);
        $immatriculationURL = rawurlencode($immatriculation);
        $url = "controleurFrontal.php?action=afficherDetail&immat=" . $immatriculationURL;

        echo " <p> Voiture d\'immatriculation <a href=$url> $immatriculationHTML </a>. </p> ";
    }
} else {
    echo "<p>Aucune voiture à afficher</p>";
}

?>
</body>
</html>
