<!DOCTYPE html>
<html lang="fr">
<body>

<form method="get" action="controleurFrontal.php">
    <fieldset>
        <legend>Mon formulaire :</legend>
        <p>
            <label for="immat_id">Immatriculation</label> :
            <input type="text" placeholder="256AB34" name="immatriculation" id="immat_id" required/>

            <label for="marque_id">Marque</label> :
            <input type="text" placeholder="Mercedes" name="marque" id="marque_id" required/>

            <label for="couleur_id">Couleur</label> :
            <input type="text" placeholder="Rouge" name="couleur" id="couleur_id" required/>

            <label for="nbSieges_id">Nombre de sièges</label> :
            <input type="number" placeholder="5" name="nbSieges" id="nbSieges_id" min=0 required/>
        </p>
        <p>
            <input type='hidden' name='action' value='creerDepuisFormulaire'>
            <input type="submit" value="Envoyer" />
        </p>
    </fieldset>
</form>

</body>
</html>