<!DOCTYPE html>
<html lang="fr">
<body>
<h1>Erreur</h1>
<p>Aucune voiture correspondante n'a été trouvée pour cette immatriculation.</p>
</body>
</html>
