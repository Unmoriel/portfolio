<?php
require_once "Model.php";
require_once "Voiture.php";



$tabVoiture = Voiture::getVoitures();

foreach ($tabVoiture as $cle => $voiture){
    echo $voiture;
    echo "<br>";
}