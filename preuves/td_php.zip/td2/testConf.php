<?php
// On inclut les fichiers de classe PHP pour pouvoir se servir de la classe Conf.
// require_once évite que Conf.php soit inclus plusieurs fois,
// et donc que la classe Conf soit déclaré plus d'une fois.
require_once 'Conf.php';

// On affiche le login de la base de donnees
echo "Login : " . Conf::getLogin();
echo "<br>";
echo "Database : " . Conf::getDatabase();
echo "<br>";
echo "Hostname : " . Conf::getHostname();
echo "<br>";
echo "Port : " . Conf::getPort();
echo "<br>";
echo "Password : " . Conf::getPassword();
?>

