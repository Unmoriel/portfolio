<?php

require_once "ConnexionBaseDeDonnee.php";
class ModeleVoiture {

    private string $immatriculation;
    private string $marque;
    private string $couleur;
    private int $nbSieges; // Nombre de places assises

    // un getter
    public function getMarque () : string {
        return $this->marque;
    }

    // un setter
    public function setMarque(string $marque) {
        $this->marque = $marque;
    }

    // un constructeur
    public function __construct(
        string $immatriculation,
        string $marque,
        string $couleur,
        int $nbSieges
    ) {
        $this->immatriculation = substr($immatriculation, 0, 8);
        $this->marque = $marque;
        $this->couleur = $couleur;
        $this->nbSieges = $nbSieges;
    }

    /**
     * @return mixed
     */
    public function getImmatriculation() : string
    {
        return $this->immatriculation;
    }

    /**
     * @param mixed $immatriculation
     */
    public function setImmatriculation(string $immatriculation)
    {
        $this->immatriculation = substr($immatriculation, 0, 8);
    }

    /**
     * @return mixed
     */
    public function getCouleur() : string
    {
        return $this->couleur;
    }

    /**
     * @param mixed $couleur
     */
    public function setCouleur(string $couleur)
    {
        $this->couleur = $couleur;
    }

    /**
     * @return mixed
     */
    public function getNbSieges() : int
    {
        return $this->nbSieges;
    }

    /**
     * @param mixed $nbSieges
     */
    public function setNbSieges(string $nbSieges)
    {
        $this->nbSieges = $nbSieges;
    }

    // Pour pouvoir convertir un objet en chaîne de caractères
    /*public function __toString() : string {
        return "<p>Marque : $this->marque</p>
                <p>Immatriculation : $this->immatriculation</p>
                <p>Couleur : $this->couleur</p>
                <p>Nombre de sièges : $this->nbSieges</p>";
    }*/

    public static function construireDepuisTableau(array $voitureFormatTableau) : ModeleVoiture {
        return new ModeleVoiture(
            $voitureFormatTableau['immatriculation'],
            $voitureFormatTableau['marque'],
            $voitureFormatTableau['couleur'],
            $voitureFormatTableau['nbSieges']
        );
    }

    public static function getVoitures() : array {
        $voitures = []; // Crée un tableau vide pour stocker les objets ModeleVoiture

        // Obtenir l'objet PDO en utilisant la méthode statique ConnexionBaseDeDonnee::getPdo()
        $pdo = ConnexionBaseDeDonnee::getPdo();

        // Requête SQL pour récupérer toutes les voitures
        $sql = "SELECT * FROM Voiture";

        try {
            // Exécuter la requête SQL en utilisant la méthode query de PDO
            $pdoStatement = $pdo->query($sql);

            // Utiliser un foreach pour parcourir les résultats et créer des objets ModeleVoiture
            foreach ($pdoStatement as $voitureFormatTableau) {
                // Utilisez la méthode statique construireDepuisTableau pour créer une instance de ModeleVoiture
                $voiture = ModeleVoiture::construireDepuisTableau($voitureFormatTableau);

                // Ajoutez l'objet ModeleVoiture au tableau
                $voitures[] = $voiture;
            }

        } catch (PDOException $e) {
            // Gérer les erreurs de base de données ici
            echo "Erreur SQL : " . $e->getMessage();
        }

        return $voitures;
    }

    public static function getVoitureParImmat(string $immatriculation) : ?ModeleVoiture {
        $sql = "SELECT * from Voiture WHERE immatriculation = :immatriculationTag";
        // Préparation de la requête
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);

        $values = array(
            "immatriculationTag" => $immatriculation,
            //nomdutag => valeur, ...
        );
        // On donne les valeurs et on exécute la requête
        $pdoStatement->execute($values);

        // On récupère les résultats comme précédemment
        // Note: fetch() renvoie false si pas de voiture correspondante
        $voitureFormatTableau = $pdoStatement->fetch();

        // Si aucune voiture trouvée, renvoyer null
        if (!$voitureFormatTableau) {
            return null;
        }

        return ModeleVoiture::construireDepuisTableau($voitureFormatTableau);
    }

    //insère la voiture courante ($this) dans la BDD
    public function sauvegarder(): void {
        $sql = "INSERT INTO Voiture (immatriculation, marque, couleur, nbSieges) VALUES (:immatriculation, :marque, :couleur, :nbSieges)";
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);

        $values = array(
            "immatriculation" => $this->immatriculation,
            "marque" => $this->marque,
            "couleur" => $this->couleur,
            "nbSieges" => $this->nbSieges,
        );

        $pdoStatement->execute($values);
    }


}
?>