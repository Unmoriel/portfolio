<?php
require_once 'ControleurVoiture.php';

$action = $_GET['action'];

if (isset($_GET['immat'])) { //si immat existe
    $immatriculation = $_GET['immat'];
    ControleurVoiture::$action($immatriculation);
} else {
    ControleurVoiture::$action();
}
?>
