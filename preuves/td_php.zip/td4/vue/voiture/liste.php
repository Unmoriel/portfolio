<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Liste des voitures</title>
</head>
<body>
<?php
/** @var array $voitures */
echo "<h1>Liste des voitures</h1>";

if (isset($voitures)) {
    foreach ($voitures as $voiture) {
        $immatriculation = $voiture->getImmatriculation();
        $url = "https://webinfo.iutmontp.univ-montp2.fr/~georgesa/td4/Controleur/routeur.php?action=afficherDetail&immat=" . $immatriculation;

        echo " <p> Voiture d\'immatriculation <a href=$url> $immatriculation </a>. </p> ";
    }
} else {
    echo "<p>Aucune voiture à afficher</p>";
}

?>
</body>
</html>
