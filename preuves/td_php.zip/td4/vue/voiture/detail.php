<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Détails de la voiture</title>
</head>
<body>
<h1>Détails de la voiture</h1>

<?php
// Vérifiez si la variable $voiture existe et n'est pas vide
if (isset($voiture)) {
    echo "<p>Marque : " . $voiture->getMarque() . "</p>";
    echo "<p>Immatriculation : " . $voiture->getImmatriculation() . "</p>";
    echo "<p>Couleur : " . $voiture->getCouleur() . "</p>";
    echo "<p>Nombre de sièges : " . $voiture->getNbSieges() . "</p>";
} else {
    echo "<p>Aucune voiture à afficher.</p>";
}
?>
</body>
</html>
