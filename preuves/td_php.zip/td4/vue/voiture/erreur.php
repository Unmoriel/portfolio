<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Erreur</title>
</head>
<body>
<h1>Erreur</h1>
<p>Aucune voiture correspondante n'a été trouvée pour cette immatriculation.</p>
</body>
</html>
