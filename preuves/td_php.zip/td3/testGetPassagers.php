<?php
require_once 'Trajet.php';

$tabPassager = Trajet::getPassagers(3);

foreach ($tabPassager as $cle => $passager) {
    echo $passager;
    echo "<br>";

}