<?php
require_once 'Model.php';
class Voiture
{

    private string $immatriculation;
    private string $marque;
    private string $couleur;
    private string $nbSieges; // Nombre de places assises

    // un getter
    public function getMarque() : string
    {
        return $this->marque;
    }

    // un setter
    public function setMarque($marque) : void
    {
        $this->marque = $marque;
    }

    /**
     * @return mixed
     */
    public function getImmatriculation() : string
    {
        return $this->immatriculation;
    }

    /**
     * @return mixed
     */
    public function getNbSieges() : int
    {
        return $this->nbSieges;
    }

    /**
     * @return mixed
     */
    public function getCouleur() : string
    {
        return $this->couleur;
    }

    /**
     * @param mixed $immatriculation
     */
    public function setImmatriculation($immatriculation) : void
    {
        $this->immatriculation = substr($immatriculation, 0, 8);
    }

    /**
     * @param mixed $couleur
     */
    public function setCouleur($couleur) : void
    {
        $this->couleur = $couleur;
    }

    /**
     * @param mixed $nbSieges
     */
    public function setNbSieges($nbSieges) : void
    {
        $this->nbSieges = $nbSieges;
    }

    public static function construireDepuisTableau(array $voitureFormatTableau) : Voiture {
        return new Voiture($voitureFormatTableau["immatriculation"], $voitureFormatTableau["marque"], $voitureFormatTableau["couleur"], $voitureFormatTableau["nbSieges"]);
    }

    public static function getVoitures() : array{
        $pdoStatement = Model::getPdo()->query("SELECT * FROM voiture");
        $tabVoiture = [];
        foreach ($pdoStatement as $voitureFormatTableau){
            $tabVoiture[] = self::construireDepuisTableau($voitureFormatTableau);
        }

        return $tabVoiture;
    }

    public static function getVoitureParImmat(string $immatriculation) : ?Voiture {
        $sql = "SELECT * from voiture WHERE immatriculation = :immatriculationTag";
        // Préparation de la requête
        $pdoStatement = Model::getPdo()->prepare($sql);

        $values = array(
            "immatriculationTag" => $immatriculation,
            //nomdutag => valeur, ...
        );
        // On donne les valeurs et on exécute la requête
        $pdoStatement->execute($values);

        // On récupère les résultats comme précédemment
        // Note: fetch() renvoie false si pas de voiture correspondante
        $voitureFormatTableau = $pdoStatement->fetch();
        if (!$voitureFormatTableau){
            return null ;
        }
        return Voiture::construireDepuisTableau($voitureFormatTableau);

    }

    public function sauvegarder() : void{
        $sql = "INSERT INTO voiture (immatriculation, marque, couleur, nbSieges) VALUES (:immatriculationTag, :marqueTag, :couleurTag, :nbSiege)";
        $pdoStatement = Model::getPdo()->prepare($sql);

        $values = array(
            "immatriculationTag" => $this->immatriculation,
            "marqueTag" => $this->marque,
            "couleurTag" => $this->couleur,
            "nbSiege" => $this->nbSieges
        );

        $pdoStatement->execute($values);

    }


    // un constructeur
    public function __construct(
        string $immatriculation,
        string $marque,
        string $couleur,
        int $nbSieges
    )
    {
        $this->setImmatriculation($immatriculation);
        $this->marque = $marque;
        $this->couleur = $couleur;
        $this->nbSieges = $nbSieges;
    }

    // Pour pouvoir convertir un objet en chaîne de caractères
    public function __toString() : string
    {
        return "Voiture $this->immatriculation de marque $this->marque (couleur $this->couleur, $this->nbSieges sièges)";
    }
}
