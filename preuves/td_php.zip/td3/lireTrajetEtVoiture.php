<?php

require_once 'Trajet.php';
require_once 'Utilisateur.php';

echo "Trajets :";
echo "<br><br>";

foreach (Trajet::getTrajets() as $trajet) {
    echo $trajet;
}

echo "Utilisateurs :";
echo "<br><br>";

foreach (Utilisateur::getUtilisateurs() as $utilisateur) {
    echo $utilisateur;
}

