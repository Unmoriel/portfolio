<?php
require_once "Voiture.php";
require_once "Model.php";

$v = new Voiture("7U8I91HU", "Tesla", "Rouge", 5);

//$v->sauvegarder();
