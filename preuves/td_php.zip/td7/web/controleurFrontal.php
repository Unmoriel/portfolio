<?php


require_once __DIR__ . '/../src/Lib/Psr4AutoloaderClass.php';

// initialisation
$loader = new App\Covoiturage\Lib\Psr4AutoloaderClass();
$loader->register();

// enregistrement d'une association "espace de nom" → "dossier"
$loader->addNamespace('App\Covoiturage', __DIR__ . '/../src');

use App\Covoiturage\Controleur\ControleurGenerique;
use App\Covoiturage\Controleur\ControleurVoiture;
use App\Covoiturage\Lib\PreferenceControleur;

$controleur = "";
$action = "";

if(isset($_GET['controleur'])){
    $controleur = $_GET['controleur'];
}else{
    if(PreferenceControleur::existe()){
        $controleur = PreferenceControleur::lire();
    }else{
        $controleur = "controleurGenerique";
    }
}


$nomDeClasseControleur = "App\Covoiturage\Controleur\Controleur" .ucfirst($controleur);
if(class_exists($nomDeClasseControleur)){
    if (isset($_GET['action'])) {
        $action = $_GET['action'];
        if (method_exists($nomDeClasseControleur, $action)) {
            $nomDeClasseControleur::$action();
        } else {
            ControleurGenerique::afficherErreur($action . " n'est pas une action valide");
        }
    } else {
        $nomDeClasseControleur::afficherListe();
    }
}else{
    ControleurGenerique::afficherErreur($nomDeClasseControleur." n'est pas un controleur valide");
}




