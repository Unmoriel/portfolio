<!DOCTYPE html>
<html lang="fr">
<body>

<form method="get" action="controleurFrontal.php">
    <fieldset>
        <legend>Mon formulaire :</legend>
        <p>
            <input type="radio" id="voitureId" name="controleur_defaut" value="voiture" checked=<?php echo $voitureChecked?>>
            <label for="voitureId">Voiture</label>
            <input type="radio" id="utilisateurId" name="controleur_defaut" value="utilisateur" checked=<?php echo $utilisateurChecked?>>
            <label for="utilisateurId">Utilisateur</label>
            <input type="radio" id="trajetId" name="controleur_defaut" value="trajet" disabled="disabled">
            <label for="trajetId">Trajet</label>
        </p>
        <p>
            <input type='hidden' name='action' value='enregistrerPreference'>
            <input type="submit" value="Envoyer" />
        </p>
    </fieldset>
</form>

</body>
</html>
