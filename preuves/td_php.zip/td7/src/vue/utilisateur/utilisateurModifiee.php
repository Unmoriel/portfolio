<!doctype html>
<html lang="fr">
<body>
<p>
    <?php
    /** @var string $login */
    echo "L'utilisateur $login a bien été modfiée !"
    ?>
</p>

<?php
require __DIR__ . '/liste.php';
?>
</body>
</html><?php
