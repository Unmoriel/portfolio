<!DOCTYPE html>
<html lang="fr">
<body>

<form method="get" action="controleurFrontal.php">
    <fieldset>
        <legend>Création d'un utilisateur</legend>
        <p>
            <label for="login_id">Login</label> :
            <input type="text" placeholder="dupontj" name="login" id="login_id" required/>

            <label for="nom_id">Nom</label> :
            <input type="text" placeholder="Dupont" name="nom" id="nom_id" required/>

            <label for="prenom_id">Prenom</label> :
            <input type="text" placeholder="Jean" name="prenom" id="prenom_id" required/>

        </p>
        <p>
            <input type='hidden' name='action' value='creerDepuisFormulaire'>
            <input type="hidden" name="controleur" value="utilisateur">
            <input type="submit" value="Envoyer" />
        </p>
    </fieldset>
</form>

</body>
</html>
