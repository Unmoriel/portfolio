<!DOCTYPE html>
<html lang="fr">
<body>
<h1>Erreur</h1>
<?php
    /** @var string $messageErreur */
    echo $messageErreur;
?>
</body>
</html>
