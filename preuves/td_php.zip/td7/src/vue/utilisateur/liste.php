<!DOCTYPE html>
<html lang="fr">
<body>
<?php
/** @var array $utilisateurs */
echo "<h1>Liste des Utilisateurs</h1>";

if (isset($utilisateurs)) {
    foreach ($utilisateurs as $utilisateur) {
        $login =  $utilisateur->getLogin();
        $loginHTML = htmlspecialchars($login);
        $loginURL = rawurlencode($login);
        $urlDetail = "?action=afficherDetail&controleur=utilisateur&login=" . $loginURL;
        $urlModifier = "?action=formulaireMiseAJour&controleur=utilisateur&login=" . $loginURL;
        $urlSupprimer = "?action=supprimer&controleur=utilisateur&login=" . $loginURL;


        echo " <p> <a href=$urlDetail> $loginHTML</a>               
                <button type='button'> <a href=$urlSupprimer>Supprimer</a> </button> 
                <button type='button'> <a href=$urlModifier>Modifier</a> </button> </p> ";
    }
} else {
    echo "<p>Aucun utilisateur à afficher</p>";
}

?>
</body>
</html>
