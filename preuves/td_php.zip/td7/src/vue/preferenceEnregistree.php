<!DOCTYPE html>
<html lang="fr">
<body>

<p>La préférence de contrôleur est enregistrée !.</p>
</form>

</body>
</html>

