<!DOCTYPE html>
<html>
   <head>
      <meta charset="UTF-8">
       <style>
           <?php require __DIR__ . '/../../ressources/style.css'?>
       </style>
      <title><?php /** @var string $pagetitle */ echo $pagetitle; ?></title>
</head>
<body>
<header>
    <nav>
        <ul>
            <li>
                <a href="controleurFrontal.php?action=afficherListe&controleur=voiture">Gestion des voitures</a>
            </li><li>
                <a href="controleurFrontal.php?action=afficherListe&controleur=utilisateur">Gestion des utilisateurs</a>
            </li><li>
                <a href="controleurFrontal.php?action=afficherListe&controleur=trajet">Gestion des trajets</a>
            </li><li>
                <a href="controleurFrontal.php?action=afficherFormulaireCreation&controleur=voiture">Ajouter une voiture</a>
            </li><li>
                <a href="controleurFrontal.php?action=afficherFormulaireCreation&controleur=utilisateur">Ajouter un utilisateur</a>
            </li>
            <li>
                <a href="?action=afficherFormulairePreference"><img src="../ressources/img/heart.png"></a>
            </li>
        </ul>
    </nav>


</header>
<main>
    <?php /** @var string $cheminVueBody */
    require __DIR__ . "/{$cheminVueBody}";
    ?>
</main>
<footer>
    <p>
        Site de covoiturage de Aurel GEORGES
    </p>
</footer>
</body>
</html>

