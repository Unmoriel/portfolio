<!doctype html>
<html lang="fr">
<body>
<p>La voiture a bien été créée !</p>

<?php
    require __DIR__ . '/liste.php';
?>
</body>
</html>


