<!DOCTYPE html>
<html lang="fr">
<body>
<?php
/** @var array $voitures */
echo "<h1>Liste des voitures</h1>";

if (isset($voitures)) {
    foreach ($voitures as $voiture) {
        $immatriculation = $voiture->getImmatriculation();
        $immatriculationHTML = htmlspecialchars($immatriculation);
        $immatriculationURL = rawurlencode($immatriculation);
        $urlDetail = "?action=afficherDetail&immat=" . $immatriculationURL;
        $urlSupprimer = "?action=supprimer&immat=" . $immatriculationURL;
        $urlModifier= "?action=formulaireMiseAJour&immat=" . $immatriculationURL;

        echo " <p> Voiture d\'immatriculation <a href=$urlDetail> $immatriculationHTML </a> 
               <button type='button'> <a href=$urlSupprimer>Supprimer</a> </button> 
               <button type='button'> <a href=$urlModifier>Modifier</a> </button> </p> ";
    }
} else {
    echo "<p>Aucune voiture à afficher</p>";
}

?>
</body>
</html>
