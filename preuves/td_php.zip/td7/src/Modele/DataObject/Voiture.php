<?php

namespace App\Covoiturage\Modele\DataObject;


class Voiture extends AbstractDataObject
{

    private string $immatriculation;
    private string $marque;
    private string $couleur;
    private int $nbSieges; // Nombre de places assises

    // un getter
    public function getMarque(): string
    {
        return $this->marque;
    }


    // un setter
    public function setMarque(string $marque)
    {
        $this->marque = $marque;
    }

    // un constructeur
    public function __construct(
        string $immatriculation,
        string $marque,
        string $couleur,
        int    $nbSieges
    )
    {
        $this->immatriculation = substr($immatriculation, 0, 8);
        $this->marque = $marque;
        $this->couleur = $couleur;
        $this->nbSieges = $nbSieges;
    }

    /**
     * @return mixed
     */
    public function getImmatriculation(): string
    {
        return $this->immatriculation;
    }

    /**
     * @param mixed $immatriculation
     */
    public function setImmatriculation(string $immatriculation)
    {
        $this->immatriculation = substr($immatriculation, 0, 8);
    }

    /**
     * @return mixed
     */
    public function getCouleur(): string
    {
        return $this->couleur;
    }

    /**
     * @param mixed $couleur
     */
    public function setCouleur(string $couleur)
    {
        $this->couleur = $couleur;
    }

    /**
     * @return mixed
     */
    public function getNbSieges(): int
    {
        return $this->nbSieges;
    }

    public function formatTableau(): array
    {
        return array(
            "immatriculationTag" => $this->immatriculation,
            "marqueTag" => $this->marque,
            "couleurTag" => $this->couleur,
            "nbSiegesTag" => $this->nbSieges,
        );
    }

    /**
     * @param mixed $nbSieges
     */
    public function setNbSieges(string $nbSieges)
    {
        $this->nbSieges = $nbSieges;
    }

    // Pour pouvoir convertir un objet en chaîne de caractères
    /*public function __toString() : string {
        return "<p>Marque : $this->marque</p>
                <p>Immatriculation : $this->immatriculation</p>
                <p>Couleur : $this->couleur</p>
                <p>Nombre de sièges : $this->nbSieges</p>";
    }*/










}

?>