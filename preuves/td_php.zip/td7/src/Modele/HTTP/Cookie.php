<?php

namespace App\Covoiturage\Modele\HTTP;

class Cookie
{
    public static function enregistrer(string $cle, mixed $valeur, ?int $dureeExpiration = null): void{

        $valSerialise = serialize($valeur);
        $duree = 0;
        if ($dureeExpiration == null){
            setcookie($cle, $valSerialise, 0);
        }else{
            setcookie($cle, $valSerialise, time()+$dureeExpiration);
        }
    }

    public static function lire(string $cle): mixed{
        return unserialize($_COOKIE[$cle]);
    }

    public static function contient($cle) : bool{
        return isset($_COOKIE[$cle]);
    }

    public static function supprimer($cle) : void{
        unset($_COOKIE[$cle]);
        setcookie($cle, "", 1);
    }
}