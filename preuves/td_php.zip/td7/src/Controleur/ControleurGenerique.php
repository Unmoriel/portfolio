<?php

namespace App\Covoiturage\Controleur;

use App\Covoiturage\Lib\PreferenceControleur;

class ControleurGenerique
{
    protected static function afficherVue(string $cheminVue, array $parametres = []): void
    {
        $parametres["cheminVueBody"] = $cheminVue;
        extract($parametres); // Crée des variables à partir du tableau $parametres
        require __DIR__ . "/../vue/vueGenerale.php"; // Charge la vue générale
    }

    public static function afficherErreur(string $messageErreur = ""): void
    {
        if ($messageErreur == "") {
            $messageErreur = "Problème avec la voiture";
        }
        ControleurUtilisateur::afficherVue("utilisateur/erreur.php", ["messageErreur" => $messageErreur, "pagetitle" => "Erreur"]);
    }

    public static function afficherFormulairePreference()
    {
        $voitureChecked = "";
        $utilisateurChecked = "";
        if (PreferenceControleur::lire() == "voiture"){
            $voitureChecked = "checked";
        }
        elseif (PreferenceControleur::lire() == "utilisateur"){
            $utilisateurChecked = "checked";
        }
        ControleurGenerique::afficherVue("formulairePreference.php", ["pagetitle" => "Préférences",
                                                                                "utilisateurChecked" => $utilisateurChecked,
                                                                                "voitureChecked" => $voitureChecked]);
    }

    public static function enregistrerPreference()
    {
        PreferenceControleur::enregistrer($_GET["controleur_defaut"]);
        self::afficherVue("preferenceEnregistree.php", ["pagetitle" => 'Préférence enregistrée']);
    }
}
