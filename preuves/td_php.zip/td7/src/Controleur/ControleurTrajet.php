<?php

namespace App\Covoiturage\Controleur;

class ControleurTrajet extends ControleurGenerique
{

}