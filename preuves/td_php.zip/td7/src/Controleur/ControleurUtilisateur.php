<?php

namespace App\Covoiturage\Controleur;

use App\Covoiturage\Modele\DataObject\Utilisateur;
use App\Covoiturage\Modele\Repository\UtilisateurRepository;

class ControleurUtilisateur extends ControleurGenerique
{
    public static function afficherListe(): void
    {
        $utilisateurs = (new UtilisateurRepository())->recuperer();
        $pagetitle = 'Liste des utilisateurs';
        ControleurUtilisateur::afficherVue('utilisateur/liste.php', ['utilisateurs' => $utilisateurs, 'pagetitle' => $pagetitle]);
    }


    public static function afficherDetail(): void
    {
        $login = $_GET["login"];
        $utilisateur = (new UtilisateurRepository())->recupererParClePrimaire($login);
        if ($utilisateur === null) {
            // Redirige vers la vue d'erreur
            echo "WIP";
        } else {
            ControleurUtilisateur::afficherVue('utilisateur/detail.php', ['utilisateur' => $utilisateur]);
        }
    }

    public static function supprimer(): void{
        if(!isset($_GET["login"])){
            ControleurUtilisateur::afficherErreur("Login non rentré");
        } elseif (!in_array((new UtilisateurRepository())->recupererParClePrimaire(($_GET["login"])), (new UtilisateurRepository())->recuperer())){
            ControleurUtilisateur::afficherErreur("Login inconnus");
        } else{
            $login = $_GET['login'];
            (new UtilisateurRepository())->supprimerParCleePrimaire($login);
            ControleurUtilisateur::afficherVue("utilisateur/utilisateurSupprime.php", ['login' => $login, 'pagetitle' => 'Utilisateur supprimer', 'utilisateurs' => (new UtilisateurRepository())->recuperer()]);
        }
    }

    public static function afficherFormulaireCreation(): void
    {
        ControleurUtilisateur::afficherVue('utilisateur/formulaireCreation.php', ["pagetitle" => "Création de voiture"]);
    }

    public static function creerDepuisFormulaire(): void
    {
        $login = $_GET['login'];
        $nom = $_GET['nom'];
        $prenom = $_GET['prenom'];
        $utilisateur = new Utilisateur($login, $nom, $prenom);
        (new UtilisateurRepository())->sauvegarder($utilisateur);
        ControleurUtilisateur::afficherVue("utilisateur/utilisateurCree.php", ['utilisateurs' => (new UtilisateurRepository())->recuperer(), 'pagetitle' => 'Liste des utilisateurs', 'login'=>$login]);
    }



    public static function formulaireMiseAJour(): void
    {
        if (!isset($_GET["login"])) {
            ControleurVoiture::afficherErreur("login non rentré");

        } elseif (!in_array((new UtilisateurRepository())->recupererParClePrimaire($_GET["login"]), (new UtilisateurRepository())->recuperer())){
            ControleurVoiture::afficherErreur("login non valide");
        } else{
            $utilisateur = (new UtilisateurRepository())->recupererParClePrimaire($_GET["login"]);
            $login = $utilisateur->getLogin();
            $nom =  $utilisateur->getNom();
            $prenom = $utilisateur->getPrenom();

            ControleurUtilisateur::afficherVue("utilisateur/formulaireMiseAJour.php", ["pagetitle" => "Modifier un utilisateur", "login" => $login, "nom"=>$nom, "prenom" => $prenom]);
        }

    }

    public static function mettreAjour(): void{
        $login = $_GET["login"];
        $nom = $_GET["nom"];
        $prenom = $_GET["prenom"];

        $utilisateur = new Utilisateur($login, $nom, $prenom);

        (new UtilisateurRepository())->mettreAJour($utilisateur);
        ControleurUtilisateur::afficherVue("utilisateur/utilisateurModifiee.php", ["pagetitle" => "Utilisateur Modifié !", 'login' => $utilisateur->getLogin(), 'utilisateurs' => (new UtilisateurRepository())->recuperer()]);
    }



}