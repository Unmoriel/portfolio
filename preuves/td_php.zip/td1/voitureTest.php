<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php
        require_once "Voiture.php";
        $voiture1 = new Voiture('A6A7PO', 'Renault', 'Rouge', 5);
        echo $voiture1;

    ?>

</body>
</html>


