<?php
require_once 'Voiture.php';

$voiture = new Voiture($_GET['immatriculation'], $_GET['marque'], $_GET['couleur'], $_GET['nombreSiege']);

echo $voiture;