<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title> Mon premier php </title>
</head>

<body>
<?php
// Ceci est un commentaire PHP sur une ligne
/* Ceci est le 2ème type de commentaire PHP
sur plusieurs lignes */

// On met la chaine de caractères "hello" dans la variable 'texte'
// Les noms de variable commencent par $ en PHP
$marque = 'AurelMobile';
$couleur = 'Bleu';
$immatriculation = '90BN21';
$nbSiege = 5;

$voitureTab = [
        'marque' => 'AurelMobile',
        'couleur' => 'Bleu',
        'immatriculation' => '90BN21',
        'nbSiege' => '5'
];
// On écrit le contenu de la variable 'texte' dans la page Web
//echo "Voiture $immatriculation de marque $marque (couleur $couleur, $nbSiege sieges) \n";
//echo "Voiture $voitureTab[immatriculation] de marque $voitureTab[marque] (couleur $voitureTab[couleur], $voitureTab[nbSiege])";
?>




}
?>



</body>
</html>