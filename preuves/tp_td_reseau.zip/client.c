#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>

#define PORT 12345

int main() {
    int sock;
    struct sockaddr_in serverAddr;
    struct hostent *server;
    printf("Adresse :");
    char SERV[256];
    fgets(SERV, sizeof(SERV), stdin);
    SERV[strcspn(SERV, "\n")] = '\0';
    sock = socket(AF_INET, SOCK_STREAM, 0);
    server = gethostbyname(SERV);

    bzero((char *)&serverAddr, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    bcopy((char *)server->h_addr, (char *)&serverAddr.sin_addr.s_addr, server->h_length);

    connect(sock, (struct sockaddr *)&serverAddr, sizeof(serverAddr));

    char message[80];
    char reponse[80];

    while (1) {
        printf("Saisissez un message (ou 'fin' pour quitter) : ");
        fgets(message, sizeof(message), stdin);

        write(sock, message, strlen(message));

        if (strncmp(message, "fin", 3) == 0) {
            break;
        }

        read(sock, reponse, sizeof(reponse));
        printf("Réponse du serveur : %s\n", reponse);
    }

    close(sock);

    return 0;
}