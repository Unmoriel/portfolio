#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 12345
#define BUFFER_SIZE 1024
#define NUM_MESSAGES 5

int main() {
    int sockfd;
    struct sockaddr_in servaddr, cliaddr;
    char buffer[BUFFER_SIZE];
    socklen_t len;
    int i;

    // Création du socket UDP
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Erreur de création de socket");
        exit(EXIT_FAILURE);
    }

    // Initialisation de l'adresse du serveur
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = INADDR_ANY;

    // Liaison du socket à l'adresse du serveur
    if (bind(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("Erreur de liaison");
        exit(EXIT_FAILURE);
    }

    printf("Serveur en écoute sur le port %d\n", PORT);

    for (i = 0; i < NUM_MESSAGES; i++) {
        len = sizeof(cliaddr);
        if (recvfrom(sockfd, buffer, BUFFER_SIZE, 0, 
                     (struct sockaddr *)&cliaddr, &len) < 0) {
            perror("Erreur de réception");
            exit(EXIT_FAILURE);
        }

        buffer[len] = '\0';
        printf("Message reçu : %s\n", buffer);
    }

    // Fermeture du socket
    close(sockfd);
    return 0;
}