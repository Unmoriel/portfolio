#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>

int main() {
    int sock;
    struct sockaddr_in serverAddr;
    struct hostent *server;
    
    printf("Adresse IP du serveur : ");
    char SERV[256];
    fgets(SERV, sizeof(SERV), stdin);
    SERV[strcspn(SERV, "\n")] = '\0';

    printf("Numéro de port du serveur : ");
    int PORT;
    scanf("%d", &PORT);
    getchar(); 

    sock = socket(AF_INET, SOCK_STREAM, 0);
    server = gethostbyname(SERV);

    bzero((char *)&serverAddr, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    bcopy((char *)server->h_addr, (char *)&serverAddr.sin_addr.s_addr, server->h_length);

    connect(sock, (struct sockaddr *)&serverAddr, sizeof(serverAddr));

    char message[80];
    char reponse[1024];

    while (1) {
        fprintf(stderr, "Saissez la requete : ");
        fgets(message, sizeof(message), stdin);

        write(sock, message, strlen(message));

        if (strncmp(message, "fin", 3) == 0) {
            break;
        }

        int n;
        bzero(reponse, sizeof(reponse));
        while ((n = read(sock, reponse, sizeof(reponse) - 1)) > 0) {
            printf("%s", reponse); 
            if (n < sizeof(reponse) - 1)
                break; 
            bzero(reponse, sizeof(reponse));
        }
    }

    close(sock);

    return 0;
}
    