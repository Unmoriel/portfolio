#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <strings.h>
#include <unistd.h>
#include <pthread.h>

#define PORT 12345

int sock;
struct sockaddr_in local;

void *clientHandler(void *arg) {
    int clientSocket = *(int *)arg;
    char message[80];

    strcpy(message, "");
    while (strncmp(message, "fin", 3) != 0) {
        read(clientSocket, message, 80);
        printf("Le client me dit : %s\n", message);

        char reply[80];
        printf("Saisissez un message (ou 'fin' pour quitter) : ");
        fgets(reply, sizeof(reply), stdin);
        write(clientSocket, reply, 80);
    }

    close(clientSocket);
    pthread_exit(NULL);
}

int main() {
    bzero(&local, sizeof(local));
    local.sin_family = AF_INET;
    local.sin_port = htons(PORT);
    local.sin_addr.s_addr = INADDR_ANY;
    bzero(&(local.sin_zero), 8);

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket");
        exit(1);
    }

    if (bind(sock, (struct sockaddr *)&local, sizeof(struct sockaddr_in)) == -1) {
        perror("bind");
        exit(1);
    }

    if (listen(sock, 5) == -1) {
        perror("listen");
        exit(1);
    }

    while (1) {
        printf("En attente d'un client\n");

        int clientSocket;
        if ((clientSocket = accept(sock, NULL, NULL)) == -1) {
            perror("accept");
            exit(1);
        }

        printf("Client connecté\n");

        pthread_t thread;
        pthread_create(&thread, NULL, clientHandler, (void *)&clientSocket);
        pthread_detach(thread);
    }

    return 0;
}