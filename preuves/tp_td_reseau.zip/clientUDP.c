#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define SERVER_PORT 12345
#define SERVER_IP "127.0.0.1"
#define NUM_MESSAGES 5

int main() {
int sockfd;
struct sockaddr_in servaddr;
char message[100];
int i;


// Création du socket UDP
sockfd = socket(AF_INET, SOCK_DGRAM, 0);
if (sockfd < 0) {
    perror("Erreur de création de socket");
    exit(EXIT_FAILURE);
}

// Initialisation de l'adresse du serveur
memset(&servaddr, 0, sizeof(servaddr));
servaddr.sin_family = AF_INET;
servaddr.sin_port = htons(SERVER_PORT);
servaddr.sin_addr.s_addr = inet_addr(SERVER_IP);

for (i = 0; i < NUM_MESSAGES; i++) {
    sprintf(message, "Message %d depuis le client", i + 1);
    
    // Envoi du message
    if (sendto(sockfd, message, strlen(message), 0, 
               (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("Erreur d'envoi");
        exit(EXIT_FAILURE);
    }

    printf("Message envoyé: %s\n", message);
    sleep(1); // Attente d'une seconde entre les envois
}

// Fermeture du socket
close(sockfd);
return 0;

}