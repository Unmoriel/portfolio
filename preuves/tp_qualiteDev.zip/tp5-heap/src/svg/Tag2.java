package svg;

public class Tag2 extends Tag {
	
	public Tag2 (String name) {
	
		super(name);
	}
}