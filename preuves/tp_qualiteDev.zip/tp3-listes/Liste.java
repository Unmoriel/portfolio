class Liste{
    private int val;
    private Liste suiv;
    
    //attention : utilisez plutôt "getVal()" que "val", car getVal() renvoie une exception quand la liste est vide,
	//et vous empêche donc d'utiliser la valeur "fantôme" du dernier maillon

    //liste vide =_def (*,null)
 
    //////////////////////////////////////////////
    //////// méthodes fournies
    //////////////////////////////////////////////
    
    public Liste(){
	suiv = null;
    }

    public Liste(Liste l){
	if(l.estVide()){
	    suiv=null;
	}
	else{
	    val = l.val;
	    suiv = new Liste(l.suiv);
	}
    }

    public Liste(int x, Liste l){
	val = x;
	suiv = new Liste(l);
    }

	public int getVal(){
		//sur liste non vide
		if(estVide())
			throw new RuntimeException("getVal appelée sur liste vide");
		return val;
	}
	public Liste getSuiv(){
		return suiv;
	}

	public void ajoutTete(int x){
		if(estVide()){
			val = x;
			suiv = new Liste();
		}
		else {
			Liste aux = new Liste();
			aux.val = getVal();
			aux.suiv = suiv;
			val = x;
			suiv = aux;
		}
	}

    public void supprimeTete(){
		//sur liste non vide
		if(suiv.estVide()){
			suiv = null;
		}
		else {
			val = suiv.getVal();
			suiv = suiv.suiv;
		}
    }

    public boolean estVide(){
		return suiv==null;
    }



    public String toString(){
		if(estVide()){
			return "()";
		}
		else{
			return getVal()+" "+suiv.toString();
		}
    }



    //////////////////////////////////////////////
    //////// méthodes du TD
    //////////////////////////////////////////////

	public int longueur(){
		if(estVide()){
			return 0;
		}else{
			return suiv.longueur() + 1;
		}
	}

	public int somme(){
		if(estVide()){
			return 0;
		}else{
			return suiv.somme() + getVal();
		}
	}

	public boolean croissant(){
		if(suiv.estVide()){
			return true;
		}else{
			if(getVal() <= getSuiv().getVal()){
				return suiv.croissant();
			}else {
				return false;
			}
		}
	}

	public int get(int i){
		if(i == 0) {
			return getVal();
		}else{
			return get(i-1);
		}
	}

    public void ajoutFin(int x){
		if(estVide()){
			ajoutTete(x);
		}else{
			getSuiv().ajoutFin(x);
		}
	}

	public void concat(Liste l){
		if(getSuiv().estVide()) {
			suiv = l;
		}else if(estVide()){
			val = l.val;
			suiv = l.suiv;
		}else {
			getSuiv().concat(l);
		}
	}

	public Liste supprOccs(int x){
		if(estVide()){
			return new Liste();
		}else {
			if(getVal() == x){
				return getSuiv().supprOccs(x);
			}else{
				return new Liste(getVal(),suiv.supprOccs(x));
			}
		}
	}

	public Liste supprOccsV2(int x){
		if(estVide()){
			return this;
		} else if(getVal() == x){
			return suiv.supprOccsV2(x);
		}else{
			suiv = suiv.supprOccsV2(x);
			return this;
		}
	}

	public Liste retourne(){
		if(getSuiv().estVide()){
			return this;
		}else {
			Liste suivant = getSuiv().getSuiv();
			getSuiv().suiv = this;
			return suivant.suiv = retourne();
		}
	}

    public static void main(String[] arg){
		Liste l = new Liste();
		l.ajoutTete(1);
		l.ajoutTete(3);
		l.ajoutTete(9);
		l.ajoutFin(0);
		l.ajoutFin(7);
		System.out.println("l : "+l);
		Liste l2 = l.retourne();
		System.out.println("l : "+l2);



	}
}
