<?php

namespace App\EShop\Modele\DataObject;

use App\EShop\Modele\DataObject\AbstractDataObject;

class Commande extends AbstractDataObject
{

    private string $idCommande;
    private string $mail;
    private string $dateCommande;
    private float $prixTotal;

    public function formatTableau(): array
    {
        return array(
            "idCommandeTag" => $this->idCommande,
            "mailTag" => $this->mail,
            "dateCommandeTag" => $this->dateCommande,
            "prixTotalTag" => $this->prixTotal
        );
    }

    public function __construct($idCommande, $mail, $dateCommande, $prixTotal) {
        $this->idCommande = $idCommande;
        $this->mail = $mail;
        $this->dateCommande = $dateCommande;
        $this->prixTotal = $prixTotal;
    }

    public function construireDepuisFormulaire(array $formulaire): Commande
    {
        return new Commande(
            $formulaire['idCommande'],
            $formulaire['mail'],
            $formulaire['dateCommande'],
            $formulaire['prixTotal']
        );
    }

    public function getIdCommande(): string
    {
        return $this->idCommande;
    }

    public function setIdCommande(string $idCommande): void
    {
        $this->idCommande = $idCommande;
    }

    public function getMail(): string
    {
        return $this->mail;
    }

    public function setMail(string $mail): void
    {
        $this->mail = $mail;
    }

    public function getDateCommande(): string
    {
        return $this->dateCommande;
    }

    public function setDateCommande(string $dateCommande): void
    {
        $this->dateCommande = $dateCommande;
    }

    public function getPrixTotal(): float
    {
        return $this->prixTotal;
    }

    public function setPrixTotal(float $prixTotal): void
    {
        $this->prixTotal = $prixTotal;
    }
}