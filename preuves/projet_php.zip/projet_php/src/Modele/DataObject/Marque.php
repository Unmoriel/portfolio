<?php

namespace App\EShop\Modele\DataObject;

class Marque extends AbstractDataObject
{
    private ?int $idMarque;
    private string $nomMarque;
    private string $adresse;
    private string $mail;

    public function formatTableau(): array
    {
        return array(
            "idMarqueTag" => $this->idMarque,
            "nomMarqueTag" => $this->nomMarque,
            "adresseTag" => $this->adresse,
            "mailTag" => $this->mail
        );
    }

    public function __construct($idMarque, $nomMarque, $adresse, $mail)
    {
        $this->idMarque = $idMarque;
        $this->nomMarque = $nomMarque;
        $this->adresse = $adresse;
        $this->mail = $mail;
    }

    public function construireDepuisFormulaire(array $formulaire): Marque
    {
        return new Marque(
            $formulaire['idMarque'],
            $formulaire['nomMarque'],
            $formulaire['adresse'],
            $formulaire['mail']
        );
    }

    public function getIdMarque(): ?int
    {
        return $this->idMarque;
    }

    public function getNomMarque(): string
    {
        return $this->nomMarque;
    }

    public function setNomMarque(string $nomMarque): void
    {
        $this->nomMarque = $nomMarque;
    }

    public function getMail(): string
    {
        return $this->mail;
    }

    public function setMail(string $mail): void
    {
        $this->mail = $mail;
    }

    public function getAdresse(): string
    {
        return $this->adresse;
    }

    public function setAdresse(string $adresse): void
    {
        $this->adresse = $adresse;
    }
}
