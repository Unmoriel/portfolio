<?php
namespace App\EShop\Modele\DataObject;
use App\EShop\Lib\MotDePasse;
use App\EShop\Modele\HTTP\Session;

class Utilisateur extends AbstractDataObject{
    private string $mail;
    private bool $mailVerifie;
    private string $mdpHache;
    private string $nom;
    private string $prenom;
    private string $adresse;
    private string $age;
    private string $sexe;
    private bool $admin;
    private string $nonce;

    public function getNonce(): string
    {
        return $this->nonce;
    }

    public function setNonce(string $nonce): void
    {
        $this->nonce = $nonce;
    }

    /**
     * @return string
     */
    public function getSexe(): string
    {
        return $this->sexe;
    }

    /**
     * @param string $sexe
     */
    public function setSexe(string $sexe): void
    {
        $this->sexe = $sexe;
    }

    /**
     * @return bool
     */
    public function getAdmin(): bool
    {
        return $this->admin;
    }

    /**
     * @param bool $admin
     */
    public function setAdmin(bool $admin): void
    {
        $this->admin = $admin;
    }


    /**
     * @param string $nom
     */
    public function setNom(string $nom): void
    {
        $this->nom = $nom;
    }

    /**
     * @param string $prenom
     */
    public function setPrenom(string $prenom): void
    {
        $this->prenom = $prenom;
    }

    /**
     * @return string
     */
    public function getNom(): string
    {
        return $this->nom;
    }

    /**
     * @return string
     */
    public function getPrenom(): string
    {
        return $this->prenom;
    }

    public function __construct($mail, $mailVerifie, $mdpHache, $nom, $prenom, $adresse, $age, $sexe, $admin, $nonce) {
        $this->mail = $mail;
        $this->mailVerifie = $mailVerifie;
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->mdpHache = $mdpHache;
        $this->adresse = $adresse;
        $this->age = $age;
        $this->sexe = $sexe;
        $this->admin = $admin;
        $this->nonce = $nonce;
    }

    public function getMail(): string
    {
        return $this->mail;
    }

    public function setMail(string $mail): void
    {
        $this->mail = $mail;
    }

    public function getAdresse(): string
    {
        return $this->adresse;
    }

    public function setAdresse(string $adresse): void
    {
        $this->adresse = $adresse;
    }

    public function getAge(): string
    {
        return $this->age;
    }

    public function setAge(string $age): void
    {
        $this->age = $age;
    }

    /**
     * @return string
     */
    public function getMdpHache(): string
    {
        return $this->mdpHache;
    }

    /**
     * @param string $mdpHache
     */
    public function setMdpHache(string $mdpHache): void
    {
        $this->mdpHache = $mdpHache;
    }

    /**
     * @return bool
     */
    public function isMailVerifie(): bool
    {
        return $this->mailVerifie;
    }

    /**
     * @param bool $mailVerifie
     */
    public function setMailVerifie(bool $mailVerifie): void
    {
        $this->mailVerifie = $mailVerifie;
    }

    public function formatTableau(): array
    {
        return  array(
            "mailTag" => $this->mail,
            "mailVerifieTag" => $this->mailVerifie ? 1 : 0, //Mysql gère les booléens comme des entiers
            "nomTag" => $this->nom,
            "prenomTag" => $this->prenom,
            "mdpHacheTag" => $this->mdpHache,
            "adresseTag" => $this->adresse,
            "ageTag" => $this->age,
            "sexeTag" => $this->sexe,
            "adminTag" => $this->admin ? 1 : 0,
            "nonceTag" => $this->nonce
        );
    }

    public static function construireDepuisFormulaire (array $tableauFormulaire) : Utilisateur
    {
        return new Utilisateur(
            $tableauFormulaire['mail'],
            $tableauFormulaire['mailVerifie'],
            (new MotDePasse())->hacher($tableauFormulaire['mdp']),
            $tableauFormulaire['nom'],
            $tableauFormulaire['prenom'],
            $tableauFormulaire['adresse'],
            $tableauFormulaire['age'],
            $tableauFormulaire['sexe'],
            $tableauFormulaire['admin'],
            $tableauFormulaire['nonce']);
    }
}
?>

