<?php
namespace App\EShop\Modele\DataObject;
class Chaussure extends AbstractDataObject{

    private ?int $idChaussure;
    private string $modele;
    private string $pointure;
    private string $cible;
    private string $categorie;
    private float $prix;
    private string $idMarque;
    private ?string $imageUrl;


    public function formatTableau(): array
    {
        return array(
            "idChaussureTag" => $this->idChaussure,
            "modeleTag" => $this->modele,
            "pointureTag" => $this->pointure,
            "cibleTag" => $this->cible,
            "categorieTag" => $this->categorie,
            "prixTag" => $this->prix,
            "idMarqueTag" => $this->idMarque,
            "imageUrlTag" => $this->imageUrl
        );
    }

    public function __construct($idChaussure, $modele, $pointure, $cible, $categorie, $prix, $idMarque, $imageUrl) {
        $this->idChaussure = $idChaussure;
        $this->modele = $modele;
        $this->pointure = $pointure;
        $this->cible = $cible;
        $this->categorie = $categorie;
        $this->prix = $prix;
        $this->idMarque = $idMarque;
        $this->imageUrl = $imageUrl;
    }

    public function construireDepuisFormulaire(array $formulaire): Chaussure
    {
        return new Chaussure(
            $formulaire['idChaussure'],
            $formulaire['modele'],
            $formulaire['pointure'],
            $formulaire['cible'],
            $formulaire['categorie'],
            $formulaire['prix'],
            $formulaire['idMarque'],
            $formulaire['imageUrl']
        );
    }

    public function getimageUrl(): ?string
    {
        return $this->imageUrl;
    }

    public function setimageUrl(?string $imageUrl): void
    {
        $this->imageUrl = $imageUrl;
    }

    public function getIdChaussure(): ?int
    {
        return $this->idChaussure;
    }

    public function getModele(): string
    {
        return $this->modele;
    }

    public function setModele(string $modele): void
    {
        $this->modele = $modele;
    }

    public function getPointure(): string
    {
        return $this->pointure;
    }

    public function setPointure(string $pointure): void
    {
        $this->pointure = $pointure;
    }

    public function getCible(): string
    {
        return $this->cible;
    }

    public function setCible(string $cible): void
    {
        $this->cible = $cible;
    }

    public function getCategorie(): string
    {
        return $this->categorie;
    }

    public function setCategorie(string $categorie): void
    {
        $this->categorie = $categorie;
    }

    public function getPrix(): float
    {
        return $this->prix;
    }

    public function setPrix(float $prix): void
    {
        $this->prix = $prix;
    }

    public function getIdMarque(): string
    {
        return $this->idMarque;
    }

    public function setIdMarque(string $idMarque): void
    {
        $this->idMarque = $idMarque;
    }


}
?>

