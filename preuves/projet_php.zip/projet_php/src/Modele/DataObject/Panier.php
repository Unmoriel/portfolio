<?php

namespace App\EShop\Modele\DataObject;

use App\EShop\Lib\ConnexionUtilisateur;
use App\EShop\Modele\HTTP\Session;
use App\EShop\Modele\Repository\ChaussureRepository;

class Panier
{
    private $listeIdChaussures = [];
    private $loginClient;
    private function __construct()
    {
        $this->loginClient = ConnexionUtilisateur::getLoginUtilisateurConnecte(); //Null si l'utilisateur n'est pas connecté
    }

    public static function getPanier()
    {
        $session = Session::getInstance();
        if ($session->contient("panier")) {
            return unserialize($session->lire("panier"));
        } else {
            $panier = new Panier();
            $session->enregistrer("panier", serialize($panier));
            return $panier;
        }
    }

    public function sauvegarder()
    {
        $session = Session::getInstance();
        $session->enregistrer("panier", serialize($this));
    }

    public function getLoginClient()
    {
        return $this->loginClient;
    }

    public function setLoginClient($loginClient)
    {
        $this->loginClient = $loginClient;
        $this->sauvegarder();
    }

    public function ajouter($idChaussure)
    {
        if(isset($this->listeIdChaussures[$idChaussure])) {
            $this->listeIdChaussures[$idChaussure]++;
        }else {
            $this->listeIdChaussures[$idChaussure] = 1;
        }
        $this->sauvegarder();
    }

    public function retirer($idChaussure)
    {
        if(isset($this->listeIdChaussures[$idChaussure])) {
            unset($this->listeIdChaussures[$idChaussure]);
        }
        $this->sauvegarder();
    }

    public function getListeIdChaussures(): array
    {
        return $this->listeIdChaussures;
    }

    public function vider()
    {
        $this->listeIdChaussures = [];
        $this->sauvegarder();
    }

    public function nbProduits(): int
    {
        return count($this->listeIdChaussures);
    }

    public function getPrixTotal(): float
    {
        $prixTotal = 0;
        foreach ($this->listeIdChaussures as $idChaussure => $quantite) {
            $prixTotal += (new ChaussureRepository())->recupererParClePrimaire($idChaussure)->getPrix() * $quantite;
        }
        return $prixTotal;
    }
}