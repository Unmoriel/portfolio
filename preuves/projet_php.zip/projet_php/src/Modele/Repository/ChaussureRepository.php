<?php

namespace App\EShop\Modele\Repository;
    use App\EShop\Controleur\ControleurGenerique;
    use App\EShop\Modele\DataObject\Chaussure;

class ChaussureRepository extends AbstractRepository{

    public  function getNomTable() : string {
        return "v_Chaussure";
    }

    public function recupererCategories()
    {
        $sql = "SELECT DISTINCT categorie FROM v_Chaussure";
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);
        $pdoStatement->execute();
        return $pdoStatement->fetchAll(); //fetchAll retourne un tableau de tableau
    }

    public function recupererPointures()
    {
        $sql = "SELECT DISTINCT pointure FROM v_Chaussure";
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);
        $pdoStatement->execute();
        return $pdoStatement->fetchAll(); //fetchAll retourne un tableau de tableau
    }

    public function recupererIdMarque()
    {
        $sql = "SELECT DISTINCT idMarque FROM v_Chaussure";
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);
        $pdoStatement->execute();
        return $pdoStatement->fetchAll(); //fetchAll retourne un tableau de tableau
    }

    public function recupererCibles()
    {
        $sql = "SELECT DISTINCT cible FROM v_Chaussure";
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);
        $pdoStatement->execute();

        $resultats = array(); // Initialisez un tableau pour stocker les résultats

        // Utilisez fetch pour récupérer chaque ligne
        while ($row = $pdoStatement->fetch()) {
            // Ajoutez la ligne au tableau des résultats
            $resultats[] = $row['cible'];
        }

        // Retournez le tableau des résultats
        return $resultats;
    }



    protected function construireDepuisTableau(array $produitFormatTableau) : Chaussure
    {
        return new Chaussure(
            $produitFormatTableau['idChaussure'] ?? null,
            $produitFormatTableau['modele'],
            $produitFormatTableau['pointure'],
            $produitFormatTableau['cible'],
            $produitFormatTableau['categorie'],
            $produitFormatTableau['prix'],
            $produitFormatTableau['idMarque'],
            $produitFormatTableau['imageUrl'] ?? null
        );
    }

    public function supprimerParClePrimaire(int $idChaussure)
    {
        $sql = "DELETE FROM v_Chaussure WHERE idChaussure = :idChaussure";
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);
        $pdoStatement->execute([":idChaussure" => $idChaussure]);
    }


    protected function getNomClePrimaire(): string
    {
        return "idChaussure";
    }

    protected function getNomsColonnes(): array
    {
       return ["idChaussure", "modele", "pointure", "cible", "categorie", "prix", "idMarque", "imageUrl"];
    }

    public function filtrerEtTrier(array $filtres, array $tris): array
    {
        $sql = "SELECT * FROM v_Chaussure";

        // Ajouter les conditions de filtre à la requête
        if (!empty($filtres)) {
            $sql .= " WHERE " . implode(" AND ", $this->genererConditionsFiltres($filtres));
        }

        // Ajouter les conditions de tri à la requête
        if (!empty($tris)) {$sql .= " ORDER BY " . implode(", ", $this->genererConditionsTris($tris));
        }
            $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);

        $pdoStatement->execute();

        return $pdoStatement->fetchAll();
    }

    private function genererConditionsFiltres(array $filtres): array
    {
        $conditions = [];
        foreach ($filtres as $filtre => $valeur) {
            $conditions[] = "$filtre = '$valeur'";
        }
        return $conditions;
    }


    private function genererConditionsTris(array $tris): array
    {
        $conditions = [];
        foreach ($tris as $tri => $ordre) {
            $conditions[] = "$tri $ordre";
        }
        return $conditions;
    }



}