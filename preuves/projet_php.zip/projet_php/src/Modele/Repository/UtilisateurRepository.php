<?php

namespace App\EShop\Modele\Repository;
use App\EShop\Modele\DataObject\Utilisateur;

class UtilisateurRepository extends AbstractRepository{

    public function getNomTable() : string {
        return "v_Utilisateurs";
    }
    protected function construireDepuisTableau(array $utilisateurFormatTableau) : Utilisateur
    {
        return new Utilisateur(
            $utilisateurFormatTableau['mail'],
            $utilisateurFormatTableau['mailVerifie'],
            $utilisateurFormatTableau['mdpHache'],
            $utilisateurFormatTableau['nom'],
            $utilisateurFormatTableau['prenom'],
            $utilisateurFormatTableau['adresse'],
            $utilisateurFormatTableau['age'],
            $utilisateurFormatTableau['sexe'],
            $utilisateurFormatTableau['admin'],
            $utilisateurFormatTableau['nonce']);
    }

    protected function getNomClePrimaire(): string
    {
        return "mail";
    }

    protected function getNomsColonnes(): array
    {
        return ["mail", "mailVerifie", "mdpHache", "nom", "prenom", "adresse", "age", "sexe", "admin", "nonce"];
    }

    public function trier($tris): array{
        $sql = "SELECT * FROM v_Utilisateurs";

        if (!empty($tris)) {$sql .= " ORDER BY " . implode(", ", $this->genererConditionsTris($tris));
        }
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);

        $pdoStatement->execute();

        return $pdoStatement->fetchAll();
    }
    private function genererConditionsTris(array $tris): array
    {
        $conditions = [];
        foreach ($tris as $tri => $ordre) {
            $conditions[] = "$tri $ordre";
        }
        return $conditions;
    }
}