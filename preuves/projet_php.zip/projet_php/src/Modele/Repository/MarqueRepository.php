<?php

namespace App\EShop\Modele\Repository;

use App\EShop\Modele\DataObject\Marque; // Assurez-vous d'importer la classe Marque appropriée

class MarqueRepository extends AbstractRepository
{
    public function getNomTable(): string
    {
        return "v_Marques ";
    }

    protected function construireDepuisTableau(array $marqueFormatTableau): Marque
    {
        // Remplacez les clés du tableau avec les noms appropriés de vos colonnes dans la table MarquesChaussure
        return new Marque(
            $marqueFormatTableau['idMarque'] ?? null,
            $marqueFormatTableau['nomMarque'],
            $marqueFormatTableau['adresse'],
            $marqueFormatTableau['mail'],
        );
    }

    protected function getNomClePrimaire(): string
    {
        return "idMarque";
    }

    protected function getNomsColonnes(): array
    {
        return ["idMarque", "nomMarque", "adresse", "mail"];
    }

    public function getNomParId($idMarque): string
    {
        $sql = "SELECT nomMarque FROM v_Marques WHERE idMarque = :idMarque";
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);
        $pdoStatement->bindValue(":idMarque", $idMarque);
        $pdoStatement->execute();
        $nomMarque = $pdoStatement->fetchColumn();

        return $nomMarque;
    }

    public function recupererParId($idMarque): ?Marque
    {
        $sql = "SELECT * FROM v_Marques WHERE idMarque = :idMarque";
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);
        $pdoStatement->bindValue(":idMarque", $idMarque); //bind value permet de sécuriser la requête
        $pdoStatement->execute();
        $marque = $pdoStatement->fetch();
        if ($marque === false) {
            return null;
        }
        else{
            return $this->construireDepuisTableau($marque);
        }

    }

}
