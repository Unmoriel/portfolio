<?php

namespace App\EShop\Modele\Repository;

use App\EShop\Modele\DataObject\AbstractDataObject;
use App\EShop\Modele\DataObject\Commande;

class   CommandeRepository extends AbstractRepository
{
    public  function getNomTable() : string {
        return "v_Commande";
    }
    protected function construireDepuisTableau(array $commandeFormatTableau) : Commande
    {
        return new Commande(
            $commandeFormatTableau['idCommande'],
            $commandeFormatTableau['mail'],
            $commandeFormatTableau['dateCommande'],
            $commandeFormatTableau['prixTotal']);
    }

    protected function getNomClePrimaire(): string
    {
        return "idCommande";
    }

    protected function getNomsColonnes(): array
    {
        return ["idCommande", "mail", "dateCommande", "prixTotal"];
    }

    public function recuperer() : array
    {
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->query(
            "SELECT * FROM {$this->getNomTable()} ORDER BY dateCommande DESC");
        $tab = [];
        foreach ($pdoStatement as $formatTableau) {
            $tab[] = $this->construireDepuisTableau($formatTableau);
        }
        return $tab;
    }

    public function recupererParLogin($mail) : array
    {
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare(
            "SELECT * FROM {$this->getNomTable()} WHERE mail = :mailTag ORDER BY dateCommande DESC");
        $pdoStatement->execute(['mailTag' => $mail]);
        $tab = [];
        foreach ($pdoStatement as $formatTableau) {
            $tab[] = $this->construireDepuisTableau($formatTableau);
        }
        return $tab;
    }

    public function sauvegarderAvecChaussures(Commande $commande, array $tabChaussures): void
    {
        parent::sauvegarder($commande);
        $requete = "INSERT INTO v_DetailCommande (idDetail, idCommande, idChaussure, quantitee)
                    VALUES (:idDetailTag, :idCommandeTag, :idChaussureTag, :quantiteTag)";
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($requete);
        foreach ($tabChaussures as $idChaussure => $quantite) {
            $pdoStatement->execute([
                'idDetailTag' => uniqid('dtl_'),
                'idCommandeTag' => $commande->getIdCommande(),
                'idChaussureTag' => $idChaussure,
                'quantiteTag' => $quantite
            ]);

        }
    }

    public function trier($tris): array{
        $sql = "SELECT * FROM v_Commande";

        if (!empty($tris)) {$sql .= " ORDER BY " . implode(", ", $this->genererConditionsTris($tris));
        }
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($sql);

        $pdoStatement->execute();

        return $pdoStatement->fetchAll();
    }

    private function genererConditionsTris(array $tris): array
    {
        $conditions = [];
        foreach ($tris as $tri => $ordre) {
            $conditions[] = "$tri $ordre";
        }
        return $conditions;
    }

    public function recupererIdChaussureQuantiteParIdCommande($idCommande): array
    {
        $requete = "SELECT dc.idChaussure, dc.quantitee
                    FROM v_DetailCommande dc
                    WHERE dc.idCommande = :idCommandeTag;";
        $pdoStatement = ConnexionBaseDeDonnee::getPdo()->prepare($requete);
        $pdoStatement->execute(['idCommandeTag' => $idCommande]);
        $tabChaussure = [];
        foreach ($pdoStatement as $formatTableau) {
            $tabChaussure[$formatTableau['idChaussure']] = $formatTableau['quantitee'];
        }
        return $tabChaussure;
    }
}