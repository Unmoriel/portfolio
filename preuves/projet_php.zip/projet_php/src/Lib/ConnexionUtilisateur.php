<?php
namespace App\EShop\Lib;

use App\EShop\Controleur\ControleurUtilisateur;
use App\EShop\Modele\HTTP\Session;
use App\EShop\Modele\Repository\ConnexionBaseDeDonnee;
use App\EShop\Modele\Repository\UtilisateurRepository;

class ConnexionUtilisateur
{
    // L'utilisateur connecté sera enregistré en session associé à la clé suivante
    private static string $cleConnexion = "utilisateurConnecte";

    public static function connecter(string $loginUtilisateur): void
    {
        // À compléter
    }

    public static function estConnecte(): bool
    {
        $session = Session::getInstance();
        return $session->contient(ConnexionUtilisateur::$cleConnexion);
    }

    public static function deconnecter(): void
    {
        $session = Session::getInstance();
        $session->supprimer(ConnexionUtilisateur::$cleConnexion);
    }

    public static function getLoginUtilisateurConnecte(): ?string
    {
        $session = Session::getInstance();
        if (ConnexionUtilisateur::estConnecte()){
            $utilisateur = $session->lire(ConnexionUtilisateur::$cleConnexion);
            return $utilisateur->getMail();
        }else{
            return null;
        }
    }

    public static function estAdmin(): bool
    {
        $session = Session::getInstance();
        if(ConnexionUtilisateur::estConnecte()){
            $utilisateur = $session->lire(ConnexionUtilisateur::$cleConnexion);
            if($utilisateur->getAdmin()){
                return true;
            }
        }
        return false;
    }

    public static function estUtilisateur($login): bool
    {
        if(ConnexionUtilisateur::estConnecte()){
            if(ConnexionUtilisateur::getLoginUtilisateurConnecte() == $login){
                return true;
            }
        }
        return false;

    }
}

