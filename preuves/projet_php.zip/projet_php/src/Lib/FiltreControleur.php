<?php
namespace App\EShop\Lib;

use App\EShop\Modele\DataObject\Chaussure;
use App\EShop\Modele\HTTP\Cookie;
use App\EShop\Modele\Repository\ChaussureRepository;

class FiltreControleur {
    public static function existe(array $nomFiltre): bool
    {
        $n = count($nomFiltre);
        for ($i = 0; $i < $n; $i++) {
            if (Cookie::contient($nomFiltre[$i]) && Cookie::lire($nomFiltre[$i]) != "Aucune Preferences") {
                return true;
            }
        }
        return false;
    }

    public static function lire(array $nomFiltre): array
    {
        for ($i = 0; $i < count($nomFiltre); $i++) {
            if (Cookie::contient($nomFiltre[$i])) {
                $filtre[$nomFiltre[$i]] = Cookie::lire($nomFiltre[$i]);
            }
        }
        return $filtre;
    }

    public static function enregistrer(array $filtre, array $nomFiltre): void
    {
        for ($i = 0; $i < count($nomFiltre); $i++) {
            if (isset($filtre[$nomFiltre[$i]])) {
                Cookie::enregistrer($nomFiltre[$i], $filtre[$nomFiltre[$i]]);
            }
        }
    }

    public static function supprimer(array $nomFiltre): void
    {
        for ($i = 0; $i < count($nomFiltre); $i++) {
            if (Cookie::contient($nomFiltre[$i])) {
                Cookie::supprimer($nomFiltre[$i]);
            }
        }
    }



}
?>
