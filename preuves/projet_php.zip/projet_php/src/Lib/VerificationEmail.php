<?php

namespace App\EShop\Lib;

use App\EShop\Configurations\ConfigurationSite;
use App\EShop\Modele\DataObject\Utilisateur;
use App\EShop\Modele\Repository\UtilisateurRepository;

class VerificationEmail
{
    public static function envoiEmailValidation(Utilisateur $utilisateur): void
    {
        $loginURL = rawurlencode($utilisateur->getMail());
        $nonceURL = rawurlencode($utilisateur->getNonce());
        $URLAbsolue = ConfigurationSite::getURLAbsolue();
        $lienValidationEmail = "$URLAbsolue?action=validerEmail&controleur=utilisateur&mail=$loginURL&nonce=$nonceURL";
        $corpsEmail = "<a href=\"$lienValidationEmail\">-->Valider votre adresse mail<--</a>";
        $destinataire = "huiklmop@yopmail.com";
        $sujet = "Validation de l'adresse email";
        // Pour envoyer un email contenant du HTML
        $enTete = "MIME-Version: 1.0" . "\r\n";
        $enTete .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        mail($destinataire, $sujet, $corpsEmail, $enTete);

    }

    public static function traiterEmailValidation($mail, $nonce): bool
    {
        $utilisateur = (new UtilisateurRepository())->recupererParClePrimaire($mail);
        if($utilisateur != null && $utilisateur->getNonce() == $nonce) {
            $utilisateur->setMailVerifie(true);
            $utilisateur->setNonce("");
            (new UtilisateurRepository())->mettreAJour($utilisateur);
            return true;
        }
        return false;
    }

    public static function envoiEmailReinitialisationMDP(Utilisateur $utilisateur): void
    {
        $mailURL = rawurlencode($utilisateur->getMail());
        $nonceURL = rawurlencode($utilisateur->getNonce());
        $URLAbsolue = ConfigurationSite::getURLAbsolue();
        $lienReinitialisationMDP = "$URLAbsolue?action=afficherFormulaireChoixNouveauMDP&controleur=utilisateur&mail=$mailURL&nonce=$nonceURL";
        $corpsEmail = "<a href=\"$lienReinitialisationMDP\">-->Réinitialiser votre mot de passe<--</a>";
        $destinataire = "huiklmop@yopmail.com";
        $sujet = "Réinitialisation du mot de passe";
        $enTete = "MIME-Version: 1.0" . "\r\n";
        $enTete .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        mail($destinataire, $sujet, $corpsEmail, $enTete);
    }

    public static function traiterEmailReinitialisationMDP($mail, $nonce): bool
    {
        $utilisateur = (new UtilisateurRepository())->recupererParClePrimaire($mail);
        if(!($utilisateur->getNonce() == "")){ //Si le nonce == "" alors c'est qu'il n'y a pas eu de demande de réinitialisation de mot de passe
            return ($utilisateur->getNonce() == $nonce); //Le changement du nonce en "" se fait dans le controleur (pour éviter de réécraser le changement
        }
        return false;
    }



    public static function aValideEmail(Utilisateur $utilisateur) : bool
    {
        return $utilisateur->isMailVerifie();
    }
}