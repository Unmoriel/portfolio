<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php
        /** @var string $pagetitle */
        use App\EShop\Lib\ConnexionUtilisateur;
        echo $pagetitle; ?></title>
    <style>
        <?php require __DIR__ . "/../../ressources/css/style.css"; ?>
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
<header>
    <nav>
            <ul>
                <?php
                if(!ConnexionUtilisateur::estConnecte()){
                    echo '<li><a href="controleurFrontal.php?action=afficherliste&controleur=chaussure">Liste des produits</a></li>';
                    echo '<li><a href="controleurFrontal.php?action=afficherpanier&controleur=panier">Panier</a></li>';
                    echo '<li><a href="controleurFrontal.php?action=afficherFormulaireConnexion&controleur=utilisateur">Connexion</a></li>';
                    echo '<li><a href="controleurFrontal.php?action=afficherFormulaireCreation&controleur=utilisateur">Inscription</a></li>';
                }else{
                    if (!ConnexionUtilisateur::estAdmin()) {//Connecté mais pas admin
                        echo '<li><a href="controleurFrontal.php?action=afficherliste&controleur=chaussure">Liste des produits</a></li>';
                        echo '<li><a href="controleurFrontal.php?action=afficherpanier&controleur=panier">Panier</a></li>';
                        echo '<li class="deroulant">
                                <a href="controleurFrontal.php?action=afficherDetail&controleur=utilisateur&mail=' . ConnexionUtilisateur::getLoginUtilisateurConnecte() . '">Mon compte</a>
                                <ul class="sous">
                                    <li><a href="controleurFrontal.php?action=afficherCommandeParLogin&controleur=commande">Mes commandes</a></li>
                                </ul>
                              </li>';
                        echo '<li><a href="controleurFrontal.php?action=deconnexion&controleur=utilisateur">Déconnexion</a></li>';
                    } else {
                        echo '<li><a href="controleurFrontal.php?action=afficherliste&controleur=chaussure">Liste des produits</a></li>';
                        echo '<li><a href="controleurFrontal.php?action=afficherpanier&controleur=panier">Panier</a></li>';
                        echo '<li class="deroulant">
                                <a>Administration</a>
                                <ul class="sous">
                                    <li><a href="controleurFrontal.php?action=gererUtilisateur&controleur=utilisateur">Gerer les utilisateurs</a></li>
                                    <li><a href="controleurFrontal.php?action=gererChaussures&controleur=chaussure">Gerer les chaussures</a></li>
                                    <li><a href="controleurFrontal.php?action=gererCommandes&controleur=commande">Gerer les commandes</a> </li>
                                    <li><a href="controleurFrontal.php?action=gererMarques&controleur=marque">Gerer les marques</a></li>
                                </ul>
                              
                              </li>';
                        echo '<li class="deroulant">
                                <a href="controleurFrontal.php?action=afficherDetail&controleur=utilisateur&mail=' . ConnexionUtilisateur::getLoginUtilisateurConnecte() . '">Mon compte</a>
                                <ul class="sous">
                                    <li><a href="controleurFrontal.php?action=afficherCommandeParLogin&controleur=commande">Mes commandes</a></li>
                                </ul>
                              </li>';
                        echo '<li><a href="controleurFrontal.php?action=deconnexion&controleur=utilisateur">Déconnexion</a></li>';
                        }
                    }
                ?>

            </ul>
    </nav>
    <div>
        <?php
        /** @var string[][] $messagesFlash */
        foreach($messagesFlash as $type => $messagesFlashPourUnType) {
            // $type est l'une des valeurs suivantes : "success", "info", "warning", "danger"
            // $messagesFlashPourUnType est la liste des messages flash d'un type
            foreach ($messagesFlashPourUnType as $messageFlash) {
                echo <<< HTML
            <div class="alert alert-$type">
               $messageFlash
            </div>
            HTML;
            }
        }
        ?>
    </div>
</header>
<main>
    <?php
    /** @var string $cheminVueBody */
    require __DIR__ . "/{$cheminVueBody}";
    ?>
</main>
<footer>
    <p>Site de EShop d'Alexandre, Aurel, Ilias. </p>
</footer>
</body>
</html>

