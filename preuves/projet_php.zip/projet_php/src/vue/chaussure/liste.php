<body>
<button onclick='window.location.href="?action=afficherFormulairePreference&controleur=chaussure"'>Filtres</button>
<button onclick='window.location.href="?action=supprimerPreference&controleur=generique&redirection=chaussure&nomFiltre=marque,cible,prix,taille"'>Supprimer les filtres</button>

<div class="container py-5 bg-light">
    <h2 class="display-4 text-center mb-5">Nos Baskets :</h2>

    <div class="row">
        <?php
        use App\EShop\Lib\FiltreControleur;
        use App\EShop\Modele\DataObject\Chaussure;
        use App\EShop\Modele\Repository\ChaussureRepository;

        // Prise en compte du filtre
        if (FiltreControleur::existe(["marque", "cible", "prix", "taille"])) {
            $preference = FiltreControleur::lire(["marque", "cible", "prix", "taille"]);
            $marque = $preference["marque"] ?? null;
            $cible = $preference["cible"] ?? null;
            $prix = isset($preference["prix"]) ? ($preference["prix"] == "croissant" ? "ASC" : "DESC") : null;
            $taille = isset($preference["taille"]) ? ($preference["taille"] == "croissant" ? "ASC" : "DESC") : null;

            if($marque != null)
                $filtre = ["idMarque" => $marque];
            else
                $filtre = [];
            $filtre = ["cible" => $cible] + $filtre;
            $tris = ["prix" => $prix, "pointure" => $taille];
            $filtre = array_filter($filtre, function ($value) {
                return $value !== null;
            });
            $tris = array_filter($tris, function ($value) {
                return $value !== null;
            });
            $produitsT = (new ChaussureRepository())->filtrerEtTrier($filtre, $tris);
            foreach ($produitsT as $produit) {
                $nom = $produit['modele'];
                $idChaussure = $produit['idChaussure'];
                $url = $produit['imageUrl'];
                $urlImg = "<img src='{$url}' alt='{$nom}' class='img-list'>";
                $prix = $produit['prix'];
                $idChaussureHTML = htmlspecialchars($idChaussure);

                echo "<div class=\"col-md-4 col-sm-6\">
                        <div class=\"card mb-4 shadow-sm\">
                            {$urlImg}
                            <div class=\"card-body\">
                                <p class=\"card-text\">
                                    {$nom}
                                </p>
                                <p class=\"card-text\">
                                    {$prix} €            
                                </p>
                                <div class=\"btn-group\">
                                    <button type=\"button\" class=\"btn btn-sm btn-outline-secondary ml-1\">
                                        <a href='?action=ajouterPanier&controleur=panier&idChaussure={$idChaussureHTML}'>Ajouter au panier</a>
                                    </button>
                                    <button type=\"button\" class=\"btn btn-sm btn-outline-secondary ml-1\">
                                        <a href='?action=afficherDetail&controleur=chaussure&idChaussure={$idChaussureHTML}'>En savoir plus</a>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>";
            }

        }
        else {
            /** @var Chaussure[] $produits */
            $produitsT = $produits;
            foreach ($produitsT as $produit) {
                $nom = $produit->getModele();
                $idChaussure = $produit->getIdChaussure();
                $url = $produit->getimageUrl();
                $urlImg = "<img src='{$url}' alt='{$nom}' class='img-list'>";
                $prix = $produit->getPrix();
                $idChaussureHTML = htmlspecialchars($idChaussure);

                echo "<div class=\"col-md-4 col-sm-6\">
                        <div class=\"card mb-4 shadow-sm\">
                            {$urlImg}
                            <div class=\"card-body\">
                                <p class=\"card-text\">
                                    {$nom}
                                </p>
                                <p class=\"card-text\">
                                    {$prix} €            
                                </p>
                                <div class='btn-group'>
                                    <a href='?action=ajouterPanier&controleur=panier&idChaussure={$idChaussureHTML}' class=\"btn btn-outline-primary\">Ajouter au panier</a>
                                    <a href='?action=afficherDetail&controleur=chaussure&idChaussure={$idChaussureHTML}' class=\"btn btn-outline-primary\">En savoir plus</a>
                                </div>
                            </div>
                        </div>
                    </div>";
            }
        }
        ?>
    </div>
</div>

