<body>
<form>
    <fieldset>
        <legend>Filtre</legend>
        <p>
            <input type="hidden" name="action" value="enregistrerPreference">
            <input type="hidden" name="nomFiltre" value="marque,cible,prix,taille">
            <input type="hidden" name="redirection" value="GererChaussure">
        </p>
        <?php
        use App\EShop\Lib\FiltreControleur;

        if (FiltreControleur::existe(["marque", "cible", "prix", "taille"])) {
            $preference = FiltreControleur::lire(["marque", "cible", "prix", "taille"]);
        } else {
            $preference = [];
        }
        echo "<p><label>Cible</label></p><p>";
        // Filtre par genre
        /** @var $cibles */
        echo "<select name='cible'>";
        echo "<option selected>Aucune Preferences</option>";
        for($i = 0; $i < count($cibles); $i++)
        {
            if(isset($preference["cible"]) && $preference["cible"] == $cibles[$i])
            {
                echo "<option value='{$cibles[$i]}' selected>{$cibles[$i]}</option>";
            }
            else
            {
                echo "<option value='{$cibles[$i]}'>{$cibles[$i]}</option>";
            }
        }
        echo "</select></p>";

        echo "<p><label>Marque</label></p><p>";
        // Filtre par marque
        echo "<select name='marque'>";
        /** @var Marque[] $marques */
        echo "<option selected>Aucune Preferences</option>";
        foreach ($marques as $marque) {
            if (isset($preference["marque"]) && $preference["marque"] == $marque->getIdMarque()) {
                echo "<option value='{$marque->getIdMarque()}' selected>{$marque->getNomMarque()}</option>";
            } else {
                echo "<option value='{$marque->getIdMarque()}'>{$marque->getNomMarque()}</option>";
            }
        }
        echo "</select></p>";

        echo "<p><label>Pointure</label></p><p>";
        // Filtrer par Pointure
        if (isset($preference["taille"]) && $preference["taille"] == "croissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="taille" value="croissant" checked></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="taille" value="decroissant"></p>';
        }
        else if (isset($preference["taille"]) && $preference["taille"] == "decroissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="taille" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="taille" value="decroissant" checked></p>';
        }
        else
        {
            echo '<p><label> Croissante</label><input type="radio" name="taille" value="croissant"></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="taille" value="decroissant"></p>';
        }
        echo "</p>";
        // Filtrer par prix croissant ou décroissant
        echo "<p><label>Prix</label></p><p>";
        if (isset($preference["prix"]) && $preference["prix"] == "croissant")
        {
            echo '<p><label> Croissant</label><input type="radio" name="prix" value="croissant" checked></p>';
            echo '<p><label> Décroissant</label><input type="radio" name="prix" value="decroissant" ></p>';
        }
        else if (isset($preference["prix"]) && $preference["prix"] == "decroissant")
        {
            echo '<p><label> Croissant</label><input type="radio" name="prix" value="croissant"></p>';
            echo '<p><label> Décroissant</label><input type="radio" name="prix" value="decroissant" checked></p>';
        }
        else
        {
            echo '<p><label> Croissant</label><input type="radio" name="prix" value="croissant"></p>';
            echo '<p><label> Décroissant</label><input type="radio" name="prix" value="decroissant"></p>';
        }
        echo "</p>";


        ?>
        <p>
            <input type="submit" value="Enregistrer">
        </p>
    </fieldset>
</form>
</body>
