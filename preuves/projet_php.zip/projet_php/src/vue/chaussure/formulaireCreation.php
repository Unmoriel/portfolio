<form method="post" action="?action=creerDepuisFormulaire&controleur=chaussure">
    <fieldset>
        <legend>Ajouter une chaussure :</legend>
        <div>
            <input type="hidden" name="action" value="creerDepuisFormulaire"/>
            <input type="hidden" name="controleur" value="chaussure"/>
        </div>


        <div class="form-floating">
            <input type="text" class="form-control" name="modele" id="modele_id" placeholder="Nom de la chaussure" required/>
            <label for="modele_id">Modele</label>
        </div>

        <div class="form-floating">
            <select class="form-select" id="marque_id" name="idMarque">
                <?php
                /** @var array $marques */

                foreach ($marques as $idMarque => $nomMarque) {
                    $idMarqueHTML = htmlspecialchars($idMarque);
                    $nomMarqueHTML = htmlspecialchars($nomMarque);
                    echo "<option value='{$idMarqueHTML}'>{$nomMarqueHTML}</option>";
                }
                ?>
            </select>
            <label for="marque_id">Marque</label>
        </div>

        <div class="form-floating">
            <select class="form-select" id="categorie_id" name="categorie">
                <option value="Course à pied">Course à pied</option>
                <option value="Tennis">Tennis</option>
                <option value="Basket">Basket</option>
                <option value="Ville">Ville</option>
                <option value="Chaussons">Chaussons</option>
                <option value="Luxe">Luxe</option>
                <option value="Football">Football</option>
            </select>
            <label for="categorie_id">Categorie</label>
        </div>

        <div class="form-floating">
            <input class="form-control" type="number" name="pointure" id="pointure_id" min="30" max="50" placeholder="40" required/>
            <label for="pointure_id">Pointure</label>
            <div class="form-text">
                De 30 à 50
            </div>
        </div>

        <div class="form-floating">
            <select class="form-select" id="cible_id" name="cible">
                <option value="Homme">Homme</option>
                <option value="Femme">Femme</option>
                <option value="Mixte">Mixte</option>
            </select>
            <label for="cible_id">Cible</label>
        </div>

        <!-- Le prix peut etre un float -->
        <div class="form-floating">
            <input class="form-control" type="number" name="prix" id="prix_id" min="10" max='500' step="0.01" placeholder="99.99" required/>
            <label for="prix_id">Prix</label>
            <div class="form-text">
                Entre 10 et 500
            </div>

        <div class="form-floating">
            <input class="form-control" type="text" name="imageUrl" id="imageUrl_id" placeholder="URL" oninput="checkImage(this)"/>
            <label for="imageUrl_id">URL de l'image</label>
            <div class="form-text">
                Copier l'URL d'une image sur internet et la coller ici
            </div>
        </div>


        <!-- Div pour prévisualiser l'image -->
        <div id="imagePreview"></div>
        <script>
            function checkImage(input) {
                const url = input.value;
                const img = new Image();
                img.src = url;
                img.onload = function () {
                    // L'image est valide, l'afficher
                    document.getElementById('imagePreview').innerHTML = '<img src="' + url + '" alt="Image preview" class="img-fluid" style="max-width: 100%; max-height: 200px;">';
                };
                img.onerror = function () {
                    // L'image n'est pas valide, afficher l'URL par défaut
                    document.getElementById('imagePreview').innerHTML = '<img src="https://static.vecteezy.com/ti/vecteur-libre/p3/6059989-icone-camera-croisee-eviter-de-prendre-des-photos-image-n-est-pas-disponible-illustrationle-gratuit-vectoriel.jpg" alt="Default Image" class="img-fluid" style="max-width: 100%; max-height: 200px;">';
                    input.value = null;
                };
            }

            window.onload = function() { // On prévisualise l'image au chargement de la page
                checkImage(document.getElementById('imageUrl_id'));
            };
        </script>

        <div>
            <input class="btn btn-valide btn-primary" type="submit" value="Enregistrer" />
        </div>
    </fieldset>
</form>

<style>
    .form-floating {
        margin-bottom: 1rem;
        width: 400px;
    }
    .form-select{
        margin-bottom: 1rem;
        width: 400px;
    }
    .btn-valide{
        margin-top: 1rem;
    }
</style>
