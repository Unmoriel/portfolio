<div>
    <h1>Gérer les chaussures</h1>
    <button onclick='window.location.href="?action=afficherFormulaireFiltre&controleur=chaussure"'>Filtres</button>
    <button onclick='window.location.href="?action=supprimerPreference&controleur=generique&redirection=GererChaussure&nomFiltre=marque,cible,prix,taille"'>Supprimer les filtres</button>
    <div>
        <a href="controleurFrontal.php?action=afficherFormulaireCreation&controleur=chaussure">Ajouter une chaussure</a>
    </div>
    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">Modele</th>
            <th scope="col">Marque</th>
            <th scope="col">Prix</th>
            <th scope="col">Pointure</th>
            <th scope="col">Cible</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php
        /** @var array $chaussures
         *  @var array $marques
         * */
        use App\EShop\Lib\FiltreControleur;
        use App\EShop\Modele\Repository\ChaussureRepository;
        if (FiltreControleur::existe(["marque", "cible", "prix", "taille"])) {
            $preference = FiltreControleur::lire(["marque", "cible", "prix", "taille"]);
            $marque = $preference["marque"] ?? null;
            $cible = $preference["cible"] ?? null;
            $prix = isset($preference["prix"]) ? ($preference["prix"] == "croissant" ? "ASC" : "DESC") : null;
            $taille = isset($preference["taille"]) ? ($preference["taille"] == "croissant" ? "ASC" : "DESC") : null;

            if ($marque != null)
                $filtre = ["idMarque" => $marque];
            else
                $filtre = [];
            $filtre = ["cible" => $cible] + $filtre;
            $tris = ["prix" => $prix, "pointure" => $taille];
            $filtre = array_filter($filtre, function ($value) {
                return $value !== null;
            });
            $tris = array_filter($tris, function ($value) {
                return $value !== null;
            });
            $produitsT = (new ChaussureRepository())->filtrerEtTrier($filtre, $tris);
            foreach ($produitsT as $chaussure) {
                $idChaussure = $chaussure['idChaussure'];
                echo "<tr>";
                echo "<td>" . htmlspecialchars($chaussure["modele"]) . "</td>";
                echo "<td>" . htmlspecialchars($marques->getNomParId($chaussure["idMarque"])) . "</td>";
                echo "<td>" . htmlspecialchars($chaussure["prix"]) . "</td>";
                echo "<td>" . htmlspecialchars($chaussure["pointure"]) . "</td>";
                echo "<td>" . $chaussure["cible"] . "</td>";
                echo "<td>
                    <a href='controleurFrontal.php?action=afficherDetail&controleur=chaussure&idChaussure=" . $chaussure["idChaussure"] . "'>Détail</a>
                    <a href='controleurFrontal.php?action=afficherFormulaireModification&controleur=chaussure&idChaussure=" . $chaussure["idChaussure"] . "'>Modifier</a>
                    <a href='controleurFrontal.php?action=supprimer&controleur=chaussure&idChaussure=" . $chaussure["idChaussure"] . "'>Supprimer</a></td>";
                echo "</tr>";
            }
        }
        else {
            $produitsT = $chaussures;
            foreach ($produitsT as $chaussure) {
                $idChaussure = $chaussure['idChaussureTag'];
                echo "<tr>";
                echo "<td>" . htmlspecialchars($chaussure["modeleTag"]) . "</td>";
                echo "<td>" . htmlspecialchars($marques->getNomParId($chaussure["idMarqueTag"])) . "</td>";
                echo "<td>" . htmlspecialchars($chaussure["prixTag"]) . "</td>";
                echo "<td>" . htmlspecialchars($chaussure["pointureTag"]) . "</td>";
                echo "<td>" . $chaussure["cibleTag"] . "</td>";
                echo "<td>
                    <a href='controleurFrontal.php?action=afficherDetail&controleur=chaussure&idChaussure=" . $chaussure["idChaussureTag"] . "'>Détail</a>
                    <a href='controleurFrontal.php?action=afficherFormulaireModification&controleur=chaussure&idChaussure=" . $chaussure["idChaussureTag"] . "'>Modifier</a>
                    <a href='controleurFrontal.php?action=supprimer&controleur=chaussure&idChaussure=" . $chaussure["idChaussureTag"] . "'>Supprimer</a></td>";
                echo "</tr>";
            }
        }
        ?>
        </tbody>
    </table>
</div>