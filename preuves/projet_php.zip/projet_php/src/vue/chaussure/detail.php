<?php
use App\EShop\Modele\DataObject\Chaussure;
use App\EShop\Modele\Repository\MarqueRepository;

/** @var Chaussure $chaussure */
/** @var string $nomMarque */
$modeleHTML = htmlspecialchars($chaussure["modeleTag"]);
$prixHTML = htmlspecialchars($chaussure["prixTag"]);
$pointureHTML = htmlspecialchars($chaussure["pointureTag"]);
$sexeHTML = htmlspecialchars($chaussure["cibleTag"]);
$nomMarqueHTML = htmlspecialchars($nomMarque);
$idChaussure = htmlspecialchars($chaussure["idChaussureTag"]);
$modeleHTML = htmlspecialchars($chaussure["modeleTag"]);
$imageUrlHTML = htmlspecialchars($chaussure["imageUrlTag"]);

echo "<h1>{$modeleHTML} </h1>";
echo "<h3> {$prixHTML} € </h3>";
echo "<img src='{$imageUrlHTML}' alt='{$modeleHTML}' class='img-fluid'>";
echo "<p> Marque : {$nomMarqueHTML} </p>";
echo "<p> Pointure : {$pointureHTML} </p>";
echo "<p> Sexe : {$sexeHTML} </p>";
echo "<p> Modèle : {$modeleHTML} </p>";
?>