<form method="post" action="?action=mettreAJour&controleur=chaussure">
    <fieldset>
        <legend>Modifier une chaussure :</legend>
        <div>
            <input type="hidden" name="action" value="mettreAJour" />
            <input type="hidden" name="controleur" value="chaussure" />
            <input type="hidden" name="idChaussure" value="<?= $chaussure["idChaussureTag"] ?>" />
        </div>


        <div class="form-floating">
            <select class="form-select" id="marque_id" name="idMarque">
                <?php
                /** @var array $marques */

                foreach ($marques as $idMarque => $nomMarque) {
                    $selected = ($idMarque == $chaussure["idMarqueTag"]) ? 'selected' : '';
                    echo "<option value='{$idMarque}' $selected>{$nomMarque}</option>";
                }
                ?>
            </select>
            <label for="marque_id">Marque</label>
        </div>

        <div class="form-floating">
            <input class="form-control" type="text" name="modele" id="modele_id" value="<?= $chaussure["modeleTag"] ?>" required />
            <label for="modele_id">Modèle</label>
        </div>

        <div class="form-floating">
            <select class="form-select" id="categorie_id" name="categorie">
                <?php
                /** @var $categories */
                foreach ($categories as $categorie) {
                    $selected = ($categorie['categorie'] == $chaussure["categorieTag"]) ? 'selected' : '';
                    echo "<option value='{$categorie['categorie']}' $selected>{$categorie['categorie']}</option>";
                }
                ?>
            </select>
            <label for="categorie_id">Catégorie</label>
        </div>

        <div class="form-floating">
            <input class="form-control" type="number" name="pointure" id="pointure_id" value="<?= $chaussure["pointureTag"] ?>" min="30" max="50" required />
            <label for="pointure_id">Pointure</label>
            <span id="pointureHelpInline" class="form-text"> De 30 à 50 </span>
        </div>

        <div class="form-floating">
            <select class="form-select" id="cible_id" name="cible">
                <option value="Homme" <?= ($chaussure["cibleTag"] === 'Homme') ? 'selected' : '' ?>>Homme</option>
                <option value="Femme" <?= ($chaussure["cibleTag"] === 'Femme') ? 'selected' : '' ?>>Femme</option>
                <option value="Mixte" <?= ($chaussure["cibleTag"] === 'Mixte') ? 'selected' : '' ?>>Mixte</option>
            </select>
            <label for="cible_id">Cible</label>
        </div>

        <div class="form-floating">
            <input class="form-control" type="text" name="prix" id="prix_id" pattern="\d+(\.\d{2})?" value="<?= $chaussure["prixTag"] ?>" required />
            <label for="prix_id">Prix</label>
        </div>

        <p>
            <div  class="form-floating">
                <input class="form-control" type="text" name="imageUrl" id="imageUrl_id" value="<?= $chaussure["imageUrlTag"] ?>" oninput="checkImage(this)"/>
                <span id="urlHelpInline" class="form-text"> Copiez collez l'URL de l'image ici </span>
                <label for="imageUrl_id">URL de l'image</label>
            </div>

            <!-- Div pour prévisualiser l'image -->
            <div id="imagePreview"></div>
            <script>
                function checkImage(input) {
                    const url = input.value;
                    const img = new Image();
                    img.src = url;

                    if (img.src === "https://static.vecteezy.com/ti/vecteur-libre/p3/6059989-icone-camera-croisee-eviter-de-prendre-des-photos-image-n-est-pas-disponible-illustrationle-gratuit-vectoriel.jpg") {
                        input.value = null;
                    }

                    img.onload = function () {
                        // L'image est valide, l'afficher
                        document.getElementById('imagePreview').innerHTML = '<img src="' + url + '" alt="Image preview" class="img-fluid" style="max-width: 100%; max-height: 200px;">';
                    };
                    img.onerror = function () {
                        input.value = null;
                        // L'image n'est pas valide, afficher l'URL par défaut
                        document.getElementById('imagePreview').innerHTML = '<img src="https://static.vecteezy.com/ti/vecteur-libre/p3/6059989-icone-camera-croisee-eviter-de-prendre-des-photos-image-n-est-pas-disponible-illustrationle-gratuit-vectoriel.jpg" alt="Default Image" class="img-fluid" style="max-width: 100%; max-height: 200px;">';
                    };
                }

                window.onload = function() { // On prévisualise l'image au chargement de la page
                    checkImage(document.getElementById('imageUrl_id'));
                };
            </script>
        </p>

        <p>
            <input class="btn btn-valide btn-primary" type="submit" value="Enregistrer les modifications" />
        </p>
    </fieldset>
</form>
<style>
    .form-floating {
        margin-bottom: 1rem;
        width: 400px;
    }
    .form-select{
        margin-bottom: 1rem;
        width: 400px;
    }
    .btn-valide{
        margin-top: 1rem;
    }
</style>
