
<div class="container py-5 bg-light">
    <h2 class="display-4 text-center mb-5">Votre Panier</h2>

    <div class="row">
        <?php
        if (empty($chaussures)) {
            echo "<h3 class='text-center'>Votre panier est vide</h3>";
        }else{
            foreach ($chaussures as $idChaussure => $chaussure) {
                $nomHTML = htmlspecialchars($chaussure["modeleTag"]);
                $idChaussureHTML = htmlspecialchars($chaussure["idChaussureTag"]);
                $urlImgHTML = htmlspecialchars($chaussure["imageUrlTag"]);
                $prixHTML = htmlspecialchars($chaussure["prixTag"]);

                echo "<div class=\"col-md-4 col-sm-6\">
                    <div class=\"card mb-4 shadow-sm\">
                        <img src={$urlImgHTML} alt='Image de la chaussure' class='img-list'>
                        <div class=\"card-body\">
                            <p class=\"card-text\">
                                {$nomHTML}
                            </p>
                            <p class=\"card-text\">
                                {$prixHTML} € - Quantité : {$chaussure["quantiteTag"]}           
                            </p>
                            <div class=\"btn-group\">
                                <a href='?action=supprimerDuPanier&controleur=panier&idChaussure={$idChaussureHTML}' class=\"btn btn-outline-primary\">Supprimer du panier</a>
                                <a href='?action=afficherDetail&controleur=chaussure&idChaussure={$idChaussureHTML}' class=\"btn btn-outline-primary\">En savoir plus</a>
                            </div>
                        </div>
                    </div>
                </div>";
            }
            echo "<a href='?action=commander&controleur=commande' class=\"btn btn-outline-success btn-commande\"> <h3 class='text-center'>Commander - {$prixTotal} €</h3></a>";
        }
        ?>
</div>


