<div>
    <h1>Gerer les utilisateurs :</h1>
    <button onclick='window.location.href="?action=afficherFormulairePreference&controleur=utilisateur"'>Filtres</button>
    <button onclick='window.location.href="?action=supprimerPreference&controleur=generique&redirection=utilisateur&nomFiltre=mail,nom,prenom,adresse,age,sexe,admin,mailverif"'>Supprimer les filtres</button>
    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">Mail</th>
            <th scope="col">Nom</th>
            <th scope="col">Prenom</th>
            <th scope="col">Adresse</th>
            <th scope="col">Age</th>
            <th scope="col">Sexe</th>
            <th scope="col">Admin</th>
            <th scope="col">Mail verifie</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php
        use App\EShop\Lib\FiltreControleur;
        use App\EShop\Modele\Repository\UtilisateurRepository;
        /** @var array $utilisateurs */
        if(FiltreControleur::existe(["mail","nom","prenom","adresse","age","sexe","admin","mailverif"])) {
            $preference = FiltreControleur::lire(["mail", "nom", "prenom", "adresse", "age", "sexe", "admin", "mailverif"]);
            $mail = isset($preference["mail"]) ? ($preference["mail"] == "croissant" ? "ASC" : "DESC") : null;
            $nom = isset($preference["nom"]) ? ($preference["nom"] == "croissant" ? "ASC" : "DESC") : null;
            $prenom = isset($preference["prenom"]) ? ($preference["prenom"] == "croissant" ? "ASC" : "DESC") : null;
            $adresse = isset($preference["adresse"]) ? ($preference["adresse"] == "croissant" ? "ASC" : "DESC") : null;
            $age = isset($preference["age"]) ? ($preference["age"] == "croissant" ? "ASC" : "DESC") : null;
            $sexe = isset($preference["sexe"]) ? ($preference["sexe"] == "croissant" ? "ASC" : "DESC") : null;
            $admin = isset($preference["admin"]) ? ($preference["admin"] == "croissant" ? "ASC" : "DESC") : null;
            $mailverif = isset($preference["mailverif"]) ? ($preference["mailverif"] == "croissant" ? "ASC" : "DESC") : null;
        }
        else{
            $preference = [];
            $mail = null;
            $nom = null;
            $prenom = null;
            $adresse = null;
            $age = null;
            $sexe = null;
            $admin = null;
            $mailverif = null;
        }
        $tris = ["mail" => $mail, "nom" => $nom, "prenom" => $prenom, "adresse" => $adresse, "age" => $age, "sexe" => $sexe, "admin" => $admin, "mailverif" => $mailverif];
        $tris = array_filter($tris, function ($value) {
            return $value !== null;
        });
        $utilisateursTrier = (new UtilisateurRepository())->trier($tris);

        foreach ($utilisateursTrier as $utilisateur) {
            $mailHTML = htmlspecialchars($utilisateur["mail"]);
            echo "<tr>";
            echo "<td>" . $mailHTML . "</td>";
            echo "<td>" . htmlspecialchars($utilisateur["nom"]) . "</td>";
            echo "<td>" . htmlspecialchars($utilisateur["prenom"]) . "</td>";
            echo "<td>" . htmlspecialchars($utilisateur["adresse"]) . "</td>";
            echo "<td>" . htmlspecialchars($utilisateur["age"]) . "</td>";
            echo "<td>" . htmlspecialchars($utilisateur["sexe"]) . "</td>";
            if($utilisateur["admin"] == 1){
                echo "<td>Oui</td>";
            }else{
                echo "<td>Non</td>";
            }
            if($utilisateur["mailVerifie"] == 1){
                echo "<td>Oui</td>";
            }else{
                echo "<td>Non</td>";
            }
            echo "<td>
                    <a href='controleurFrontal.php?action=afficherFormulaireMiseAJour&controleur=utilisateur&mail=$mailHTML'>Modifier</a>
                    <a href='controleurFrontal.php?action=supprimer&controleur=utilisateur&mail=$mailHTML' >Supprimer</a></td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
    <a href="controleurFrontal.php?action=afficherFormulaireCreation&controleur=utilisateur">Ajouter un utilisateur</a>
</div>
