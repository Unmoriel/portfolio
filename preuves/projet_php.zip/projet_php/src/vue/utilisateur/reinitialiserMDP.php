<form method="post" action="?action=verifierReinitialisationMDP&controleur=utilisateur&mail=<?php echo rawurlencode($mail) ?>">
    <fieldset>
        <legend>Réinitialiser son mot de passe :</legend>
        <p>
            <input type="hidden" name="nonce" value="<?php echo $nonce ?>">
        </p>
        <div class="form-floating">
            <input class="form-control" id="mdpNouv_id" type="password" name="mdpNouveau" placeholder="Password" required>
            <label for="mdpNouv_id">Nouveau mot de passe&#42;</label>
        </div>
        <div class="form-floating">
            <input class="form-control" id="mdpNouv_id" type="password" name="mdpNouvConf" placeholder="Password" required>
            <label for="mdpNouv_id">Confirmation du nouveau mot de passe&#42;</label>
        </div>
        <p>
            <input class="btn btn-primary" type="submit" value="Modifier le mot de passe" />
        </p>
    </fieldset>
</form>