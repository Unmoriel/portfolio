<form method="get" action="controleurFrontal.php?">
    <fieldset>
        <legend>Mot de passe oublié :</legend>
        <div>
            <input type="hidden"  name="action" value="demandeReinitialiserMDP"/>
            <input type="hidden"  name="controleur" value="utilisateur"/>
        </div>
        <div class="form-floating">
            <input type="email" class="form-control" id="mail_id" name="mail" placeholder="nom@exemple.com" required/>
            <label for="mail_id">Adresse mail</label>
        </div>
        <div id="passwordHelpBlock" class="form-text">
            Rentrez votre adresse mail pour recevoir un mail de réinitialisation de mot de passe si vous êtes inscrit.
        </div>
        <div>
            <input class="btn btn-primary btn-conf-mail" type="submit" value="Envoyer un mail" />
        </div>

    </fieldset>
</form>
<style>
    .btn-conf-mail {
        margin-top: 1em;
    }
    .form-floating {
        width: 600px;
    }
</style>
