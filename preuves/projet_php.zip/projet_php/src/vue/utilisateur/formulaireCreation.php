<form class="row g-3" method="post" action="?action=creerDepuisFormulaire&controleur=utilisateur">
    <fieldset>
        <legend>Inscription :</legend>
        <div class="form-floating">
            <input type="email" class="form-control" id="mail_id" name="mail" placeholder="nom@exemple.com" required/>
            <label for="mail_id">Adresse mail</label>
        </div>
        <div class="form-floating">
            <input type="text" class="form-control" id="nom_id"  name="nom" placeholder="Dupont" required>
            <label for="nom_id">Nom</label>
        </div>
        <div class="form-floating">
            <input type="text" class="form-control" id="prenom_id"  name="prenom" placeholder="Jean" required>
            <label for="prenom_id">Prenom</label>
        </div>
        <div class="form-floating">
            <input type="number" class="form-control" id="age_id"  name="age" placeholder="18" required>
            <label for="age_id">Age</label>
        </div>
        <div class="form-floating">
            <input type="text" class="form-control" id="adresse_id"  name="adresse" placeholder="1 rue de la victoire" required>
            <label for="adresse_id">Adresse</label>
        </div>
        <div class="form-floating">
            <select class="form-select" id="sexe_id" name="sexe" aria-label="Floating label select example">
                <option>Homme</option>
                <option>Femme</option>
            </select>
            <label for="sexe_id">Sexe</label>
        </div>
        <?php /* @var bool $estAdmin */
        if($estAdmin){
            echo "<div class='form-check form-switch'>
                          <input class='form-check-input' type='checkbox' id='estAdmin_id' name='admin'>
                          <label class='form-check-label' for='estAdmin_id'>Admin</label>
                        </div>";
        }
        ?>
        <div class="form-floating">
            <input class="form-control" id="floatingPassword" type="password" name="mdp" placeholder="Password" required>
            <label for="floatingPassword">Mot de passe&#42;</label>
        </div>
        <div class="form-floating">
            <input class="form-control" id="floatingPassword" type="password" name="mdp2" placeholder="Password" required>
            <label for="floatingPassword">Verification du mot de passe&#42;</label>
        </div>
        <p>
            <input class="btn btn-primary" type="submit" value="S'inscrire" />
        </p>
    </fieldset>
</form>

<style>
    .form-floating {
        margin-bottom: 1rem;
        width: 400px;
    }
    .form-select{
        margin-bottom: 1rem;
        width: 400px;
    }
</style>
