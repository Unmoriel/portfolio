<form method="post" action="controleurFrontal.php?action=connecter&controleur=utilisateur">
    <fieldset>
        <legend>Connexion :</legend>
        <div class="form-floating mb-3">
            <input type="email" class="form-control" id="floatingInput" name="mail" placeholder="name@example.com" required/>
            <label for="floatingInput">Adresse mail</label>
        </div>
        <div class="form-floating">
            <input class="form-control" id="floatingPassword" type="password" name="mdp" placeholder="Password" required>
            <label for="floatingPassword">Mot de passe&#42;</label>
        </div>
        <div>
            <input type="submit" class="btn btn-primary" value="Se connecter" />
        </div>
    </fieldset>
</form>
<div class="bot-button-connexion">
    <a class="btn btn-outline-secondary" href="controleurFrontal.php?action=afficherFormulaireCreation&controleur=utilisateur">Pas encore inscrit ?</a>
    <a class="btn btn-outline-dark" href="controleurFrontal.php?action=afficherMDPoublie&controleur=utilisateur">Mot de passe oublié ?</a>
</div>


<style>
    .form-floating{
        margin-bottom: 1rem;
        width: 300px;
    }
    .bot-button-connexion a{
        margin: 10px;
    }
</style>
