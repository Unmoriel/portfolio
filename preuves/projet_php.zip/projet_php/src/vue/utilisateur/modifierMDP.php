<form method="post" action="?action=modifierMdp&controleur=utilisateur&mail=<?php echo rawurlencode($mail) ?>">
    <fieldset>
        <legend>Modifier son mot de passe :</legend>
        <div class="form-floating">
            <input class="form-control" id="floatingPassword" type="password" name="mdpAncien" placeholder="Password" required>
            <label for="floatingPassword">Mot de passe courant&#42;</label>
        </div>
        <div class="form-floating">
            <input class="form-control" id="mdpConf_id" type="password" name="mdpNouveau" placeholder="Password" required>
            <label for="mdpConf_id">Nouveau mot de passe&#42;</label>
        </div>
        <div class="form-floating">
            <input class="form-control" id="mdpNouvConf_id" type="password" name="mdpNouvConf" placeholder="Password" required>
            <label for="mdpNouvConf_id">Confirmation du nouveau mot de passe&#42;</label>
        </div>
        <p>
            <input class="btn btn-primary" type="submit" value="Modifier le mot de passe" />
        </p>
    </fieldset>
</form>
<style>
    .form-floating {
        width: 600px;
        margin: 1em;
    }
</style>

