<?php
/** @var array $utilisateur */

use App\EShop\Lib\ConnexionUtilisateur;

$mailHTML = htmlspecialchars($utilisateur["mailTag"]);
$nomHTML = htmlspecialchars($utilisateur["nomTag"]);
$prenomHTML = htmlspecialchars($utilisateur["prenomTag"]);
$ageHTML = htmlspecialchars($utilisateur["ageTag"]);
$adresseHTML = htmlspecialchars($utilisateur["adresseTag"]);

echo '<p>Mail : ' . $mailHTML . '</p>';
echo '<p>Nom : ' . $nomHTML . '</p>';
echo '<p>Prénom : ' . $prenomHTML . '</p>';
echo '<p>Age : ' . $ageHTML . '</p>';
echo '<p>Adresse : ' . $adresseHTML . '</p>';
if (ConnexionUtilisateur::estUtilisateur($utilisateur["mailTag"]) || ConnexionUtilisateur::estAdmin()){
    echo '<p><a href="controleurFrontal.php?action=afficherFormulaireMiseAJour&controleur=utilisateur&mail=' . rawurlencode($utilisateur["mailTag"]) . '">Modifier</a></p>';
    echo '<p><a href="controleurFrontal.php?action=supprimer&controleur=utilisateur&mail=' . rawurlencode($utilisateur["mailTag"]) . '">Supprimer</a></p>';
}
?>