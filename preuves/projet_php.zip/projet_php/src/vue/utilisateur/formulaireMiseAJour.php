<?php
    /** @var array $utilisateur */

    echo "<form method='post' action='?action=mettreAJour&controleur=utilisateur&mail={$utilisateur["mailTag"]}'>";
    echo "<fieldset>";

    use App\EShop\Lib\ConnexionUtilisateur;

    if(ConnexionUtilisateur::estUtilisateur($utilisateur["mailTag"])){
        echo "<legend>Modifier vos informations personnelles</legend>";
    }else{
        echo "<legend>Modifier les informations personnelles de l'utilisateur {$utilisateur["nomTag"]} {$utilisateur["prenomTag"]} </legend>";
    }
?>
        <div class="form-floating">
            <input type="email" class="form-control" id="mail_id" name="mail" placeholder="nom@exemple.com" value="<?php echo htmlspecialchars($utilisateur["mailTag"]); ?>" readonly/>
            <label for="mail_id">Adresse mail</label>
        </div>
        <div class="form-floating">
            <input type="text" class="form-control" value="<?php echo htmlspecialchars($utilisateur["nomTag"]); ?>" name="nom" id="nom_id" required/>
            <label for="nom_id">Nom</label>
        </div>
        <div class="form-floating">
            <input type="text" class="form-control" value="<?php echo htmlspecialchars($utilisateur["prenomTag"]); ?>" name="prenom" id="prenom_id" required/>
            <label for="prenom_id">Prénom</label>
        </div>
        <div class="form-floating">
            <input type="number" class="form-control" value="<?php echo htmlspecialchars($utilisateur["ageTag"])?>" name="age" id="age_id" required/>
            <label for="age_id">Age</label>
        </div>
        <div class="form-floating">
            <input type="text" class="form-control" value="<?php echo htmlspecialchars($utilisateur["adresseTag"])?> " name="adresse" id="adresse_id" required/>
            <label for="adresse_id">Adresse</label>
        </div>
        <div class="form-floating">
            <select class="form-select" id="sexe_id" name="sexe">
                <option <?php if($utilisateur["sexeTag"] == "Homme"){echo "selected";} ?> >Homme</option>
                <option <?php if($utilisateur["sexeTag"] == "Femme"){echo "selected";} ?> >Femme</option>
            </select>
            <label for="sexe_id">Sexe</label>
        </div>
        <?php
            if(ConnexionUtilisateur::estAdmin()) {
                $checked = $utilisateur["adminTag"] ? "checked" : "";
                echo "<div class='form-check form-switch'>
                          <input class='form-check-input' type='checkbox' id='estAdmin_id' name='admin'  $checked>
                          <label class='form-check-label' for='estAdmin_id'>Admin</label>
                        </div>";
            }

            if(!ConnexionUtilisateur::estAdmin()){
                echo    "<div class='form-floating'>
                            <input class='form-control' type='password' name='mdp' id='mdp_id' required/>
                             <label for='mdp_id'>Mot de passe&#42;</label>
                        </div>";
            }
        ?>
        <div>
            <input class="btn btn-primary" type="submit" value="Valider" />
        </div>
    </fieldset>
</form>
<div class="btn-group btn-gerer-mdp">
    <?php
    echo "<a class='btn btn-danger' href='?action=demandeReinitialiserMDP&controleur=utilisateur&mail={$utilisateur['mailTag']}'>Réinitialiser le mot de passe</a>";
    if(ConnexionUtilisateur::estUtilisateur($utilisateur["mailTag"])) {
        echo "<br><a class='btn btn-warning' href='?action=afficherFormulaireNouveauMDP&controleur=utilisateur&mail={$utilisateur['mailTag']}'>Modifier le mot de passe</a>";
    }
    ?>
</div>
<style>
    .form-floating {
        margin-bottom: 1rem;
        width: 400px;
    }
    .form-select{
        margin-bottom: 1rem;
        width: 400px;
    }
    .btn-gerer-mdp{
        margin-bottom: 1rem;
    }

</style>

