<form>
    <fieldset>
        <legend>Filtre</legend>
        <p>
            <input type="hidden" name="action" value="enregistrerPreference">
            <input type="hidden" name="nomFiltre" value="mail,nom,prenom,adresse,age,sexe,admin,mailverif">
            <input type="hidden" name="redirection" value="utilisateur">
        </p>
        <?php
        use App\EShop\Lib\FiltreControleur;

        if (FiltreControleur::existe(["mail", "nom", "prenom", "adresse", "age", "sexe", "admin", "mailverif"])) {
            $preference = FiltreControleur::lire(["mail", "nom", "prenom", "adresse", "age", "sexe", "admin", "mailverif"]);
        } else {
            $preference = [];
        }
        // Tri par mail
        echo "<p><label>Mail</label></p><p>";

        if(isset($preference["mail"]) && $preference["mail"] == "croissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="mail" value="croissant" checked></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="mail" value="decroissant"></p>';
        }
        else if(isset($preference["mail"]) && $preference["mail"] == "decroissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="mail" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="mail" value="decroissant" checked></p>';
        }
        else
        {
            echo '<p><label> Croissante</label><input type="radio" name="mail" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="mail" value="decroissant"></p>';
        }
        // Tri par nom
        echo "<p><label>Nom</label></p><p>";

        if(isset($preference["nom"]) && $preference["nom"] == "croissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="nom" value="croissant" checked></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="nom" value="decroissant"></p>';
        }
        else if(isset($preference["nom"]) && $preference["nom"] == "decroissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="nom" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="nom" value="decroissant" checked></p>';
        }
        else
        {
            echo '<p><label> Croissante</label><input type="radio" name="nom" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="nom" value="decroissant"></p>';
        }

        // Tri par prenom
        echo "<p><label>Prenom</label></p><p>";

        if(isset($preference["prenom"]) && $preference["prenom"] == "croissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="prenom" value="croissant" checked></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="prenom" value="decroissant"></p>';
        }
        else if(isset($preference["prenom"]) && $preference["prenom"] == "decroissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="prenom" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="prenom" value="decroissant" checked></p>';
        }
        else
        {
            echo '<p><label> Croissante</label><input type="radio" name="prenom" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="prenom" value="decroissant"></p>';
        }

        // Tri par adresse

        echo "<p><label>Adresse</label></p><p>";

        if(isset($preference["adresse"]) && $preference["adresse"] == "croissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="adresse" value="croissant" checked></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="adresse" value="decroissant"></p>';
        }
        else if(isset($preference["adresse"]) && $preference["adresse"] == "decroissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="adresse" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="adresse" value="decroissant" checked></p>';
        }
        else
        {
            echo '<p><label> Croissante</label><input type="radio" name="adresse" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="adresse" value="decroissant"></p>';
        }

        // Tri par age

        echo "<p><label>Age</label></p><p>";

        if(isset($preference["age"]) && $preference["age"] == "croissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="age" value="croissant" checked></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="age" value="decroissant"></p>';
        }
        else if(isset($preference["age"]) && $preference["age"] == "decroissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="age" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="age" value="decroissant" checked></p>';
        }
        else
        {
            echo '<p><label> Croissante</label><input type="radio" name="age" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="age" value="decroissant"></p>';
        }

        // Tri par sexe

        echo "<p><label>Sexe</label></p><p>";

        if(isset($preference["sexe"]) && $preference["sexe"] == "croissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="sexe" value="croissant" checked></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="sexe" value="decroissant"></p>';
        }
        else if(isset($preference["sexe"]) && $preference["sexe"] == "decroissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="sexe" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="sexe" value="decroissant" checked></p>';
        }
        else
        {
            echo '<p><label> Croissante</label><input type="radio" name="sexe" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="sexe" value="decroissant"></p>';
        }

        // Tri par admin

        echo "<p><label>Admin</label></p><p>";

        if(isset($preference["admin"]) && $preference["admin"] == "croissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="admin" value="croissant" checked></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="admin" value="decroissant"></p>';
        }
        else if(isset($preference["admin"]) && $preference["admin"] == "decroissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="admin" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="admin" value="decroissant" checked></p>';
        }
        else
        {
            echo '<p><label> Croissante</label><input type="radio" name="admin" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="admin" value="decroissant"></p>';
        }

        // Tri par mailverif

        echo "<p><label>Mailverif</label></p><p>";

        if(isset($preference["mailverif"]) && $preference["mailverif"] == "croissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="mailverif" value="croissant" checked></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="mailverif" value="decroissant"></p>';
        }
        else if(isset($preference["mailverif"]) && $preference["mailverif"] == "decroissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="mailverif" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="mailverif" value="decroissant" checked></p>';
        }
        else
        {
            echo '<p><label> Croissante</label><input type="radio" name="mailverif" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="mailverif" value="decroissant"></p>';
        }
        ?>
        <p>
            <input type="submit" value="Enregistrer">
        </p>
</form>