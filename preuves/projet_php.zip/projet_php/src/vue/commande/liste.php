<div class="container py-5 bg-light">

        <h2 class="display-4 text-center mb-5">Les commandes : </h2>
<!-- 576 XS - > 576px S > 768px M > 992px L > 1200px Extra Large-->

        <div class="row">
<?php
/** @var array $commandes */
foreach ($commandes as $commande) {
    $nom = htmlspecialchars($commande['dateCommandeTag']);
    $idCommandeHTML = htmlspecialchars($commande['idCommandeTag']);
    $urlImg = "<img src='../ressources/image/commande/commandeFront.png'>";
    echo "<div class=\"col-md-4 col-sm-6\">
            <div class=\"card mb-4 shadow-sm\">
                {$urlImg}
                <div class=\"card-body\">
                     <p class=\"card-text\">
                            Commande du {$nom} <br> Prix total : {$commande['prixTotalTag']} €
                     </p>
                     <a href='?action=afficherDetail&controleur=commande&idCommande={$idCommandeHTML}' class='btn btn-secondary'>Plus de detail</a>


                </div>
            </div>
         </div>";
}
?>