<form>
    <fieldset>
        <legend>Filtre</legend>
        <p>
            <input type="hidden" name="action" value="enregistrerPreference">
            <input type="hidden" name="nomFiltre" value="dateCommandeCommande,mailCommande">
            <input type="hidden" name="redirection" value="commande">
        </p>
        <?php
        use App\EShop\Lib\FiltreControleur;

        if (FiltreControleur::existe(["dateCommande", "mailCommande"])) {
            $preference = FiltreControleur::lire(["dateCommande", "mailCommande"]);
        } else {
            $preference = [];
        }
        // Tri par dateCommande
        echo "<p><label>dateCommande</label></p><p>";

        if(isset($preference["dateCommande"]) && $preference["dateCommande"] == "croissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="dateCommande" value="croissant" checked></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="dateCommande" value="decroissant"></p>';
        }
        else if(isset($preference["dateCommande"]) && $preference["dateCommande"] == "decroissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="dateCommande" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="dateCommande" value="decroissant" checked></p>';
        }
        else
        {
            echo '<p><label> Croissante</label><input type="radio" name="dateCommande" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="dateCommande" value="decroissant"></p>';
        }

        // Tri par mail

        echo "<p><label>Mail</label></p><p>";

        if(isset($preference["mailCommande"]) && $preference["mailCommande"] == "croissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="mailCommande" value="croissant" checked></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="mailCommande" value="decroissant"></p>';
        }
        else if(isset($preference["mailCommande"]) && $preference["mailCommande"] == "decroissant")
        {
            echo '<p><label> Croissante</label><input type="radio" name="mailCommande" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="mailCommande" value="decroissant" checked></p>';
        }
        else
        {
            echo '<p><label> Croissante</label><input type="radio" name="mailCommande" value="croissant" ></p>';
            echo '<p><label> Décroissante</label><input type="radio" name="mailCommande" value="decroissant"></p>';
        }

        echo "<p><input type='submit' value='Enregistrer'></p>";
        ?>
    </fieldset>
</form>
