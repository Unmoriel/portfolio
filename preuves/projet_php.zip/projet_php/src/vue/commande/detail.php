<div class="container py-5 bg-light">
    <h2 class="display-4 text-center mb-5">Commande du <?php echo $dateCommande?></h2>

    <div class="row">
        <?php /* @var array $chaussures */
        foreach ($chaussures as $idChaussure => $chaussure) {
            $nomHTML = htmlspecialchars($chaussure["modeleTag"]);
            $idChaussure = $chaussure["idChaussureTag"];
            $urlImgHTML = htmlspecialchars($chaussure["imageUrlTag"]);
            $prixHTML = htmlspecialchars($chaussure["prixTag"]);
            $idChaussureHTML = htmlspecialchars($idChaussure);
            echo "<div class=\"col-md-4 col-sm-6\">
                    <div class=\"card mb-4 shadow-sm\">
                        <img src={$urlImgHTML} alt='Image de la chaussure' class='img-list'>
                        <div class=\"card-body\">
                            <p class=\"card-text\">
                                {$nomHTML}
                            </p>
                            <p class=\"card-text\">
                                {$prixHTML} € - Quantité : {$chaussure["quantiteTag"]}            
                            </p>
                            <div class=\"btn-group\">
                                <a href='?action=ajouterPanier&controleur=panier&idChaussure={$idChaussureHTML}' class=\"btn btn-outline-primary\">Recommander</a>
                                <a href='?action=afficherDetail&controleur=chaussure&idChaussure={$idChaussureHTML}' class=\"btn btn-outline-primary\">En savoir plus</a>
                            </div>
                        </div>
                    </div>
                </div>";
        }
        ?>
    </div>
</div>