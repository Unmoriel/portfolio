<div>
    <h1>Gerer les commandes :</h1>
    <button onclick='window.location.href="?action=afficherFormulairePreference&controleur=commande"'>Filtres</button>
    <button onclick='window.location.href="?action=supprimerPreference&controleur=generique&redirection=commande&nomFiltre=dateCommande,mailCommande"'>Supprimer les filtres</button>
    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">Date</th>
            <th scope="col">Mail de l'utilisateur</th>
            <th scope="col">Id de la commande</th>
            <th scope="col">Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php
        /** @var array $commandes */
        use App\EShop\Lib\FiltreControleur;
        use App\EShop\Modele\Repository\CommandeRepository;
        if(FiltreControleur::existe(["dateCommande","mailCommande"])) {
            $preference = FiltreControleur::lire(["dateCommande","mailCommande"]);
            $date = isset($preference["dateCommande"]) ? ($preference["dateCommande"] == "croissant" ? "ASC" : "DESC") : null;
            $mailCommande = isset($preference["mailCommande"]) ? ($preference["mailCommande"] == "croissant" ? "ASC" : "DESC") : null;

        $tris = ["dateCommande" => $date, "mail" => $mailCommande];
        $tris = array_filter($tris, function ($value) {
            return $value !== null;
        });
        $commandesT = (new CommandeRepository())->trier($tris);
            foreach ($commandesT as $commande) {
                $idCommandeHTML = htmlspecialchars($commande['idCommande']);
                $dateCommandeHTML = htmlspecialchars($commande['dateCommande']);
                $mailHTML = htmlspecialchars($commande['mail']);
                echo "<tr>";
                echo "<td>" . $dateCommandeHTML. "</td>";
                echo "<td>" . $mailHTML . "</td>";
                echo "<td>" . $idCommandeHTML. "</td>";
                echo "<td>
                    <a href='controleurFrontal.php?action=afficherDetail&controleur=commande&idCommande=$idCommandeHTML'>Détail</a>
                    <a href='controleurFrontal.php?action=supprimer&controleur=commande&idCommande=$idCommandeHTML'>Supprimer</a></td>";
                echo "</tr>";
            }
        }
        else{
            $commandesT = $commandes;
            foreach ($commandesT as $commande) {
                $idCommandeHTML = htmlspecialchars($commande['idCommandeTag']);
                $dateCommandeHTML = htmlspecialchars($commande['dateCommandeTag']);
                $mailHTML = htmlspecialchars($commande['mailTag']);
                echo "<tr>";
                echo "<td>" . $dateCommandeHTML. "</td>";
                echo "<td>" . $mailHTML . "</td>";
                echo "<td>" . $idCommandeHTML. "</td>";
                echo "<td>
                        <a href='controleurFrontal.php?action=afficherDetail&controleur=commande&idCommande=$idCommandeHTML'>Détail</a>
                        <a href='controleurFrontal.php?action=supprimer&controleur=commande&idCommande=$idCommandeHTML'>Supprimer</a></td>";
                echo "</tr>";
            }
        }
        ?>
        </tbody>
    </table>
</div>