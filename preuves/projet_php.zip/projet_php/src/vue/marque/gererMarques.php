<div>
    <h1>Gérer les marques</h1>
    <a href="controleurFrontal.php?action=afficherFormulaireCreation&controleur=marque">Ajouter une marque</a>
    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">Nom de la Marque</th>
            <th scope="col">Adresse</th>
            <th scope="col">Mail</th>
        </tr>
        </thead>
        <tbody>
        <?php
        /** @var array $marques */
        foreach ($marques as $marque) {
            $nomMarqueHTML = htmlspecialchars($marque['nomMarqueTag']);
            $adresseHTML = htmlspecialchars($marque['adresseTag']);
            $mailHTML = htmlspecialchars($marque['mailTag']);
            $idMarqueHTML = htmlspecialchars($marque['idMarqueTag']);
            echo "<tr>";
            echo "<td>" . $nomMarqueHTML . "</td>";
            echo "<td>" . $adresseHTML . "</td>";
            echo "<td>" . $mailHTML . "</td>";
            echo "<td>
                    <a href='controleurFrontal.php?action=afficherFormulaireModification&controleur=marque&idMarque={$idMarqueHTML}'>Modifier</a>
                    <a href='controleurFrontal.php?action=supprimer&controleur=marque&idMarque={$idMarqueHTML}'>Supprimer</a></td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</div>