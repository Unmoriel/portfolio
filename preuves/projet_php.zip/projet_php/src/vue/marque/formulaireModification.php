<form method="post" action="?action=mettreAJour&controleur=marque&idMarque=<?php echo $marque["idMarqueTag"] ?>">
    <fieldset>
        <legend>Modifier la marque :</legend>
        <div class="form-floating">
            <input class="form-control" type="text" name="nomMarque" id="nomMarque_id" value="<?php echo $marque["nomMarqueTag"] ?>" required />
            <label for="nomMarque_id">Nom de la marque</label>
        </div>

        <div class="form-floating">
            <input class="form-control" type="text" name="adresse" id="adresse_id" value="<?php echo $marque['adresseTag'] ?>" required />
            <label for="adresse_id">Adresse</label>
        </div>

        <div class="form-floating">
            <input class="form-control" type="email" name="mail" id="mail_id" value="<?php echo $marque["mailTag"] ?>" required />
            <label for="mail_id">Mail</label>
        </div>

        <p>
            <input class="btn btn-valide btn-primary" type="submit" value="Enregistrer les modifications" />
        </p>
    </fieldset>
</form>
<style>
    .form-floating {
        margin-bottom: 1rem;
        width: 400px;
    }
    .form-select{
        margin-bottom: 1rem;
        width: 400px;
    }
    .btn-valide{
        margin-top: 1rem;
    }
</style>