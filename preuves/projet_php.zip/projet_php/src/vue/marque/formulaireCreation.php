<form method="post" action="?action=creerDepuisFormulaire&controleur=marque">
    <fieldset>
        <legend>Ajouter une marque :</legend>

        <div class="form-floating">
            <input class="form-control" type="text" name="nomMarque" id="nomMarque_id" required />
            <label for="nomMarque_id">Nom Marque</label>
        </div>
        <div class="form-floating">
            <input class="form-control" type="text" name="adresse" id="adresse_id" required />
            <label for="adresse_id">Adresse</label>
        </div>
        <div class="form-floating">
            <input class="form-control" type="email" name="mail" id="mail_id" required />
            <label for="mail_id">Mail</label> 
        </div>
        <p>
            <input class="btn btn-valide btn-primary" type="submit" value="Envoyer" />
        </p>
    </fieldset>
</form>
<style>
    .form-floating {
        margin-bottom: 1rem;
        width: 400px;
    }
    .form-select{
        margin-bottom: 1rem;
        width: 400px;
    }
    .btn-valide{
        margin-top: 1rem;
    }
</style>

