<?php

namespace App\EShop\Controleur;

use App\EShop\Lib\ConnexionUtilisateur;
use App\EShop\Lib\MessageFlash;
use App\EShop\Modele\DataObject\Commande;
use App\EShop\Modele\DataObject\Panier;
use App\EShop\Modele\Repository\ChaussureRepository;
use App\EShop\Modele\Repository\CommandeRepository;

class ControleurCommande extends ControleurGenerique
{

    public static function afficherDetail(): void
    {
        if(!isset($_GET['idCommande'])) {
            ControleurCommande::afficherMessageFlash ("danger", "Aucun id de commande n'a été fourni", "?action=afficherListe&controleur=commande");
        }else {
            $idCommande = $_GET['idCommande'];
            $commande = (new CommandeRepository())->recupererParClePrimaire($idCommande);
            if ($commande == null) {
                ControleurCommande::afficherMessageFlash ("danger", "Commande introuvable", "?action=afficherListe&controleur=commande");
            }
            $chaussures = (new CommandeRepository())->recupererIdChaussureQuantiteParIdCommande($idCommande); // chaussures[idChaussre] = quantite
            if($chaussures == null){
                ControleurCommande::afficherMessageFlash ("danger", "Aucune chaussure n'a été trouvée dans cette commande", "?action=afficherListe&controleur=commande");
            }
            $tabChaussures = [];
            foreach ($chaussures as $idChaussure => $quantite){
                $tabChaussures[$idChaussure] = (new ChaussureRepository())->recupererParClePrimaire($idChaussure)->formatTableau();
                $tabChaussures[$idChaussure]["quantiteTag"] = $quantite;
            }
            ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Liste des produits", "cheminVueBody" => "commande/detail.php", 'chaussures' => $tabChaussures, "dateCommande" => $commande->getDateCommande()]);
        }
    }

    public static function afficherCommandeParLogin(): void
    {
        if(!ConnexionUtilisateur::estConnecte()){
            ControleurGenerique::afficherMessageFlash ("warning", "Connectez vous pour voir vos commandes", "?action=afficherListe&controleur=chaussure");
        }else{
            $mail = ConnexionUtilisateur::getLoginUtilisateurConnecte();
            $commandes = (new CommandeRepository())->recupererParLogin($mail);
            $tabCommandes = [];
            foreach ($commandes as $commande){
                $tabCommandes[] = $commande->formatTableau();
            }
            ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Liste des produits", "cheminVueBody" => "commande/liste.php", 'commandes' => $tabCommandes]);
        }
    }

    public static function commander(){
        if(!ConnexionUtilisateur::estConnecte()){
            ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Connexion", "cheminVueBody" => "utilisateur/formulaireConnexion.php"]);
        }else{
            $panier = Panier::getPanier();
            if($panier->nbProduits() == 0){
                ControleurGenerique::afficherMessageFlash ("warning", "Votre panier est vide", "?action=afficherListe&controleur=chaussure");
            }else{
                $commande = new Commande(uniqid("cmd_"), ConnexionUtilisateur::getLoginUtilisateurConnecte(), date("d-m-Y H:i:s"), $panier->getPrixTotal());
                (new CommandeRepository())->sauvegarderAvecChaussures($commande, $panier->getListeIdChaussures());
                $panier->vider();
                MessageFlash::ajouter("success", "Votre commande a été enregistrée");
                ControleurGenerique::redirectionVersURL("?action=afficherListe&controleur=chaussure");
            }
        }
    }

    public static function gererCommandes(){
        if(!ConnexionUtilisateur::estAdmin()){
            ControleurGenerique::afficherMessageFlash ("danger", "Connectez vous avec un compte administrateur", "?action=afficherListe&controleur=chaussure");
        }else{
            $commandes = (new CommandeRepository())->recuperer();
            $tabCommandes = [];
            foreach ($commandes as $commande){
                $tabCommandes[] = $commande->formatTableau();
            }
            ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Gérer les commandes", "cheminVueBody" => "commande/gererCommandes.php", 'commandes' => $tabCommandes]);
        }
    }

    public static function supprimer():void{
        if(!ConnexionUtilisateur::estAdmin()){
            ControleurGenerique::afficherMessageFlash ("danger", "Connectez vous avec un compte administrateur", "?action=gererCommande&controleur=chaussure");
        }else{
            if(!isset($_GET['idCommande'])){
                ControleurGenerique::afficherMessageFlash ("danger", "Aucun id de commande n'a été fourni", "?action=gererCommande&controleur=chaussure");
            }else {
                $idCommande = $_GET['idCommande'];
                $commande = (new CommandeRepository())->recupererParClePrimaire($idCommande);
                if ($commande == null) {
                    ControleurGenerique::afficherMessageFlash ("danger", "Commande introuvable", "?action=gererCommande&controleur=chaussure");
                } else {
                    (new CommandeRepository())->supprimer($commande->getIdCommande());
                    MessageFlash::ajouter("success", "La commande a été supprimée");
                    ControleurGenerique::redirectionVersURL("?action=gererCommandes&controleur=commande");
                }
            }
        }
    }

    public static function afficherFormulairePreference(): void
    {
        ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Filtres des commandes", "cheminVueBody" => "commande/filtreCommande.php"]);
    }
}