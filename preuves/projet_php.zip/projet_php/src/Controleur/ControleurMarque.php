<?php

namespace App\EShop\Controleur;

use App\EShop\Lib\ConnexionUtilisateur;
use App\EShop\Lib\MessageFlash;
use App\EShop\Modele\DataObject\Marque;
use App\EShop\Modele\Repository\MarqueRepository;

class ControleurMarque extends ControleurGenerique
{

    public static function gererMarques(): void
    {
        ControleurMarque::verifierAdmin();
        $marques = (new MarqueRepository())->recuperer();
        $tabMarques = [];
        foreach ($marques as $marque) {
            $tabMarques[] = $marque->formatTableau();
        }
        ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Gérer les marques", "cheminVueBody" => "marque/gererMarques.php", 'marques' => $tabMarques]);
    }

    public static function afficherFormulaireCreation(): void
    {
        ControleurMarque::verifierAdmin();
        ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Ajouter une marque", "cheminVueBody" => "marque/formulaireCreation.php"]);
    }

    public static function creerDepuisFormulaire(): void
    {
        ControleurMarque::verifierAdmin();
        if(!isset($_POST['nomMarque'], $_POST['adresse'], $_POST['mail'])) {
            ControleurMarque::afficherMessageFlash ("danger", "Tous les champs n'ont pas été remplis", "?action=afficherFormulaireCreation&controleur=marque");
        }else {
            $marque = new Marque(null, $_POST['nomMarque'], $_POST['adresse'], $_POST['mail']);
            (new MarqueRepository())->sauvegarder($marque);
            MessageFlash::ajouter("success", "La marque a été créée");
            ControleurMarque::redirectionVersURL("?action=gererMarques&controleur=marque");
        }
    }

    public static function supprimer(): void
    {
        ControleurMarque::verifierAdmin();
        if(!isset($_GET['idMarque'])) {
            ControleurMarque::afficherMessageFlash ("danger", "Aucun id de marque n'a été fourni", "?action=gererMarques&controleur=marque");
        }else {
            $idMarque = $_GET['idMarque'];
            (new MarqueRepository())->supprimer($idMarque);
            MessageFlash::ajouter("success", "La marque a été supprimée");
            ControleurMarque::redirectionVersURL("?action=gererMarques&controleur=marque");
        }
    }

    public static function afficherFormulaireModification(): void
    {
        ControleurMarque::verifierAdmin();
        if(!isset($_GET['idMarque'])) {
            ControleurMarque::afficherMessageFlash ("danger", "Aucun id de marque n'a été fourni", "?action=gererMarques&controleur=marque");
        }else {
            $idMarque = $_GET['idMarque'];
            $marque = (new MarqueRepository())->recupererParId($idMarque);
            if($marque == null) {
                ControleurMarque::afficherMessageFlash ("danger", "La marque n'existe pas", "?action=gererMarques&controleur=marque");
            }
            $tabMarque = $marque->formatTableau();
            ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Modifier une marque", "cheminVueBody" => "marque/formulaireModification.php", 'marque' => $tabMarque]);
        }
    }

    public static function mettreAJour(): void
    {
        ControleurMarque::verifierAdmin();
        if(!isset($_POST['nomMarque'], $_POST['adresse'], $_POST['mail'])) {
            ControleurMarque::afficherMessageFlash ("danger", "Tous les champs n'ont pas été remplis", "?action=gererMarques&controleur=marque");
        }elseif(!isset($_GET['idMarque'])) {
            ControleurMarque::afficherMessageFlash ("danger", "Aucun id de marque n'a été fourni", "?action=gererMarques&controleur=marque");
        }else {
            $marque = new Marque($_GET['idMarque'], $_POST['nomMarque'], $_POST['adresse'], $_POST['mail']);
            var_dump($marque);
            (new MarqueRepository())->mettreAJour($marque);
            MessageFlash::ajouter("success", "La marque a été modifiée");
            ControleurMarque::redirectionVersURL("?action=gererMarques&controleur=marque");
        }
    }
}
