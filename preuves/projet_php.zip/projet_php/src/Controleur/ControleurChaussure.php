<?php

namespace App\EShop\Controleur;

use App\EShop\Lib\MessageFlash;
use App\EShop\Modele\DataObject\Chaussure;
use App\EShop\Modele\Repository\ChaussureRepository;
use App\EShop\Modele\Repository\MarqueRepository;

class ControleurChaussure extends ControleurGenerique
{

    public static function afficherListe(): void
    {
        $produits = (new ChaussureRepository())->recuperer();
        ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Liste des produits", "cheminVueBody" => "chaussure/liste.php", 'produits' => $produits]);
    }

    public static function afficherDetail(): void
    {
        if(!isset($_GET['idChaussure'])){
            ControleurChaussure::afficherMessageFlash ("danger", "Aucun id de chaussure n'a été fourni", "?action=afficherListe&controleur=chaussure");
        }else{
            $idChaussure = $_GET['idChaussure'];
            $chaussure = (new ChaussureRepository())->recupererParClePrimaire($idChaussure);
            $nomMarque = (new MarqueRepository())->getNomParId($chaussure->getIdMarque());
            if ($chaussure == null) {
                ControleurChaussure::afficherMessageFlash ("danger", "Chaussure introuvable", "?action=afficherListe&controleur=chaussure");
            } else {
                ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Détail de la chaussure", "cheminVueBody" => "chaussure/detail.php", "chaussure" => $chaussure->formatTableau(), "nomMarque" => $nomMarque]);
            }
        }

    }

    public static function creerDepuisFormulaire(): void
    {
        ControleurChaussure::verifierAdmin();
        if(!isset($_POST['modele']) ||
            !isset($_POST['pointure']) ||
            !isset($_POST['cible']) ||
            !isset($_POST['categorie']) ||
            !isset($_POST['prix']) ||
            !isset($_POST['idMarque']) ||
            !isset($_POST['imageUrl'])
        ){
            ControleurChaussure::afficherMessageFlash ("danger", "Tous les champs n'ont pas été remplis", "?action=afficherFormulaireCreation&controleur=chaussure");
        }else{
            self::verifImageUrl();
            $chaussure = new Chaussure(null, $_POST['modele'], $_POST['pointure'], $_POST['cible'], $_POST['categorie'], $_POST['prix'], $_POST['idMarque'], $_POST['imageUrl']);
            (new ChaussureRepository())->sauvegarder($chaussure);
            MessageFlash::ajouter("success", "La chaussure a été créée");
            ControleurChaussure::redirectionVersURL("?action=afficherListe&controleur=chaussure");
        }

    }



    public static function afficherFormulairePreference(): void
    {
        $pointure = ControleurChaussure::recupererPointures();
        $marques = ControleurChaussure::recupererMarques();
        $idMarques = ControleurChaussure::recupererIdMarque();
        $cibles = ControleurChaussure::recupererCibles();
        ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Formulaire préférence", "cheminVueBody" => "chaussure/formulairePreference.php", "pointure" => $pointure, "marques" => $marques, "idMarques" => $idMarques, "cibles" => $cibles]);
    }

    public static function afficherFormulaireFiltre(): void
    {
        $pointure = ControleurChaussure::recupererPointures();
        $marques = ControleurChaussure::recupererMarques();
        $idMarques = ControleurChaussure::recupererIdMarque();
        $cibles = ControleurChaussure::recupererCibles();
        ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Formulaire préférence", "cheminVueBody" => "chaussure/filtreChaussure.php", "pointure" => $pointure, "marques" => $marques, "idMarques" => $idMarques, "cibles" => $cibles]);
    }

    public static function afficherFormulaireCreation(): void
    {
        ControleurChaussure::verifierAdmin();
        $marques = ControleurChaussure::recupererMarques();
        $tableauMarques = [];
        foreach ($marques as $marque) {
            $tableauMarques[$marque->getIdMarque()] = $marque->getNomMarque();
        }
        ControleurGenerique::afficherVue("vueGenerale.php", [
            "pagetitle" => "Formulaire de création",
            "cheminVueBody" => "chaussure/formulaireCreation.php",
            "marques" => $tableauMarques,
        ]);
    }

    public static function afficherFormulaireModification(): void
    {
        ControleurChaussure::verifierAdmin();
        $idChaussure = $_GET['idChaussure'];
        $chaussure = (new ChaussureRepository())->recupererParClePrimaire($idChaussure);
        $tabChaussure = $chaussure->formatTableau();
        $marques = ControleurChaussure::recupererMarques();
        $tableauMarques = [];
        foreach ($marques as $marque) {
            $tableauMarques[$marque->getIdMarque()] = $marque->getNomMarque();
        }
        $categories = ControleurChaussure::recupererCategories();

        ControleurGenerique::afficherVue("vueGenerale.php", [
            "pagetitle" => "Formulaire de modification",
            "cheminVueBody" => "chaussure/formulaireModification.php",
            "chaussure" => $tabChaussure,
            "marques" => $tableauMarques,
            "categories" => $categories,
        ]);
    }

    public static function recupererMarques(): array
    {
        return (new MarqueRepository())->recuperer();
    }

    public static function recupererCategories(): array
    {
        return (new ChaussureRepository())->recupererCategories();
    }

    public static function recupererPointures(): array
    {
        return (new ChaussureRepository())->recupererPointures();
    }

    public static function recupererIdMarque(): array
    {
        return (new ChaussureRepository())->recupererIdMarque();
    }

    public static function recupererCibles(): array
    {
        return (new ChaussureRepository())->recupererCibles();
    }



    public static function mettreAJour(): void
    {
        ControleurChaussure::verifierAdmin();
        if(!isset($_POST['modele']) ||
            !isset($_POST['pointure']) ||
            !isset($_POST['cible']) ||
            !isset($_POST['categorie']) ||
            !isset($_POST['prix']) ||
            !isset($_POST['idMarque']) ||
            !isset($_POST['imageUrl'])
        ) {
            ControleurChaussure::afficherMessageFlash ("danger", "Tous les champs n'ont pas été remplis", "?action=gererChaussures&controleur=chaussure");
        }

        else {
            self::verifImageUrl();
            $chaussure = new Chaussure(
                $_POST['idChaussure'],
                $_POST['modele'],
                $_POST['pointure'],
                $_POST['cible'],
                $_POST['categorie'],
                $_POST['prix'],
                $_POST['idMarque'],
                $_POST['imageUrl']
            );

            (new ChaussureRepository())->mettreAJour($chaussure);
            MessageFlash::ajouter("success", "La chaussure a été mise à jour");
            ControleurChaussure::redirectionVersURL("?action=gererChaussures&controleur=chaussure");
        }
    }

    public static function gererChaussures(): void
    {
        ControleurChaussure::verifierAdmin();
        $chaussures = (new ChaussureRepository())->recuperer();
        $marques = (new MarqueRepository());
        $tableauChaussures = [];
        foreach ($chaussures as $chaussure) {
            $tableauChaussures[] = $chaussure->formatTableau();
        }
        ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Gérer les chaussures", "cheminVueBody" => "chaussure/gererChaussures.php", 'chaussures' => $tableauChaussures, 'marques' => $marques]);
    }

    public static function supprimer(): void
    {
        ControleurChaussure::verifierAdmin();
        if(!isset($_GET['idChaussure'])){
            ControleurChaussure::afficherMessageFlash ("danger", "Aucun id de chaussure n'a été fourni", "?action=gererChaussures&controleur=chaussure");
        }else {
            $idChaussure = $_GET['idChaussure'];
            (new ChaussureRepository())->supprimer($idChaussure);
            MessageFlash::ajouter("success", "La chaussure a été supprimée");
            ControleurChaussure::redirectionVersURL("?action=gererChaussures&controleur=chaussure");
        }
    }

    public static function verifImageUrl(): void {
        //si l'url est null, on met une image par défaut
        if ($_POST['imageUrl'] == null) {
            $_POST['imageUrl'] = "https://static.vecteezy.com/ti/vecteur-libre/p3/6059989-icone-camera-croisee-eviter-de-prendre-des-photos-image-n-est-pas-disponible-illustrationle-gratuit-vectoriel.jpg";
        }
    }
}
