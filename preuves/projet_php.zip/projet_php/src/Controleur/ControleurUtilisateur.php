<?php
namespace App\EShop\Controleur;
use App\EShop\Lib\ConnexionUtilisateur;
use App\EShop\Lib\MessageFlash;
use App\EShop\Lib\MotDePasse;
use App\EShop\Lib\VerificationEmail;
use App\EShop\Modele\DataObject\Utilisateur;
use App\EShop\Modele\Repository\UtilisateurRepository;
use App\EShop\Modele\HTTP\Session;
class ControleurUtilisateur extends ControleurGenerique{
    public static function afficherListe() : void {
        $utilisateurs = (new UtilisateurRepository)->recuperer();
        ControleurUtilisateur::afficherVue("vueGenerale.php", ["pagetitle" => "Liste des utilisateurs", "cheminVueBody" => "utilisateur/liste.php",'utilisateurs' => $utilisateurs]);
    }

    public static function afficherDetail() : void {
        if(!isset($_GET['mail'])){
            ControleurUtilisateur::afficherMessageFlash ("danger", "Aucun mail fournit", "?action=afficherListe&controleur=chaussure");
        }
        $mail = $_GET['mail'];
        $utilisateur = (new UtilisateurRepository)->recupererParClePrimaire($mail)->formatTableau();
        if ($utilisateur == null) {
            ControleurUtilisateur::afficherMessageFlash ("danger", "L'utilisateur au mail $mail n'existe pas", "?action=afficherListe&controleur=chaussure");
        } else {
            ControleurUtilisateur::afficherVue("vueGenerale.php", ["pagetitle" => "Détail de l'utilisateur", "cheminVueBody" => "utilisateur/detail.php", "utilisateur" => $utilisateur]);
        }
    }

    public static function afficherFormulairePreference(): void
    {
        ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Filtres Utilisateur", "cheminVueBody" => "utilisateur/filtreUtilisateur.php"]);
    }

    public static function supprimer(): void
    {
        ControleurUtilisateur::verifierAdmin();
        if(!isset($_GET['mail'])){
            ControleurUtilisateur::afficherMessageFlash ("danger", "Aucun mail fournit", "?action=afficherListe&controleur=chaussure");
        }else {
            $mail = $_GET['mail'];
            $utilisateur = (new UtilisateurRepository)->recupererParClePrimaire($mail);
            if ($utilisateur == null) {
                ControleurUtilisateur::afficherMessageFlash ("danger", "L'utilisateur au mail $mail n'existe pas", "?action=afficherListe&controleur=chaussure");
            } else {
                (new UtilisateurRepository)->supprimer($mail);
                MessageFlash::ajouter("success", "L'utilisateur a été supprimé");
                ControleurUtilisateur::redirectionVersURL("controleurFrontal.php?action=gererUtilisateur&controleur=utilisateur");
            }
        }
    }


    public static function creerDepuisFormulaire() : void {
        if ($_POST['mdp'] != $_POST['mdp2']) {
            ControleurUtilisateur::afficherMessageFlash ("danger", "Les mots de passe ne correspondent pas", "?action=afficherFormulaireCreation&controleur=utilisateur");
        }
        else {
            if((new UtilisateurRepository)->recupererParClePrimaire($_POST['mail']) != null){
                ControleurUtilisateur::afficherMessageFlash ("danger", "L'adresse mail est déjà utilisée", "?action=afficherFormulaireCreation&controleur=utilisateur");
            }
            if(!isset($_POST['mail']) ||
                !isset($_POST['mdp']) ||
                !isset($_POST['mdp2']) ||
                !isset($_POST['nom']) ||
                !isset($_POST['prenom']) ||
                !isset($_POST['adresse']) ||
                !isset($_POST['age']) ||
                !isset($_POST['sexe'])){
                ControleurUtilisateur::afficherMessageFlash ("danger", "Tous les champs n'ont pas été remplis", "?action=afficherFormulaireCreation&controleur=utilisateur");
            }

            $admin = false;
            if(ConnexionUtilisateur::estAdmin() && isset($_POST['admin'])){
                $admin = true;
            }
            $tabFormulaire = [
                "mail" => $_POST['mail'],
                "mailVerifie" => false,
                "mdp" => $_POST['mdp'],
                "nom" => $_POST['nom'],
                "prenom" => $_POST['prenom'],
                "adresse" => $_POST['adresse'],
                "age" => $_POST['age'],
                "sexe" => $_POST['sexe'],
                "admin" => $admin,
                "nonce" => MotDePasse::genererChaineAleatoire()
            ];
            $utilisateur = Utilisateur::construireDepuisFormulaire($tabFormulaire);
            (new UtilisateurRepository)->sauvegarder($utilisateur);
            VerificationEmail::envoiEmailValidation($utilisateur);
            MessageFlash::ajouter("info", "Un email de validation vous a été envoyé (huiklmop@yopmail.com)");
            ControleurUtilisateur::redirectionVersURL("controleurFrontal.php?action=afficherFormulaireConnexion&controleur=utilisateur");
        }
    }

    public static function validerEmail() : void {
        if(!isset($_GET['mail']) || !isset($_GET['nonce'])){
            ControleurUtilisateur::afficherMessageFlash ("danger", "Aucun mail ou nonce fournit", "?action=afficherListe&controleur=chaussure");
        }
        $mail = $_GET['mail'];
        $nonce = $_GET['nonce'];
        $utilisateur = (new UtilisateurRepository)->recupererParClePrimaire($mail);
        if ($utilisateur == null) {
            ControleurUtilisateur::afficherMessageFlash ("danger", "L'utilisateur au mail $mail n'existe pas", "?action=afficherListe&controleur=chaussure");
        } else {
            if (VerificationEmail::traiterEmailValidation($mail, $nonce)) {
                MessageFlash::ajouter("success", "Votre email a été validé");
                ControleurUtilisateur::redirectionVersURL("controleurFrontal.php?action=afficherFormulaireConnexion&controleur=utilisateur");
            }else{
                ControleurUtilisateur::afficherMessageFlash ("danger", "L'email n'a pas pu être validé", "?action=afficherListe&controleur=chaussure");
            }
        }
    }

    public static function afficherFormulaireCreation() : void {
        ControleurUtilisateur::afficherVue("vueGenerale.php", ["pagetitle" => "Formulaire de création", "cheminVueBody" => "utilisateur/formulaireCreation.php", "estAdmin"=>ConnexionUtilisateur::estAdmin()]);
    }

    public static function afficherMDPoublie() : void {
        ControleurUtilisateur::afficherVue("vueGenerale.php", ["pagetitle" => "Mot de passe oublié", "cheminVueBody" => "utilisateur/mdpOublie.php"]);
    }

    public static function afficherFormulaireMiseAJour(): void {
        if(!isset($_GET['mail'])){
            ControleurUtilisateur::afficherMessageFlash ("danger", "Aucun mail fournit", "?action=afficherListe&controleur=chaussure");
        }else{
            $mail = $_GET['mail'];
            if (ConnexionUtilisateur::estUtilisateur($mail) || ConnexionUtilisateur::estAdmin()) {
                $utilisateur = (new UtilisateurRepository)->recupererParClePrimaire($mail);
                if ($utilisateur == null) {
                    ControleurUtilisateur::afficherMessageFlash ("danger", "L'utilisateur au mail $mail n'existe pas", "?action=afficherListe&controleur=chaussure");
                } else {
                    ControleurUtilisateur::afficherVue("vueGenerale.php", ["pagetitle" => "Formulaire de mise à jour", "cheminVueBody" => "utilisateur/formulaireMiseAJour.php", "utilisateur" => $utilisateur->formatTableau()]);
                }
            }else{
                ControleurUtilisateur::afficherMessageFlash ("danger", "Vous n'êtes pas autorisé à modifier cet utilisateur", "?action=afficherListe&controleur=chaussure");
            }
        }

    }
    public static function mettreAJour(): void
    {
        if (isset($_GET['mail'], $_POST['nom'], $_POST['prenom'], $_POST["adresse"], $_POST["age"], $_POST["age"])) {
            $utilisateur = (new UtilisateurRepository)->recupererParClePrimaire($_GET['mail']);
            if ($utilisateur == null) {
                ControleurUtilisateur::afficherMessageFlash (
                    "danger",
                    "L'utilisateur au mail {$_GET['mail']} n'existe pas",
                    "?action=afficherListe&controleur=chaussure");
            } else {
                if (ConnexionUtilisateur::estUtilisateur($_GET["mail"]) || ConnexionUtilisateur::estAdmin()) {
                    if (ConnexionUtilisateur::estAdmin() || MotDePasse::verifier($_POST["mdp"], $utilisateur->getMdpHache())) {
                        $utilisateur->setNom($_POST['nom']);
                        $utilisateur->setPrenom($_POST['prenom']);
                        $utilisateur->setAdresse($_POST['adresse']);
                        $utilisateur->setAge($_POST['age']);
                        $utilisateur->setSexe($_POST['sexe']);
                        if(ConnexionUtilisateur::estAdmin()) {
                            $utilisateur->setAdmin(isset($_POST['admin']));
                        }
                        (new UtilisateurRepository)->mettreAJour($utilisateur);
                        ControleurUtilisateur::afficherMessageFlash (
                            "success",
                            "L'utilisateur a été mis à jour",
                            "?action=afficherListe&controleur=chaussure");
                    } else {
                        ControleurUtilisateur::afficherMessageFlash (
                            "danger",
                            "Le mot de passe est incorrect",
                            "?action=afficherFormulaireMiseAJour&controleur=utilisateur");
                    }
                } else {
                    ControleurUtilisateur::afficherMessageFlash (
                        "danger",
                        "Vous n'êtes pas autorisé à modifier cet utilisateur",
                        "?action=afficherListe&controleur=chaussure");
                }
            }
        }else{
            ControleurUtilisateur::afficherMessageFlash (
                "danger",
                "Tous les champs n'ont pas été remplis",
                "?action=afficherFormulaireMiseAJour&controleur=utilisateur");
        }
    }

    public static function afficherFormulaireNouveauMDP(){
        if(!isset($_GET['mail'])) {
            ControleurUtilisateur::afficherMessageFlash ("danger", "Aucun mail fournit", "?action=afficherListe&controleur=chaussure");
        }else {
            ControleurUtilisateur::afficherVue("vueGenerale.php", ["pagetitle" => "Changer de mot de passe", "cheminVueBody" => "utilisateur/modifierMDP.php", "mail" => $_GET['mail']]);
        }
    }

    public static function modifierMdp():void {
        if(!isset($_GET['mail'])) {
            ControleurUtilisateur::afficherMessageFlash ("danger", "Aucun mail fournit", "?action=afficherListe&controleur=chaussure");
        }else{
            if (!isset($_POST['mdpAncien']) || !isset($_POST['mdpNouveau']) || !isset($_POST['mdpNouvConf'])) {
                ControleurUtilisateur::afficherMessageFlash ("danger", "Tous les champs n'ont pas été remplis", "?action=afficherFormulaireNouveauMDP&controleur=utilisateur");
            } else {
                $mail = $_GET['mail'];
                $utilisateur = (new UtilisateurRepository())->recupererParClePrimaire($mail);
                if ($utilisateur == null) {
                    ControleurUtilisateur::afficherMessageFlash ("danger", "L'utilisateur au mail $mail n'existe pas", "?action=afficherListe&controleur=chaussure");
                } else {
                    if (ConnexionUtilisateur::estUtilisateur($mail) || ConnexionUtilisateur::estAdmin()) {
                        if (MotDePasse::verifier($_POST['mdpAncien'], $utilisateur->getMdpHache())) {
                            if ($_POST['mdpNouveau'] == $_POST['mdpNouvConf']) {
                                $utilisateur->setMdpHache((new MotDePasse())->hacher($_POST['mdpNouveau']));
                                (new UtilisateurRepository())->mettreAJour($utilisateur);
                                ControleurUtilisateur::afficherMessageFlash ("success", "Le mot de passe a été modifié", "?action=afficherListe&controleur=chaussure");
                            } else {
                                ControleurUtilisateur::afficherMessageFlash ("danger", "Les mots de passe ne correspondent pas", "?action=afficherFormulaireNouveauMDP&controleur=utilisateur&mail=$mail");
                            }
                        } else {
                            ControleurUtilisateur::afficherMessageFlash ("danger", "Le mot de passe est incorrect", "?action=afficherFormulaireNouveauMDP&controleur=utilisateur&mail=$mail");
                        }
                    } else {
                        ControleurUtilisateur::afficherMessageFlash ("danger", "Vous n'êtes pas autorisé à modifier cet utilisateur", "?action=afficherFormulaireNouveauMDP&controleur=utilisateur&mail=$mail");
                    }
                }
            }
        }

    }

    public static function afficherFormulaireReinitialisationMDP(){
        if(!isset($_GET['mail'])) {
            ControleurUtilisateur::afficherMessageFlash ("danger", "Aucun mail fournit", "?action=afficherListe&controleur=chaussure");
        }else{
            ControleurUtilisateur::afficherVue("vueGenerale.php", ["pagetitle" => "Réinitialiser le mot de passe", "cheminVueBody" => "utilisateur/reinitialiserMDP.php", "mail" => $_GET['mail']]);
        }
    }

    public static function afficherFormulaireChoixNouveauMDP(){ //Formulaire pour le choix d'un mdp après une demande de réinitialisation
        if(!isset($_GET['mail'], $_GET['nonce'])) {
            ControleurUtilisateur::afficherMessageFlash ("danger", "Aucun mail ou nonce fournit", "?action=afficherListe&controleur=chaussure");
        }else{
            ControleurUtilisateur::afficherVue("vueGenerale.php", ["pagetitle" => "Réinitialiser son mot de passe", "cheminVueBody" => "utilisateur/reinitialiserMDP.php", "mail" => $_GET['mail'], "nonce" => $_GET['nonce']]);
        }
    }

    public static function demandeReinitialiserMDP(){
        if(!isset($_GET['mail'])) {
            ControleurUtilisateur::afficherMessageFlash ("danger", "Aucun mail fournit", "?action=afficherListe&controleur=chaussure");
        }else{
            $mail = $_GET['mail'];
            $utilisateur = (new UtilisateurRepository)->recupererParClePrimaire($mail);
            if ($utilisateur == null) {
                ControleurUtilisateur::afficherMessageFlash ("danger", "L'utilisateur au mail $mail n'existe pas", "?action=afficherListe&controleur=chaussure");
            } else {
                $utilisateur->setNonce(MotDePasse::genererChaineAleatoire());
                (new UtilisateurRepository)->mettreAJour($utilisateur);
                VerificationEmail::envoiEmailReinitialisationMDP($utilisateur);
                if(ConnexionUtilisateur::estUtilisateur($mail)){
                    ControleurUtilisateur::afficherMessageFlash ("success", "Un mail pour réinitialiser votre mot de passe à été envoyé (huiklmop@yopmail.com)", "?action=afficherDetail&controleur=utilisateur");
                }elseif(ConnexionUtilisateur::estAdmin()){
                    ControleurUtilisateur::afficherMessageFlash ("success", "Un mail pour réinitialiser le mot de passe à été envoyé (huiklmop@yopmail.com)", "?action=gererUtilisateur&controleur=utilisateur");
                }else{
                    ControleurUtilisateur::afficherMessageFlash ("success", "Un mail pour réinitialiser votre mot de passe à été envoyé (huiklmop@yopmail.com)", "?action=afficherListe&controleur=chaussure");
                }
            }
        }
    }

    public static function verifierReinitialisationMDP() : void{
        if(!isset($_GET['mail'])) {
            ControleurUtilisateur::afficherMessageFlash ("danger", "Aucun mail fournit", "?action=afficherListe&controleur=chaussure");
        }else{
            if(!isset($_POST['nonce']) || !isset($_POST['mdpNouveau']) || !isset($_POST['mdpNouvConf'])){
                MessageFlash::ajouter("danger", "Tous les champs n'ont pas été remplis");
                ControleurUtilisateur::afficherVue("vueGenerale.php", ["pagetitle" => "Réinitialiser le mot de passe", "cheminVueBody" => "utilisateur/reinitialiserMDP.php", "mail" => $_GET['mail']]);
            }else{
                $mail = $_GET['mail'];
                $utilisateur = (new UtilisateurRepository)->recupererParClePrimaire($mail);
                if ($utilisateur == null) {
                    ControleurUtilisateur::afficherMessageFlash ("danger", "L'utilisateur au mail $mail n'existe pas", "?action=afficherListe&controleur=chaussure");
                } else {
                    if (VerificationEmail::traiterEmailReinitialisationMDP($mail, $_POST['nonce'])) {
                        if ($_POST['mdpNouveau'] == $_POST['mdpNouvConf']) {
                            $utilisateur->setMdpHache((new MotDePasse())->hacher($_POST['mdpNouveau']));
                            $utilisateur->setNonce("");
                            (new UtilisateurRepository)->mettreAJour($utilisateur);
                            ControleurUtilisateur::afficherMessageFlash ("success", "Le mot de passe a été modifié", "?action=deconnexion&controleur=utilisateur");
                        } else {
                            MessageFlash::ajouter("danger", "Les mots de passe ne correspondent pas");
                            ControleurUtilisateur::afficherVue("vueGenerale.php", ["pagetitle" => "Réinitialiser le mot de passe", "cheminVueBody" => "utilisateur/reinitialiserMDP.php", "mail" => $mail]);
                        }
                    } else {
                        MessageFlash::ajouter("danger", "Le code de réinitialisation est incorrect");
                        ControleurUtilisateur::afficherVue("vueGenerale.php", ["pagetitle" => "Réinitialiser le mot de passe", "cheminVueBody" => "utilisateur/reinitialiserMDP.php", "mail" => $mail]);
                    }

                }
            }
        }
    }


    public static function connecter() : void {
        if(!(isset($_POST['mail'])) || !(isset($_POST['mdp']))){
            ControleurUtilisateur::afficherMessageFlash ("danger", "Tous les champs n'ont pas été remplis", "?action=afficherFormulaireConnexion&controleur=utilisateur");
        }
        else {
            $utilisateur = (new UtilisateurRepository)->recupererParClePrimaire($_POST['mail']);
            if ($utilisateur == null) {
                ControleurUtilisateur::afficherMessageFlash ("danger", "Le mot de passe ou le mail est incorrect", "?action=afficherFormulaireConnexion&controleur=utilisateur");
            } else {
                $mdpHache = $utilisateur->getMdpHache();
                if ((new MotDePasse())->verifier($_POST['mdp'], $mdpHache)) {
                    if(VerificationEmail::aValideEmail($utilisateur)) {
                        Session::getInstance()->enregistrer("utilisateurConnecte", $utilisateur);
                        MessageFlash::ajouter("success", "Vous êtes connecté");
                        ControleurUtilisateur::redirectionVersURL("controleurFrontal.php?action=afficherliste&controleur=chaussure");
                    }else{
                        MessageFlash::ajouter("warning", "Votre email n'a pas été validé (huiklmop@yopmail.com)");
                        ControleurUtilisateur::redirectionVersURL("controleurFrontal.php?action=afficherFormulaireConnexion&controleur=utilisateur");
                    }
                } else {
                    ControleurUtilisateur::afficherMessageFlash ("danger", "Le mot de passe ou le mail est incorrect", "?action=afficherFormulaireConnexion&controleur=utilisateur");
                }
            }
        }
    }

    public static function afficherFormulaireConnexion() : void {
        ControleurUtilisateur::afficherVue("vueGenerale.php", ["pagetitle" => "Formulaire de connexion", "cheminVueBody" => "utilisateur/formulaireConnexion.php"]);
    }

    public static function deconnexion() : void {
        if(ConnexionUtilisateur::estConnecte()){
            ConnexionUtilisateur::deconnecter();
            MessageFlash::ajouter("success", "Vous avez été déconnecté");
        }
        ControleurUtilisateur::redirectionVersURL("controleurFrontal.php?action=afficherliste&controleur=chaussure");
    }

    public static function gererUtilisateur(){
        if (ConnexionUtilisateur::estAdmin()){
            $utilisateurs = (new UtilisateurRepository)->recuperer();
            $tabUtilisateur = [];
            foreach ($utilisateurs as $utilisateur){
                $tabUtilisateur[] = $utilisateur->formatTableau();
            }
            ControleurUtilisateur::afficherVue("vueGenerale.php", ["pagetitle" => "Gestion des utilisateurs", "cheminVueBody" => "utilisateur/gererUtilisateurs.php", "utilisateurs"=>$tabUtilisateur]);
        }else{
            ControleurUtilisateur::afficherMessageFlash ("danger", "Connectez-vous avec un compte administrateur", "?action=afficherListe&controleur=chaussure");
        }
    }

}
?>