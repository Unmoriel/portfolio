<?php

namespace App\EShop\Controleur;

use App\EShop\Lib\ConnexionUtilisateur;
use App\EShop\Lib\MessageFlash;
use App\EShop\Modele\DataObject\Panier;
use App\EShop\Modele\Repository\ChaussureRepository;

class ControleurPanier extends ControleurGenerique
{
    public static function afficherPanier(): void
    {
        $panier = Panier::getPanier();
        $tabChaussures = [];
        foreach ($panier->getListeIdChaussures() as $idChaussure => $quantite) {
            $tabChaussures[$idChaussure] = (new ChaussureRepository())->recupererParClePrimaire($idChaussure)->formatTableau();
            $tabChaussures[$idChaussure]["quantiteTag"] = $quantite;
        }
        ControleurGenerique::afficherVue("vueGenerale.php", ["pagetitle" => "Panier", "cheminVueBody" => "panier/liste.php", "chaussures" => $tabChaussures, "prixTotal" => $panier->getPrixTotal()]);
    }

    public static function ajouterPanier(){
        if(!isset($_GET['idChaussure'])){
            ControleurGenerique::afficherMessageFlash ("danger", "Aucun id de chaussure n'a été fourni", "?action=afficherListe&controleur=chaussure");
        }else {
            Panier::getPanier()->ajouter($_GET['idChaussure']);
            $modele = (new ChaussureRepository())->recupererParClePrimaire($_GET['idChaussure'])->getModele();
            MessageFlash::ajouter("success", "La chaussure $modele a été ajoutée au panier");
            ControleurPanier::redirectionVersURL("?action=afficherListe&controleur=chaussure");
        }
    }

    public static function supprimerDuPanier(){
        if(!isset($_GET['idChaussure'])){
            ControleurGenerique::afficherMessageFlash ("danger", "Aucun id de chaussure n'a été fourni", "?action=afficherPanier&controleur=chaussure");
        }else {
            Panier::getPanier()->retirer($_GET['idChaussure']);
            MessageFlash::ajouter("success", "La chaussure a été retirée du panier");
            ControleurPanier::afficherPanier();
        }
    }

    public static function viderPanier(){
        Panier::getPanier()->vider();
        ControleurPanier::afficherPanier();
    }
}