<?php

namespace App\EShop\Controleur;
use App\EShop\Lib\ConnexionUtilisateur;
use App\EShop\Lib\MessageFlash;
use App\EShop\Lib\MotDePasse;
use App\EShop\Lib\FiltreControleur;
use App\EShop\Modele\DataObject\Chaussure;
use App\EShop\Modele\Repository\ChaussureRepository;
use JetBrains\PhpStorm\NoReturn;

class ControleurGenerique
{
    protected static function verifierAdmin(): void
    {
        if(!ConnexionUtilisateur::estAdmin()){
            ControleurGenerique::afficherMessageFlash ("danger", "Connectez-vous avec un compte administrateur", "?action=afficherListe&controleur=chaussure");
        }
    }

    #[NoReturn] public static function afficherMessageFlash (string $type, string $message, string $redirection): void
    {
        MessageFlash::ajouter($type, $message);
        self::redirectionVersURL($redirection);
    }

    protected static function afficherVue(string $cheminVue, array $parametres = []): void
    {
        $messagesFlash = MessageFlash::lireTousMessages();
        extract($parametres); // Crée des variables à partir du tableau $parametres
        require __DIR__ . "/../vue/$cheminVue"; // Charge la vue
    }

    public static function supprimerPreference(): void
    {
        $redirection = $_GET['redirection'];
        $nomFiltreString = $_GET['nomFiltre'];
        $nomFiltre = explode(',', $nomFiltreString);
        $nomFiltre = array_map('trim', $nomFiltre);
            FiltreControleur::supprimer($nomFiltre);
            MessageFlash::ajouter("info","Préférence supprimée");
        switch ($redirection){
            case "chaussure":
                ControleurGenerique::redirectionVersURL("controleurFrontal.php?action=afficherliste&controleur=chaussure");
                break;
            case "utilisateur":
                ControleurGenerique::redirectionVersURL("controleurFrontal.php?action=gererUtilisateur&controleur=utilisateur");
                break;
            case "commande":ControleurGenerique::redirectionVersURL("controleurFrontal.php?action=gererCommandes&controleur=commande");
                break;
            case "GererChaussure":ControleurGenerique::redirectionVersURL("controleurFrontal.php?action=gererChaussures&controleur=chaussure");
                break;
        }
    }



    public static function enregistrerPreference(): void
    {
        $redirection = $_GET['redirection'];
        $nomFiltreString = $_GET['nomFiltre'];
        $nomFiltre = explode(',', $nomFiltreString);
        $nomFiltre = array_map('trim', $nomFiltre);
        if (FiltreControleur::existe($nomFiltre)) {
            FiltreControleur::supprimer($nomFiltre);
        }
            for ($i = 0; $i < count($nomFiltre); $i++) {
                if (isset($_GET[$nomFiltre[$i]]) && $_GET[$nomFiltre[$i]] != "Aucune Preferences") {
                    $filtre[$nomFiltre[$i]] = $_GET[$nomFiltre[$i]];
                }
            }
        if ($filtre == null ) {
            MessageFlash::ajouter("info","Aucune préférence enregistrée");
            switch ($redirection){
                case "chaussure":
                    ControleurGenerique::redirectionVersURL("controleurFrontal.php?action=afficherliste&controleur=chaussure");
                    break;
                case "utilisateur":
                    ControleurGenerique::redirectionVersURL("controleurFrontal.php?action=gererUtilisateur&controleur=utilisateur");
                    break;
                case "commande":ControleurGenerique::redirectionVersURL("controleurFrontal.php?action=gererCommandes&controleur=commande");
                    break;
                case "GererChaussure":ControleurGenerique::redirectionVersURL("controleurFrontal.php?action=gererChaussures&controleur=chaussure");
                    break;
            }
        }
        else{
            FiltreControleur::enregistrer($filtre, $nomFiltre);
            MessageFlash::ajouter("info","Préférence enregistrée");
            switch ($redirection){
                case "chaussure":
                    ControleurGenerique::redirectionVersURL("controleurFrontal.php?action=afficherliste&controleur=chaussure");
                    break;
                case "utilisateur":
                    ControleurGenerique::redirectionVersURL("controleurFrontal.php?action=gererUtilisateur&controleur=utilisateur");
                    break;
                case "commande":ControleurGenerique::redirectionVersURL("controleurFrontal.php?action=gererCommandes&controleur=commande");
                    break;
                case "GererChaussure":ControleurGenerique::redirectionVersURL("controleurFrontal.php?action=gererChaussures&controleur=chaussure");
                    break;
            }
        }
    }

    #[NoReturn] public static function redirectionVersURL(string $url): void
    {
        header("Location: $url");
        exit();
    }
}