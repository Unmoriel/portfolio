<?php
use App\EShop\Controleur\ControleurChaussure;
use App\EShop\Controleur\ControleurGenerique;
use App\EShop\Lib\FiltreControleur;
require_once __DIR__ . '/../src/Lib/Psr4AutoloaderClass.php';
// initialisation
$loader = new App\EShop\Lib\Psr4AutoloaderClass();
$loader->register();
// enregistrement d'une association "espace de nom" → "dossier"
$loader->addNamespace('App\EShop', __DIR__ . '/../src');

if(isset($_GET['controleur'])) {
    $controleur = $_GET['controleur'];
}
else{
    $controleur = "generique";
}
$nomDeClasseControleur = "App\\EShop\\Controleur\\Controleur" . ucfirst($controleur);
if (!class_exists($nomDeClasseControleur)) {
    ControleurGenerique::afficherMessageFlash ("danger", "Controleur inconnu", "?action=afficherListe&controleur=chaussure");
}
else{
    if (isset($_GET['action'])) {
        $action = $_GET['action'];
        if (method_exists($nomDeClasseControleur, $action)) {
            $nomDeClasseControleur::$action();
        }
        else {
            $nomDeClasseControleur::afficherMessageFlash ("danger", "Action inconnue", "?action=afficherListe&controleur=chaussure");
        }
    }
    else {
        ControleurChaussure::afficherListe();
    }
}


?>

