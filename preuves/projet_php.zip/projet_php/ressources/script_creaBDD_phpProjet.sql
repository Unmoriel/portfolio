DROP TABLE IF EXISTS `georgesa`.`v_DetailCommande`;
DROP TABLE IF EXISTS `georgesa`.`v_Commande`;
DROP TABLE IF EXISTS `georgesa`.`v_Chaussure`;
DROP TABLE IF EXISTS `georgesa`.`v_Utilisateurs`;
DROP TABLE IF EXISTS `georgesa`.`v_Marques`;

CREATE OR REPLACE TABLE v_Marques(
    idMarque VARCHAR(50),
    nomMarque VARCHAR(50),
    adresse VARCHAR(50),
    mail VARCHAR(50),
    PRIMARY KEY(idMarque)
) ENGINE = InnoDB;


CREATE OR REPLACE TABLE v_Utilisateurs(
    mail VARCHAR(256),
    mailAVerifier VARCHAR(256),
    mdpHache VARCHAR(256),
    nom VARCHAR(50),
    prenom VARCHAR(50),
    adresse VARCHAR(50),
    sexe ENUM('Femme', 'Homme'),
    age INT,
    admin BOOLEAN,
    nonce VARCHAR(32),
    PRIMARY KEY(mail)
) ENGINE = InnoDB;

CREATE OR REPLACE TABLE v_Commande(
   idCommande VARCHAR(50),
   dateCommande VARCHAR(50),
   login VARCHAR(50),
   PRIMARY KEY(idCommande),
   FOREIGN KEY(login) REFERENCES v_Utilisateurs(login)
) ENGINE = InnoDB;

CREATE OR REPLACE TABLE v_Chaussure(
    idChaussure VARCHAR(8),
    modele VARCHAR(50),
    pointure INT,
    cible ENUM('Femme', 'Homme', 'Enfant', 'Mixte'),
    categorie ENUM('Course à pied','Tennis','Basket','Ville','Chaussons','Luxe','Football') NOT NULL,
    prix FLOAT,
    idMarque VARCHAR(50),
    PRIMARY KEY(idChaussure),
    FOREIGN KEY(idMarque) REFERENCES v_Marques(idMarque)
) ENGINE = InnoDB;

CREATE OR REPLACE TABLE v_DetailCommande(
     idDetail VARCHAR(50),
     idCommande VARCHAR(50),
     idChaussure VARCHAR(50),
     PRIMARY KEY(idDetail),
     FOREIGN KEY(idCommande) REFERENCES v_Commande(idCommande),
     FOREIGN KEY(idChaussure) REFERENCES v_Chaussure(idChaussure)
) ENGINE = InnoDB;
