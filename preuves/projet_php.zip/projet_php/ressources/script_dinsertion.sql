
-- Insertion des données dans la table v_marque

INSERT INTO `v_Marques` (`idMarque`, `nomMarque`, `mail`, `adresse`) VALUES
('m1', 'Nike', 'nike@pro.fr', '1 rue de la victoire'),
('m2', 'Adidas', 'adidas@pro.fr', '2 rue de la victoire'),
('m3', 'Puma', 'puma@pro.fr', '3 rue de la victoire'),
('m4', 'Asics', 'asics@pro.fr', '4 rue de la victoire'),
('m5', 'New Balance', 'newbalance@pro.fr', '5 rue de la victoire'),
('m6', 'Reebok', 'reebok@pro.fr', '6 rue de la victoire'),
('m7', 'Converse', 'converse@pro.fr', '7 rue de la victoire'),
('m8', 'Skechers', 'skechers@pro.fr', '8 rue de la victoire'),
('m9', 'Salomon', 'salomon@pro.fr', '9 rue de la victoire'),
('m10', 'Mizuno', 'mizuno@pro.fr', '10 rue de la victoire'),
('m11', 'Vans', 'vans@pro.fr', '11 rue de la victoire'),
('m12', 'Under Armour', 'underarmour@pro.fr', '12 rue de la victoire');

-- Insertion des données dans la table Chaussures

INSERT INTO `v_Chaussure` (`idChaussure`, `idMarque`, `modele`, `pointure`, `cible`, `categorie`, `prix`) VALUES
('CH7422', 'm1', 'Air Max 270', 43, 'Femme','Course à pied' , 139.99),
('CH6959', 'm2', 'Ultra Boost', 37, 'Femme', 'Tennis', 89.99),
('CH2216', 'm5', 'Fresh Foam Zante', 39, 'Enfant', 'Tennis', 89.99),
('CH8902', 'm6', 'Nano X', 36, 'Mixte','Ville', 59.99),
('CH4554', 'm3', 'Cali Sport', 36, 'Homme','Basket', 109.99),
('CH9854', 'm12', 'HOVR Phantom', 39, 'Mixte','Ville', 139.99),
('CH6200', 'm9', 'Speedcross 5', 44, 'Enfant','Ville', 119.99),
('CH4904', 'm7', 'Chuck Taylor All Star', 36, 'Homme','Basket', 59.99),
('CH8252', 'm11', 'Old Skool', 39, 'Femme', 'Luxe',109.99),
('CH9474', 'm8', 'D''Lites', 43, 'Enfant','Basket', 69.99),
('CH5698', 'm4', 'GEL-Kayano', 43, 'Enfant','Luxe', 119.99),
('CH7806', 'm10', 'Wave Rider', 38, 'Enfant','Luxe', 109.99),
('CH6976', 'm12', 'Charged Assert 8', 37, 'Mixte', 'Football', 149.99),
('CH3669', 'm3', 'RS-X', 43, 'Femme','Football', 149.99),
('CH8067', 'm6', 'Classic Leather', 38, 'Femme','Football', 139.99),
('CH4192', 'm2', 'NMD R1', 42, 'Enfant','Chaussons', 79.99),
('CH4249', 'm4', 'GEL-Nimbus', 36, 'Enfant', 'Tennis', 99.99),
('CH7102', 'm11', 'Sk8-Hi', 37, 'Femme', 'Course à pied', 109.99),
('CH7201', 'm1', 'Air Force 1', 40, 'Enfant','Chaussons', 79.99),
('CH3641', 'm5', '990v5', 41, 'Enfant','Chaussons', 69.99),
('CH7584', 'm6', 'Nano 9', 39, 'Mixte','Chaussons', 109.99),
('CH8760', 'm10', 'Wave Inspire', 42, 'Mixte','Chaussons', 99.99),
('CH1017', 'm12', 'Curry 7', 45, 'Mixte', 'Basket', 129.99),
('CH1982', 'm8', 'Ultra Flex', 44, 'Femme', 'Course à pied', 129.99),
('CH8010', 'm4', 'GEL-Lyte III', 38, 'Enfant', 'Tennis', 129.99)


-- La création d'utilisateur est a faire par la biais du formulaire à cause du mdp haché
-- Même chose pour les commandes
