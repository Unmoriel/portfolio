package ocp1;

public abstract class Animal {

    private String nom;

    public Animal(String nom) {
        this.nom = nom;
    }
    public abstract void crier();


}
