package ocp1;

public class Main {

    public static void main(String[]args) {
        Animal chien = new Chien("Médor");
        Animal chat = new Chat("Félix");
        Animal oiseau = new Oiseau("Titi");
        chien.crier();
        chat.crier();
        oiseau.crier();
    }

}
