package srp2;

public class Main {

    public static void main(String[]args) {
        Rectangle rectangle = new Rectangle(100, 150);
        System.out.printf("L'aire du rectangle est %s\n", rectangle.aire());
        //Affiche une fenêtre contenant le rectangle.
        affichage affichage = new affichage(rectangle);
        affichage.setVisible(true);
    }

}
