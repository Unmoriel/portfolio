package srp2;

import javax.swing.*;
import java.awt.*;

public class affichage extends JFrame {
    public Rectangle rec;

    public affichage(Rectangle rec) {
        this.rec = rec;
        setSize(rec.getLargeur() * 2, rec.getHauteur() * 2);
        setTitle("Rectangle");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void paint(Graphics g) {
        g.drawRect(rec.getLargeur()/2, rec.getHauteur()/2, rec.getLargeur(), rec.getHauteur());
    }
}
