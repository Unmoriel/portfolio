package srp2;

import javax.swing.*;

public class Rectangle extends JFrame{

    private int hauteur;

    private int largeur;

    public Rectangle(int hauteur, int largeur) {
        this.hauteur = hauteur;
        this.largeur = largeur;
    }



    public int getHauteur() {
        return hauteur;
    }

    public int getLargeur() {
        return largeur;
    }

    public int aire() {
        return hauteur * largeur;
    }

}
