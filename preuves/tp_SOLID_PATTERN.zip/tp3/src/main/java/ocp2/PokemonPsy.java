package ocp2;

public class PokemonPsy extends Pokemon{

    public PokemonPsy(String nom, int vieMax) {
            super(nom, vieMax);
        }

    public int getDegats() {
            return 60;
        }

    public String nomAttaque() {
        return "Psy";
    }

    @Override
    public String toString() {
        return "Je suis " + getNom() + " un pokemon de type Eau";
    }
}
