package ocp2;

import java.util.Random;

public class PokemonEau extends Pokemon {


    public PokemonEau(String nom, int vieMax) {
        super(nom, vieMax);
    }

    public int getDegats() {
        Random random = new Random();
        return 50 + random.nextInt(30);
    }

    public String nomAttaque(){
        return "Hydrocanon";
    }

    @Override
    public String toString() {
        return "Je suis " + getNom() + " un pokemon de type Eau";
    }

}
