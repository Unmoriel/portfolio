package ocp2;

import java.util.Random;

public class PokemonNormal extends Pokemon{

    public PokemonNormal(String nom, int vieMax) {
        super(nom, vieMax);
    }

    public int getDegats() {
        Random r = new Random();
        if(r.nextInt(100) < 10){
            return 100;
        }else{
            return 50;
        }
    }

    @Override
    public String nomAttaque(){
        return "Charge";
    }
    @Override
    public String toString() {
        return "Je suis " + getNom() + " un pokemon de type Normal";
    }
}
