package ocp2;

public class PokemonFeu extends Pokemon {


    public PokemonFeu(String nom, int vieMax) {
        super(nom, vieMax);
    }

    public int getDegats() {
        return 60;
    }

    public String nomAttaque() {
        return "Brulure";
    }

    @Override
    public String toString() {
        return "Je suis " + getNom() + " un pokemon de type Feu";
    }
}
