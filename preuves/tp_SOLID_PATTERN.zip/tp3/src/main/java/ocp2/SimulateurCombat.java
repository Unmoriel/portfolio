package ocp2;

import java.util.Random;

public class SimulateurCombat {

    public void simulerCombat(Pokemon pokemon1, Pokemon pokemon2) {
        Pokemon attaquant, victime;
        System.out.println(pokemon1);
        System.out.println(pokemon2);
        System.out.println("Début du combat!");
        while(pokemon1.estVivant() && pokemon2.estVivant()) {
            Random random = new Random();
            if(random.nextInt() <= 50) {
                attaquant = pokemon1;
                victime = pokemon2;
            }
            else {
                attaquant = pokemon2;
                victime = pokemon1;
            }
            attaquer(attaquant, victime);
            if(!victime.estKO()) {
                attaquer(victime, attaquant);
            }
        }
        Pokemon vainqueur, ko;
        if(pokemon1.estKO()) {
            vainqueur = pokemon2;
            ko = pokemon1;
        }
        else {
            vainqueur = pokemon1;
            ko = pokemon2;
        }
        System.out.printf("%s est KO!\n", ko.getNom());
        System.out.printf("Victoire de %s!\n", vainqueur.getNom());
        pokemon1.restaurer();
        pokemon2.restaurer();
    }

    private void attaquer(Pokemon attaquant, Pokemon victime) {
        victime.attaquer(attaquant.getDegats());

        System.out.printf("%s attaque : %s!\n", attaquant.getNom(), attaquant.nomAttaque());
        System.out.printf("PV de %s : %s\n", victime.getNom(), victime.getPointsDeVie());
    }

}
