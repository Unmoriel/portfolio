package ocp2;

public abstract class Pokemon {

    private String nom;

    private int vieMax;

    private int pointsDeVie;

    public Pokemon(String nom, int vieMax) {
        this.nom = nom;
        this.vieMax = vieMax;
        pointsDeVie = vieMax;
    }
    public String getNom() {
        return nom;
    }

    public int getPointsDeVie() {
        return pointsDeVie;
    }

    public void restaurer() {
        pointsDeVie = vieMax;
    }

    public boolean estVivant() {
        return pointsDeVie > 0;
    }

    public boolean estKO() {
        return !estVivant();
    }

    public void attaquer(int degats) {
        pointsDeVie -= degats;
        if(pointsDeVie < 0) {
            pointsDeVie = 0;
        }
    }

    public abstract String nomAttaque();
    public abstract int getDegats();

    @Override
    public abstract String toString();
}
