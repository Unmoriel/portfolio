package ocp2;

import java.util.Random;

public class PokemonElectrique extends Pokemon{

    public PokemonElectrique(String nom, int vieMax) {
        super(nom, vieMax);
    }

    public int getDegats() {
        Random random = new Random();
        return 20 + random.nextInt(80);
    }

    public String nomAttaque(){
        return "Eclair";
    }
    @Override
    public String toString() {
        return "Je suis " + getNom() + " un pokemon de type Electrique";
    }
}
