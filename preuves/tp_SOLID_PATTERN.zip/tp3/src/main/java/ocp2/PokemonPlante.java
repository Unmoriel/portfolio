package ocp2;

import java.util.Random;

public class PokemonPlante extends Pokemon {

    public PokemonPlante(String nom, int vieMax) {
        super(nom, vieMax);
    }

    public int getDegats() {
        Random random = new Random();
        return 40 + random.nextInt(40);
    }

    @Override
    public String nomAttaque(){
        return "Tranch'herbe";
    }
    @Override
    public String toString() {
        return "Je suis " + getNom() + " un pokemon de type Plante";
    }

}
