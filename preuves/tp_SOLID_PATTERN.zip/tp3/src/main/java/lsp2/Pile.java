package lsp2;

import java.util.Vector;

public class Pile<T> {
    private final Vector<T> pile = new Vector<>();

    public boolean estVide() {
        return pile.isEmpty();
    }

    public void empiler(T donnee) {
        pile.add(0, donnee);
    }

    public T depiler() {
        T data = pile.get(0);
        pile.remove(0);
        return data;
    }

    public T sommetPile() {
        return pile.get(0);
    }
}
