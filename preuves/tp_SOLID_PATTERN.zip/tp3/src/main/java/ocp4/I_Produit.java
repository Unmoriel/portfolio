package ocp4;

public interface I_Produit {

        double getPrix();
}
