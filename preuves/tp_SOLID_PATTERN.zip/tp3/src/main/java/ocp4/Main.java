package ocp4;

public class Main {

    public static void main(String[]args) {
        I_Produit produit = new ProduitAvecDatePeremptionProche(new ProduitAvecReduction(new Produit("Twix", 3), 0.50), 4);
        I_Produit produit2 = new ProduitAvecReduction(new ProduitAvecDatePeremptionProche(new Produit("Twix", 3), 4), 0.5);

        System.out.println(produit.getPrix());
        System.out.println(produit2.getPrix());


    }

}
