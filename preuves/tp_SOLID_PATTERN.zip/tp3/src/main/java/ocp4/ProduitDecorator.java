package ocp4;

abstract class ProduitDecorator implements I_Produit {
    protected I_Produit produit;

    public ProduitDecorator(I_Produit produit) {
        this.produit = produit;
    }

    public double getPrix() {
        return produit.getPrix();
    }
}
