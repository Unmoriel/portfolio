package ocp4;

public class ProduitAvecDatePeremptionProche  extends ProduitDecorator{
        private int datePeremption;

        public ProduitAvecDatePeremptionProche(I_Produit produit, int datePeremption) {
            super(produit);
            this.datePeremption = datePeremption;
        }

        public int getDatePeremption() {
            return datePeremption;
        }

        public void setDatePeremption(int datePeremption) {
            this.datePeremption = datePeremption;
        }

        @Override
        public double getPrix() {
            if (datePeremption < 5) {
                return produit.getPrix() * 0.5;
            }
            return produit.getPrix();
        }
}
