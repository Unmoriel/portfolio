package ocp4;

public class ProduitAvecReduction extends ProduitDecorator{
    private double reduction;

    public ProduitAvecReduction(I_Produit produit, double reduction) {
        super(produit);
        this.reduction = reduction;
    }

    @Override
    public double getPrix() {
        if(reduction > produit.getPrix())
            return 0;
        else{
            return produit.getPrix() - reduction;
        }
    }
}
