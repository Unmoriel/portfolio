package heritage;

public class CompteBancaire {

    private double solde = 0.0;

    public double getSolde() {
        return solde;
    }

    public void effectuerTransaction(double montant) {
        solde += montant;
    }

    public void effectuerTransactions(double[] montants) {
        for (double montant : montants) {
            effectuerTransaction(montant);
        }
    }
}
