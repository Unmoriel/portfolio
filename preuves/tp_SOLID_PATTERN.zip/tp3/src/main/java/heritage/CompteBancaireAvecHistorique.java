package heritage;

import java.util.List;
import java.util.Vector;

public class CompteBancaireAvecHistorique extends CompteBancaire {

    private List<Double> historiqueTransactions = new Vector<>();

    @Override
    public void effectuerTransaction(double montant) {
        super.effectuerTransaction(montant);
        historiqueTransactions.add(montant);
    }

    @Override
    public void effectuerTransactions(double[] montants) {
        super.effectuerTransactions(montants);
    }

    public int getNombreTransactions() {
        return this.historiqueTransactions.size();
    }

    public void afficherTransactions() {
        for(int i=0; i < historiqueTransactions.size(); i++) {
            System.out.printf("Transaction %s : %s€\n", i+1, historiqueTransactions.get(i));
        }
    }
}
