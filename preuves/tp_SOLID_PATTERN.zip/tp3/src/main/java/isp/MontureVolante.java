package isp;

public interface MontureVolante extends Monture{
    double getEnduranceVol();
}
