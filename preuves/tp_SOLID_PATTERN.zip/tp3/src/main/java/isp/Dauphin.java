package isp;

public class Dauphin extends Creature implements MontureAquatique{

        public Dauphin(String nom, Rarete rarete) {
            super(nom, rarete);
        }

        public String getNomMonture() {
            return getNom();
        }
        public double getVitesseMonture() {
            return 45;
        }
        public double getTempsSousEau() {
            return 15;
        }
}
