package isp;

public interface MontureDragon extends MontureTerrestre, MontureVolante{
    double getPuissanceFeu();
}
