package isp;

public class Rhinoceros extends Creature implements MontureTerrestre{

    public Rhinoceros(String nom, Rarete rarete) {
        super(nom, rarete);
    }

    public String getNomMonture() {
        return getNom();
    }
    public double getVitesseMonture() {
        return 30;
    }
    public double getEnduranceMonture() {
        return 100;
    }
}
