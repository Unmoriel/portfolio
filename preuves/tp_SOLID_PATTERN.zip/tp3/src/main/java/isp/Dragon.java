package isp;

public abstract class Dragon extends Creature implements MontureDragon{

    public Dragon(String nom, Rarete rarete) {
        super(nom, rarete);
    }

    public String getNomMonture() {
        return getNom();
    }

    public double getVitesseMonture() {
        return 400;
    }

    public double getEnduranceVol() {
        return 120;
    }

    @Override
    public double getPuissanceFeu() {
        return 200;
    }
}
