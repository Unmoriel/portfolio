package isp;

public interface Monture {

    String getNomMonture();

    double getVitesseMonture();


}
