package isp;

public interface MontureTerrestre extends Monture{
    double getEnduranceMonture();
}
