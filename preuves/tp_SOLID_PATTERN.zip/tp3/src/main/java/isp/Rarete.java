package isp;

public enum Rarete {
    BASIQUE,
    COMMUN,
    RARE,
    EPIQUE,
    LEGENDAIRE;
}
