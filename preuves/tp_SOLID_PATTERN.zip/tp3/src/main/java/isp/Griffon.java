package isp;

public class Griffon extends Creature implements MontureVolante{

    public Griffon(String nom, Rarete rarete) {
        super(nom, rarete);
    }

    public String getNomMonture() {
        return getNom();
    }

    public double getVitesseMonture() {
        return 300;
    }

    public double getEnduranceVol() {
        return 40;
    }
}
