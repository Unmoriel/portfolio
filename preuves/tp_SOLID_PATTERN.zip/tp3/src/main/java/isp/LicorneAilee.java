package isp;

public class LicorneAilee extends Creature implements MontureTerrestre, MontureVolante{

        public LicorneAilee(String nom, Rarete rarete) {
            super(nom, rarete);
        }

        public String getNomMonture() {
            return getNom();
        }
        public double getVitesseMonture() {
            return 75;
        }
        public double getEnduranceMonture() {
            return 50;
        }
        public double getEnduranceVol() {
            return 20;
        }
}
