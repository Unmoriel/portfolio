package isp;

public class Tigre extends Creature implements MontureTerrestre {

    private int niveauFerocite;

    public Tigre(String nom, Rarete rarete, int niveauFerocite) {
        super(nom, rarete);
        this.niveauFerocite = niveauFerocite;
    }

    @Override
    public String getNomMonture() {
        return this.getNom();
    }

    @Override
    public double getVitesseMonture() {
        return 80;
    }

    @Override
    public double getEnduranceMonture() {
        return 15 * niveauFerocite;
    }

}
