package isp;

public abstract class Creature {

    private String nom;

    private Rarete rarete;

    public Creature(String nom, Rarete rarete) {
        this.nom = nom;
        this.rarete = rarete;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Rarete getRarete() {
        return rarete;
    }
}
