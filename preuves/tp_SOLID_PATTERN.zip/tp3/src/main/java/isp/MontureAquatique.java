package isp;

public interface MontureAquatique extends Monture {
    double getTempsSousEau();
}
