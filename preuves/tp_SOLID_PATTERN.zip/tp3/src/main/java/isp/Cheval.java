package isp;

public class Cheval extends Creature implements MontureTerrestre {

    public Cheval(String nom, Rarete rarete) {
        super(nom, rarete);
    }

    @Override
    public String getNomMonture() {
        return getNom();
    }

    @Override
    public double getVitesseMonture() {
        return 50;
    }

    @Override
    public double getEnduranceMonture() {
        return 40;
    }

}
