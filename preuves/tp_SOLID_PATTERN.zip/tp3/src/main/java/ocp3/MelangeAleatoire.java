package ocp3;

import java.util.Random;

public class MelangeAleatoire implements Melange{
    public void melanger(Carte[] cartes) {
        Random rand = new Random();
        for(int i = 0; i < 52; i++) {
            int j = i + rand.nextInt(52 - i);
            Carte temp = cartes[i];
            cartes[i] = cartes[j];
            cartes[j] = temp;
        }
    }
}
