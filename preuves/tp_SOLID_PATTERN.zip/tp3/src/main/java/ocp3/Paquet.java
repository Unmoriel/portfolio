package ocp3;

import java.util.Arrays;
import java.util.Random;

public class Paquet {

    private Carte[] cartes;

    private Tri typeTri;

    private Melange typeMelange;

    public Paquet(Tri typeTri, Melange typeMelange) {
        this.typeTri = typeTri;
        this.typeMelange = typeMelange;
        cartes = new Carte[52];
        int i = 0;
        for (Enseigne enseigne : Enseigne.values()) {
            for (int j = 1; j <= 13; j++) {
                cartes[i] = new Carte(j, enseigne);
                i++;
            }
        }
        typeMelange.melanger(cartes);
    }

    public Carte[] getCartes() {
        return cartes;
    }

    public void setTypeTri(Tri typeTri) {
        this.typeTri = typeTri;
    }

    @Override
    public String toString() {
        String cartesStr = "";
        for (int i = 0; i < 52; i++) {
            cartesStr += cartes[i].toString() + "\n";
        }
        return cartesStr;
    }

    public void trier() throws Exception {
        typeTri.trier(cartes);
    }
}
