package ocp3;

public interface Melange {

    void melanger(Carte [] cartes);
}
