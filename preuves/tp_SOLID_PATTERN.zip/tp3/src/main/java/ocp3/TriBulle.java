package ocp3;

public class TriBulle implements Tri{
    public void trier(Carte[] cartes){
        System.out.println("Tri par bulle");
        for(int i = 0; i < 52; i++) {
            for(int j = 0; j < 52 - i - 1; j++) {
                if(cartes[j].compareTo(cartes[j+1]) > 0) {
                    Carte temp = cartes[j];
                    cartes[j] = cartes[j+1];
                    cartes[j+1] = temp;
                }
            }
        }
    }
}
