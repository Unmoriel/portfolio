package ocp3;

public class Carte implements Comparable<Carte> {

    private int numero;

    private Enseigne enseigne;

    public Carte(int numero, Enseigne enseigne) {
        this.numero = numero;
        this.enseigne = enseigne;
    }

    public int getNumero() {
        return numero;
    }

    @Override
    public String toString() {
        return String.format("%s de %s", numero, enseigne.toString().toLowerCase());
    }

    @Override
    public int compareTo(Carte c2) {
        if(this.enseigne.ordinal() == c2.enseigne.ordinal()) {
            return this.numero - c2.numero;
        }
        else {
            return this.enseigne.ordinal() - c2.enseigne.ordinal();
        }
    }
}
