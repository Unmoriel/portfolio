package ocp3;

public enum Enseigne {

    COEUR,
    PIQUE,
    TREFLE,
    CARREAU;

}
