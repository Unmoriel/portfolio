package ocp3;

import java.util.Arrays;

public class TriJava implements Tri{
    public void trier(Carte[] cartes) {
        System.out.println("Tri de java");
        Arrays.sort(cartes);
    }

}
