package ocp3;

public class TriEnumeration implements Tri{

    public void trier(Carte[] cartes) {
        System.out.println("Tri selection");
        for(int i = 0; i < 52; i++) {
            int indexMin = -1;
            for(int j = i; j < 52; j++) {
                if(indexMin == -1 || cartes[j].compareTo(cartes[indexMin]) < 0) {
                    indexMin = j;
                }
            }
            Carte temp = cartes[i];
            cartes[i] = cartes[indexMin];
            cartes[indexMin] = temp;
        }
    }
}
