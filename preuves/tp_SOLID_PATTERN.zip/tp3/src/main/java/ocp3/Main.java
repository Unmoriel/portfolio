package ocp3;

public class Main {

    public static void main(String[]args) {
        Paquet paquet = new Paquet(new TriBulle(), new MelangeAleatoire());
        System.out.println(paquet);
        try {
            paquet.trier();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(paquet);
    }

}
