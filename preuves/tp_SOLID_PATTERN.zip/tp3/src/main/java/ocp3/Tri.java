package ocp3;

public interface Tri {

        void trier(Carte [] cartes) throws Exception;
}
