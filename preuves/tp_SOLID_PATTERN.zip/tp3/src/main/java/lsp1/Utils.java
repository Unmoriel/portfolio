package lsp1;

public class Utils {
    public static void agrandirRectangle(Rectangle rectangle, int facteur) {
        rectangle.setHauteur(rectangle.getHauteur() * facteur);
        rectangle.setLargeur(rectangle.getLargeur() * facteur);
    }

}
