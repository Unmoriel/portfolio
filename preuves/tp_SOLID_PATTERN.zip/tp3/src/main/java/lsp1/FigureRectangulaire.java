package lsp1;

public interface FigureRectangulaire {
    int getHauteur();
    int getLargeur();
    int aire();
}