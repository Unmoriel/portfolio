package lsp1;

import org.w3c.dom.css.Rect;

public class Carre implements FigureRectangulaire {
    private Rectangle rectangle;

    public Carre(Rectangle rectangle) {
        this.rectangle = rectangle;
    }

    public void setTailleCote(int taille) {
        rectangle.setHauteur(taille);
        rectangle.setLargeur(taille);
    }

    public int getHauteur() {
        return rectangle.getHauteur();
    }

    public int getLargeur() {
        return rectangle.getLargeur();
    }

    public int aire() {
        return rectangle.aire();
    }

}
