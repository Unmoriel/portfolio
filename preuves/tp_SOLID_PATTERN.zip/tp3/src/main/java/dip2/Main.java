package dip2;

import dip2.ihm.IHMUtilisateur;

public class Main {

    public static void main(String[]args) {
        IHMUtilisateur ihm = new IHMUtilisateur();
        ihm.menu();
    }

}
