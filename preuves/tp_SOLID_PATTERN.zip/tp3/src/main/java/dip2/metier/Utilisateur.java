package dip2.metier;

public class Utilisateur {

    private String login;

    private String adresseEmail;

    private String motDePasse;

    public Utilisateur(String login, String adresseEmail, String motDePasse) {
        this.login = login;
        this.adresseEmail = adresseEmail;
        this.motDePasse = motDePasse;
    }

    public String getLogin() {
        return login;
    }

    public String getAdresseEmail() {
        return adresseEmail;
    }

    public String getMotDePasse() {
        return motDePasse;
    }

    @Override
    public String toString() {
        return String.format("%s : %s", login, adresseEmail);
    }
}
