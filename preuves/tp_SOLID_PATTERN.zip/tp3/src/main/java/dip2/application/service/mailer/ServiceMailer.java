package dip2.application.service.mailer;

public class ServiceMailer {

    public void envoyerMail(String objet, String[]destinataires, String contenu) {
        System.out.println("Mail envoye!");
    }

}
