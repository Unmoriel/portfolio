package dip2.application.service.utilisateur;

import dip2.application.service.chiffrement.HasheurMD5;
import dip2.application.service.exception.ServiceException;
import dip2.application.service.mailer.ServiceMailer;
import dip2.metier.Utilisateur;
import dip2.stockage.StockageUtilisateurMemoire;

import java.util.regex.Pattern;

public class ServiceUtilisateur {

    private StockageUtilisateurMemoire stockage = new StockageUtilisateurMemoire();

    private HasheurMD5 hasher = new HasheurMD5();

    private ServiceMailer mailer = new ServiceMailer();

    public void creerUtilisateur(String login, String adresseEmail, String motDePasse) throws ServiceException {
        if(stockage.getUtilisateurDepuisMemoire(login) != null) {
            throw new ServiceException("L'utilisateur existe deja!");
        }
        if(login.length() < 6) {
            throw new ServiceException("Le login doit contenir au moins 6 caracteres!");
        }
        if(login.length() > 12) {
            throw new ServiceException("Le login ne doit pas contenir plus de 12 caracteres!");
        }
        if(!Pattern.matches("^(.+)@(\\S+)$", adresseEmail)) {
            throw new ServiceException("Adresse email invalide!");
        }
        if(!Pattern.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#&()–[{}]:;',?/*~$^+=<>]).{8,20}$", motDePasse)) {
            throw new ServiceException("Le mot de passe doit contenir entre 8 et 20 caracteres et doit contenir au moins un chiffre, une minuscule, une majuscule et un caractere special.");
        }
        String motDePasseChiffre = hasher.hasherMD5(motDePasse);
        Utilisateur utilisateur = new Utilisateur(login, adresseEmail, motDePasseChiffre);
        stockage.enregistrerUtilisateurdansLaMemoire(utilisateur);
        mailer.envoyerMail("Compte cree!", new String[]{adresseEmail}, "Le compte a bien ete cree!");
    }

    public void connexion(String login, String motDepasse) throws ServiceException {
        Utilisateur utilisateur = stockage.getUtilisateurDepuisMemoire(login);
        if(utilisateur == null) {
            throw new ServiceException("Utilisateur inexistant");
        }
        String motDePasseEnregistre = utilisateur.getMotDePasse();
        String motDePasseChiffre = hasher.hasherMD5(motDepasse);
        if(!motDePasseEnregistre.equals(motDePasseChiffre)) {
            throw new ServiceException("Mot de passe incorrect!");
        }
    }

}
