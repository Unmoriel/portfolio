package dip2.application.controller;

import dip2.application.service.exception.ServiceException;
import dip2.application.service.utilisateur.ServiceUtilisateur;

import java.util.Map;

public class ControllerUtilisateur {

    private ServiceUtilisateur serviceUtilisateur = new ServiceUtilisateur();

    public void actionCreerUtilisateur(Map<String, String> requete) {
        if(requete.size() < 3) {
            System.err.println("Au moins trois paramètres attendus!");
            return;
        }
        if(!requete.containsKey("login")) {
            System.err.println("Login manquant!");
            return;
        }
        if(!requete.containsKey("adresseEmail")) {
            System.err.println("Adresse email manquante!");
            return;
        }
        if(!requete.containsKey("motDePasse")) {
            System.err.println("Mot de passe manquant!");
            return;
        }
        String login = requete.get("login");
        String adresseEmail = requete.get("adresseEmail");
        String motDePasse = requete.get("motDePasse");
        if(login == null || adresseEmail == null || motDePasse == null) {
            System.err.println("Paramètres invalides");
            return;
        }
        try {
            serviceUtilisateur.creerUtilisateur(login, adresseEmail, motDePasse);
            System.out.println("Inscription reeussie.");
        }
        catch (ServiceException e) {
            System.err.println(e.getMessage());
        }
    }

    public void actionConnexion(Map<String, String> requete) {
        if(requete.size() < 2) {
            System.err.println("Au moins deux paramètres attendus!");
            return;
        }
        if(!requete.containsKey("login")) {
            System.err.println("Login manquant!");
            return;
        }
        if(!requete.containsKey("motDePasse")) {
            System.err.println("Mot de passe manquant!");
            return;
        }
        String login = requete.get("login");
        String motDePasse = requete.get("motDePasse");
        if(login == null || motDePasse == null) {
            System.err.println("Paramètres invalides");
            return;
        }
        try {
            serviceUtilisateur.connexion(login, motDePasse);
            System.out.println("Connexion reussie.");
        }
        catch (ServiceException e) {
            System.err.println(e.getMessage());
        }
    }

}
