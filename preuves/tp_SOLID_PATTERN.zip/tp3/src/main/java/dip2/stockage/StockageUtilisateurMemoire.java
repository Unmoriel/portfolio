package dip2.stockage;

import dip2.metier.Utilisateur;

import java.util.HashMap;
import java.util.Map;

public class StockageUtilisateurMemoire {

    private Map<String, Utilisateur> utilisateurs = new HashMap<>();

    public void enregistrerUtilisateurdansLaMemoire(Utilisateur utilisateur) {
        utilisateurs.put(utilisateur.getLogin(), utilisateur);
    }

    public Utilisateur getUtilisateurDepuisMemoire(String login) {
        if(!utilisateurs.containsKey(login)) {
            return null;
        }
        return utilisateurs.get(login);
    }

}
