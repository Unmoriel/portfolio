package dip2.stockage;

import dip2.metier.Utilisateur;

import java.io.*;
public class StockageUtilisateurFichier {

    public void enregistrerDansFichier(Utilisateur utilisateur) {
        try {
            File file = new File("./utilisateurs.csv");
            file.createNewFile();
            OutputStream output = new FileOutputStream(file, true);
            BufferedWriter writter = new BufferedWriter(new OutputStreamWriter(output));
            writter.write(String.format("%s;%s;%s\n", utilisateur.getLogin(), utilisateur.getAdresseEmail(), utilisateur.getMotDePasse()));
            writter.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public Utilisateur getUtilisateurDepuisFichier(String login) {
        try {
            File file = new File("./utilisateurs.csv");
            file.createNewFile();
            InputStream input = new FileInputStream(file);
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            String ligne;
            while ((ligne = reader.readLine()) != null) {
                String[] data = ligne.split(";");
                if(data[0].equals(login)) {
                    return new Utilisateur(data[0], data[1], data[2]);
                }
            }
            reader.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

}
