package dip2.ihm;

import dip2.application.controller.ControllerUtilisateur;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class IHMUtilisateur {

    private ControllerUtilisateur controller = new ControllerUtilisateur();

    public void menu() {
        while(true) {
            System.out.println("Que voulez-vous faire ? (inscription/connexion)");
            Scanner scanner = new Scanner(System.in);
            String action = scanner.nextLine();
            //Gestion peu qualitative de la partie "Commande"!
            //Dans le futur, utiliser le design pattern "Commande" serait plus judicieux!
            if(action.equals("inscription")) {
                creerUnNouvelUtilisateur();
            }
            else if(action.equals("connexion")) {
                connexionUtilisateur();
            }
            else {
                System.err.println("Action inconnue");
            }
        }
    }

    public void creerUnNouvelUtilisateur() {
        Map<String, String> requete = new HashMap<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Creation d'un nouvel utilisateur");
        System.out.println("Login ?");
        requete.put("login", scanner.nextLine());
        System.out.println("Adresse email ?");
        requete.put("adresseEmail", scanner.nextLine());
        System.out.println("Mot de passe ?");
        requete.put("motDePasse", scanner.nextLine());
        controller.actionCreerUtilisateur(requete);
    }

    public void connexionUtilisateur() {
        Map<String, String> requete = new HashMap<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Connexion");
        System.out.println("Login ?");
        requete.put("login", scanner.nextLine());
        System.out.println("Mot de passe ?");
        requete.put("motDePasse", scanner.nextLine());
        controller.actionConnexion(requete);
    }

}
