package srp1;

public class Operande {

        private int valeur;

        public Operande(int valeur) {
            this.valeur = valeur;
        }

        public int getValeur() {
            return valeur;
        }

        public Operande setValeur(int valeur) {
            this.valeur = valeur;
            return this;
        }

        @Override
        public String toString() {
            return "Resultat :" + valeur;
        }
}
