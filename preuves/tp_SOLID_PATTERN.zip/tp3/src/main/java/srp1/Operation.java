package srp1;

public class Operation {

    public static Operande addition(Operande x, Operande y) {
        return new Operande(x.getValeur() + y.getValeur());
    }

    public static Operande soustraction(Operande x, Operande y) {
        return new Operande(x.getValeur() - y.getValeur());
    }


}
