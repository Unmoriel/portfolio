package dip1;

public interface I_univ {


    public String getNom();
    public String getPrenom();

}
