package dip1;

public class Main {

    public static void main(String[]args) {
        Etudiant etudiant1 = new Etudiant("Tarembois", "Guy");
        Enseignant enseignant1 = new Enseignant("Bricot", "Judat");
        CompteUniversitaire compte1 = new CompteUniversitaire(enseignant1, new GenerateurLoginNormal());
        CompteUniversitaire compte2 = new CompteUniversitaire(etudiant1, new GenerateurLoginMelange());
        System.out.printf(
                "%s %s, login : %s\n",
                compte1.getDetenteur().getNom(),
                compte1.getDetenteur().getPrenom(),
                compte1.getLogin()
        );
        System.out.printf(
                "%s %s, login : %s\n",
                compte2.getDetenteur().getNom(),
                compte2.getDetenteur().getPrenom(),
                compte2.getLogin()
        );
    }

}
