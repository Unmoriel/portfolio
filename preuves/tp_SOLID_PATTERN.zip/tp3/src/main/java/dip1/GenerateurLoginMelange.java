package dip1;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class GenerateurLoginMelange implements I_generateurLogin{

    public String genererLogin(I_univ detenteur) {
        List<String> nomList = Arrays.asList(detenteur.getNom().split(""));
        Collections.shuffle(nomList);
        StringBuilder builder = new StringBuilder();
        for(String letter : nomList) {
            builder.append(letter);
        }
        return builder.toString();
    }
}
