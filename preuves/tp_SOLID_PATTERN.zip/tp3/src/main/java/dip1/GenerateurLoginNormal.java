package dip1;

public class GenerateurLoginNormal implements I_generateurLogin{

        public String genererLogin(I_univ detenteur) {
            return (detenteur.getNom() + detenteur.getPrenom().charAt(0)).toLowerCase();
        }
}
