package dip1;

public interface I_generateurLogin {

        public String genererLogin(I_univ detenteur);
}
