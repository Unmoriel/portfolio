package dip1;

public class CompteUniversitaire {

    private I_univ detenteur;
    private I_generateurLogin generateurLogin;

    private String login;

    public CompteUniversitaire(I_univ detenteur, I_generateurLogin generateurLogin) {
        this.detenteur = detenteur;
        this.generateurLogin = generateurLogin;
        genererLogin();
    }

    private void genererLogin() {
        login = generateurLogin.genererLogin(detenteur);
    }

    public String getLogin() {
        return login;
    }

    public I_univ getDetenteur() {
        return detenteur;
    }
}
