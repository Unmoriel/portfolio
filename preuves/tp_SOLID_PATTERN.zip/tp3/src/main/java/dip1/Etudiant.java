package dip1;

public class Etudiant implements I_univ{

    private String nomEtudiant;

    private String prenomEtudiant;

    public Etudiant(String nomEtudiant, String prenomEtudiant) {
        this.nomEtudiant = nomEtudiant;
        this.prenomEtudiant = prenomEtudiant;
    }

    public String getNom() {
        return nomEtudiant;
    }

    public String getPrenom() {
        return prenomEtudiant;
    }
}
