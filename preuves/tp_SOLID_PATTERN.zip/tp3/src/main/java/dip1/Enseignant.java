package dip1;

public class Enseignant implements I_univ{

    private String nomEnseignant;

    private String prenomEnseignant;

    public Enseignant(String nomEnseignant, String prenomEnseignant) {
        this.nomEnseignant = nomEnseignant;
        this.prenomEnseignant = prenomEnseignant;
    }

    public String getNom() {
        return nomEnseignant;
    }

    public String getPrenom() {
        return prenomEnseignant;
    }
}
