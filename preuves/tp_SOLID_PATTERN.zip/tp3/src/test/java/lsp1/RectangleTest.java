package lsp1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class RectangleTest {

    @Test
    public void testAire() {
        Rectangle rectangle = new Rectangle(5,5);
        assertEquals(25, rectangle.aire());
    }

    @Test
    public void testAireAgrandirRectangle() {
        Rectangle rectangle = new Rectangle(5,5);
        Utils.agrandirRectangle(rectangle, 2);
        assertEquals(100, rectangle.aire());
    }

}
