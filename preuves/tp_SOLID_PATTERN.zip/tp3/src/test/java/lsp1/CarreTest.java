package lsp1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CarreTest {
    private final Carre c = new Carre(new Rectangle(5, 5));

    @Test
    public void testAire() {
        assertEquals(25, c.aire());
    }

    @Test
    public void testChangementHauteurChangeAussiLargeur() {
        c.setTailleCote(10);
        assertEquals(10, c.getLargeur());
    }

    @Test
    public void testChangementLargeurChangeAussiHauteur() {
        c.setTailleCote(10);
        assertEquals(10, c.getHauteur());
    }

    @Test
    public void testChangementHauteurAire() {
        c.setTailleCote(10);
        assertEquals(100, c.aire());
    }

    @Test
    public void testChangementLargeurAire() {
        c.setTailleCote(10);
        assertEquals(100, c.aire());
    }

}
