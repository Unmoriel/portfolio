package dip2;

import dip2.application.service.exception.ServiceException;
import dip2.application.service.utilisateur.ServiceUtilisateur;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ServiceUtilisateurTest {

    @Test
    public void testCreerUtilisateurLoginTropPetit() {
        ServiceUtilisateur serviceUtilisateur = new ServiceUtilisateur();
        assertThrows(ServiceException.class, () -> {
            serviceUtilisateur.creerUtilisateur("test", "test@gmail.com", "TestTest1!");
        });
    }

    @Test
    public void testCreerUtilisateurLoginTropGrand() {
        ServiceUtilisateur serviceUtilisateur = new ServiceUtilisateur();
        assertThrows(ServiceException.class, () -> {
            serviceUtilisateur.creerUtilisateur("testtttttttttttttttttttttttttttttttttttttttttttttttttttttt", "test@gmail.com", "TestTest1!");
        });
    }
    @Test
    public void testCreerUtilisateurEmailInvalide() {
        ServiceUtilisateur serviceUtilisateur = new ServiceUtilisateur();
        assertThrows(ServiceException.class, () -> {
            serviceUtilisateur.creerUtilisateur("TestLogin", "testgmail.com", "TestTest1!");
        });
    }
    @Test
    public void testCreerUtilisateurValide() {
        ServiceUtilisateur serviceUtilisateur = new ServiceUtilisateur();
        assertDoesNotThrow(() -> {
            serviceUtilisateur.creerUtilisateur("TestLogin", "test@gmail.com", "TestTest1!");
        });
    }

}
