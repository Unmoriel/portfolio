package lsp2;

import org.junit.jupiter.api.Test;

import java.util.Stack;

import static org.junit.jupiter.api.Assertions.*;

public class PileTest {

    @Test
    public void testEmpilerDepiler() {
        Pile<Integer> pile = new Pile<>();
        pile.empiler(5);
        pile.empiler(9);
        pile.empiler(10);
        assertEquals(10, pile.depiler());
        assertEquals(9, pile.depiler());
        assertEquals(5, pile.depiler());
    }

    @Test
    public void testVide() {
        Pile<Integer> pile = new Pile<>();
        assertTrue(pile.estVide());
        pile.empiler(5);
        assertFalse(pile.estVide());
        pile.depiler();
        assertTrue(pile.estVide());
    }

    @Test
    public void testSommet() {
        Pile<Integer> pile = new Pile<>();
        pile.empiler(5);
        assertEquals(5, pile.sommetPile());
        pile.empiler(9);
        assertEquals(9, pile.sommetPile());
        pile.empiler(10);
        assertEquals(10, pile.sommetPile());
        pile.depiler();
        assertEquals(9, pile.sommetPile());
        pile.depiler();
        assertEquals(5, pile.sommetPile());
    }



}
