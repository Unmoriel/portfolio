package heritage;

import heritage.CompteBancaire;
import heritage.CompteBancaireAvecHistorique;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CompteBancaireTest {

    @Test
    public void testSolde() {
        CompteBancaire compteBancaire = new CompteBancaire();
        compteBancaire.effectuerTransaction(50);
        assertEquals(50, compteBancaire.getSolde());
        compteBancaire.effectuerTransactions(new double[]{5,-7,25,30,-50});
        assertEquals(53, compteBancaire.getSolde());
    }

    @Test
    public void testNombreTransactions() {
        CompteBancaireAvecHistorique compteBancaire = new CompteBancaireAvecHistorique();
        compteBancaire.effectuerTransaction(50);
        assertEquals(1, compteBancaire.getNombreTransactions());
        compteBancaire.effectuerTransactions(new double[]{5,-7,25,30,-50});
        assertEquals(6, compteBancaire.getNombreTransactions());
    }

}
