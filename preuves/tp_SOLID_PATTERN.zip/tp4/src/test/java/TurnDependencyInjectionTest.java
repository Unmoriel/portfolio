package yahtzee;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.util.Vector;
import static org.mockito.Mockito.*;

public class TurnDependencyInjectionTest {

    private Turn turn;
    private Vector<Dice> diceSpy;

    @BeforeEach
    public void setUp() {
        // Création de l'espion pour Vector<Dice>
        Vector<Dice> originalDice = new Vector<>(Combination.NUMBER_OF_DICE);
        diceSpy = Mockito.spy(originalDice);

        // Création d'un mock pour PlayerI
        PlayerI mockPlayer = Mockito.mock(PlayerI.class);

        // Injection de l'espion dans une instance de Turn
        turn = new Turn(mockPlayer);

        // Remplacement de l'attribut dice dans Turn par l'espion
        // Cette opération nécessite un accès au champ dice, ce qui peut être réalisé par réflexion ou en modifiant la visibilité du champ (non recommandé)
        // L'approche recommandée est d'ajouter une méthode setDice dans la classe Turn pour les besoins des tests, ou d'utiliser la réflexion
        //turn.setDice(diceSpy); ça marche pas
    }

    @Test
    public void testDiceBehavior() {
        // Le vecteur de dés est vide, vous devez donc remplir diceSpy avec des dés mockés avant d'utiliser turn

        // Création et ajout de dés mockés au vecteur
        for (int i = 0; i < Combination.NUMBER_OF_DICE; i++) {
            Dice mockDice = Mockito.mock(Dice.class);
            Mockito.when(mockDice.getValue()).thenReturn(i + 1); // Retourne des valeurs de 1 à 5 pour les dés
            diceSpy.add(mockDice);
        }

        // Utilisation de turn, par exemple en effectuant un roll
        turn.roll(); // Cela devrait utiliser les dés mockés au lieu des dés réels

        // Vérification que les dés ont été roulés
        for (Dice dice : diceSpy) {
            Mockito.verify(dice, times(1)).roll();
        }
    }
}
