import yahtzee.Dice;
import org.mockito.Mockito;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import yahtzee.FullHouseCombination;
import yahtzee.SixesCombination;

import java.util.Vector;


public class DiceCombinationTest {

    @Test
    public void mockSingleDice() {
        Dice mockDice = Mockito.mock(Dice.class);
        Mockito.when(mockDice.getValue()).thenReturn(5);

        assertEquals(5, mockDice.getValue(), "Le dé mocké doit retourner 5");
    }

    @Test
    public void mockDiceForCombinations() {
        // Création et programmation des dés pour un Full House
        Vector<Dice> diceForFullHouse = new Vector<>();
        for (int value : new int[]{2, 2, 3, 3, 3}) { // Exemple de valeurs pour un Full House
            Dice mockDice = Mockito.mock(Dice.class);
            Mockito.when(mockDice.getValue()).thenReturn(value);
            diceForFullHouse.add(mockDice);
        }

        // Création et programmation des dés pour Sixes
        Vector<Dice> diceForSixes = new Vector<>();
        for (int value : new int[]{6, 6, 2, 3, 4}) { // Exemple de valeurs incluant deux six
            Dice mockDice = Mockito.mock(Dice.class);
            Mockito.when(mockDice.getValue()).thenReturn(value);
            diceForSixes.add(mockDice);
        }

        FullHouseCombination fullHouseCombination = new FullHouseCombination(diceForFullHouse);
        SixesCombination sixesCombination = new SixesCombination(diceForSixes);

        // Test des scores selon la spécification
        assertEquals(25, fullHouseCombination.getScore(), "Le score d'un Full House doit être 25");
        assertEquals(12, sixesCombination.getScore(), "Le score pour les six doit être la somme des dés montrant six");
    }
}
