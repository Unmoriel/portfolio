import org.mockito.Mockito;
import yahtzee.Combination;
import yahtzee.FullHouseCombination;
import yahtzee.PlayerI;
import yahtzee.Turn;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class testTurn {
    private PlayerI player = Mockito.mock();

    private Turn turn;

    @BeforeEach
    public void setUp() {

        MockitoAnnotations.openMocks(this);
        turn = new Turn(player);
    }

    @Test
    public void testIllegalStateExceptions() {

        assertThrows(IllegalStateException.class, () -> {
            turn.end(Combination.Type.FULL_HOUSE);
        });

        turn.roll();
        turn.roll();
        turn.roll();

        assertThrows(IllegalStateException.class, () -> {
            turn.roll();
        });

        turn.end(Combination.Type.FULL_HOUSE);
        assertThrows(IllegalStateException.class, () -> {
            turn.end(Combination.Type.SIXES);
        });
    }

    @Test
    public void testNormalTurnScenario() {
        // On effectue des actions sur le tour sans déclencher d'exceptions

        // On simule le fait de sélectionner des dés et de lancer
        turn.selectForRoll(0); // On sélectionne un dé
        turn.roll(); // On effectue un lancer
        turn.unselectForRoll(0); // On désélectionne le dé

        // On simule la fin du tour avec FULL_HOUSE
        turn.end(Combination.Type.FULL_HOUSE);

        // On vérifie que addCombinationToScoreSheet a été appelé avec une combinaison de type FULL_HOUSE
        verify(player, times(1)).addCombinationToScoreSheet(any(FullHouseCombination.class));
    }
}


