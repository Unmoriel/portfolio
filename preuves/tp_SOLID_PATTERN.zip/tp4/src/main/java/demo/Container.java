package demo;

public interface Container {

    public void clear();

    public boolean putItem(Object o);

    public Object getItem();
}
