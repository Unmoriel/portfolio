package yahtzee;

public interface PlayerI {

    /**
     * Ajoute une combinaison à la feuille de score du joueur
     * @param combination la combinaison
     * @return true si la combinaison a bien été ajoutée à la feuille de score, et false si une combinaison similaire existait déjà dans la feuille de score
     */
    boolean addCombinationToScoreSheet(Combination combination);

    /**
     * Retourne le score actuel du joueur
     * @return le score actuel du joueur
     */
    int getScore();

}
