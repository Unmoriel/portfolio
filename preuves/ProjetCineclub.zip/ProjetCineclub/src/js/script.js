import {reactive, startReactiveDom} from "./reactive.js";


let autocompletion = document.getElementById('autocompletion');
let loading = document.getElementById('loading');
let requete = new XMLHttpRequest();

// reactive object conenant les membres, les films et l'utilisateur actuel
let data = reactive({
    membres: {}, // {id: Nom}
    films: {}, // {id: Titre}
    notes: [], // [{idMembre, idFilm, valeur}]
    user: null, // id de l'utilisateur actuel
    //Attention, les id des membres et des films sont convertis en string pour être utilisés comme clés

    getNomMembre: function(id) {
        return this.membres[String(id)];
    },
    getTitreFilm: function(id) {
        return this.films[String(id)];
    },
    ajouterMembre: function() {
        addMembre();
    },
    ajouterFilm: function() {
        addFilm();
    },
    closeOverlay: function() {
        closeOverlay();
    },
    listeMembreSelect: function() {
        return updateSelectList();
    },
    listeFilms: function() {
        return updateFilmTable();
    },
    listeMembres: function() {
        return updateMemberTable();
    },
    membreInfo: function(id) {
        infoMembre(id);
    },
    filmInfo: function(id) {
        infoFilm(id);
    },
    changeNote: async function (idFilm, value) {
        let formData = new FormData();
        formData.append('action', 'update');
        formData.append('membre', data.user);
        formData.append('film', idFilm);
        formData.append('note', value);
        let req = await fetch(`php/set.php?`, {
            method: 'POST',
            body: formData
        });
        raffraichissement();
    },
    changeLogin: function() {
        let selectedLogin = document.getElementById('choix-membre');
        data.user = selectedLogin.value;
        raffraichissement();
    },
    supprMembre: function(id){
        deleteMembre(id);
    },
    supprFilm: function(id){
        deleteFilm(id);
    }
}, 'data');

/**
 * Initialisation de la page
 */

function raffraichissement() {
    getAllData().then((donnees) => {
        let membresObj = {};
        let filmsObj = {};
        for (let membre of donnees.membres) {
            membresObj[membre.id] = membre.nom;
        }
        for (let film of donnees.films) {
            filmsObj[film.id] = film.titre;
        }

        data.notes = donnees.notes.slice();
        data.membres = membresObj;
        if(data.user === null) {
            data.user = Object.keys(data.membres)[0];
        }
        data.films = filmsObj; //C'est important que ce soit le dernier à être modifié
        console.log(data);
    });
}

/**
 * Exemple de fonction pour obtenir toutes les informations de la base de données avec le script php/get.php
 * (ici les données sont affichées dans la console)
 */
async function getAllData()  {
    let allData = await fetch("php/get.php?q=all");
    let json = await allData.json();
    console.log(json);
    return json;
}

/**
 * Exemple de fonction pour exécuter une requête POST sur la base de données avec le script php/set.php
 * Ici la requête supprime le membre dont l'id est passé en paramètre
 * 
 * (cf. README pour les paramètres de php/set.php)
 */
function deleteMembre(id_membre) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'php/set.php', true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if (this.status === 200) {
            raffraichissement();
        }
    }
    xhr.send('action=delete&membre=' + id_membre);
}

/** Interaction avec la base de données */

function addFilm() {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'php/set.php', true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if (this.status === 200) {
            raffraichissement();
        }
    }
    xhr.send('action=add&titre=' + document.getElementById('titre-nouveau-film').value);
    document.getElementById('titre-nouveau-film').value = '';
}

function deleteFilm(id_film) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'php/set.php', true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if (this.status === 200) {
            raffraichissement();
        }
    }
    xhr.send('action=delete&film=' + id_film);
}

function addMembre() {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'php/set.php', true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if (this.status === 200) {
            raffraichissement();
        }
    }
    xhr.send('action=add&nom=' + document.getElementById('nom-nouveau-membre').value);
    document.getElementById('nom-nouveau-membre').value = '';
}

/**
 * Affichage des info
 */

function closeOverlay() {
    const overlay = document.getElementById('overlay');
    overlay.style.display = 'none';
}

function infoFilm(idFilm) {
    const overlay = document.getElementById('overlay');
    const titreOverlay = document.getElementById('overlay-title');
    const listeMembres = document.getElementById('members-list');
    const titreFilm = data.getTitreFilm(idFilm);
    let nbNotes = 0;
    titreOverlay.textContent = `Note de ${titreFilm} :`;
    listeMembres.innerHTML = '';

    data.notes.forEach(note => {
        if (note.id_film === Number(idFilm)) {
            nbNotes++;
            const elementListe = document.createElement('li');
            elementListe.textContent = `${data.getNomMembre(note.id_membre)} : ${note.valeur}`;
            listeMembres.appendChild(elementListe);
        }
    });

    if (nbNotes === 0) {
        const elementListe = document.createElement('li');
        elementListe.textContent = 'Aucune note';
        listeMembres.appendChild(elementListe);
    }


    overlay.style.display = 'flex';

}

function infoMembre(idMembre) {
    const overlay = document.getElementById('overlay');
    const titreOverlay = document.getElementById('overlay-title');
    const listeFilm = document.getElementById('members-list');
    // On récupère le nom du membre dans data grâce à l'id en utilisant la méthode getNomMembre
    const nomMembre = data.getNomMembre(idMembre);
    let nbNotes = 0;
    titreOverlay.textContent = `Notes de ${nomMembre}`;

    listeFilm.innerHTML = '';

    data.notes.forEach(note => {
        if (note.id_membre === Number(idMembre)) {
            nbNotes++;
            const elementListe = document.createElement('li');
            elementListe.textContent = `${data.getTitreFilm(note.id_film)} : ${note.valeur}`;
            listeFilm.appendChild(elementListe);
        }
    });

    if (nbNotes === 0) {
        const elementListe = document.createElement('li');
        elementListe.textContent = 'Aucune note';
        listeFilm.appendChild(elementListe);
    }

    overlay.style.display = 'flex';
}

/** Fonctions AutoCompletion (AC)*/
function afficheFilmAC(tableau) {
    videFilmAC();
    autocompletion.style.visibility = 'visible';
    for (var i = 0; i < tableau.length; i++) {
        let paragraph = document.createElement('p');
        paragraph.textContent = tableau[i];
        document.getElementById('autocompletion').insertAdjacentElement('beforeend', paragraph);
    }
}

function videFilmAC() {
    document.getElementById('autocompletion').innerHTML = '';
    autocompletion.style.visibility = 'hidden';

}

function requeteAJAXAC(stringFilm,callback,loadingStart,loadingEnd) {
    loadingStart();
    if (requete.readyState !== 0 && requete.readyState !== 4) {
        requete.abort();
    }
    let url = "https://webinfo.iutmontp.univ-montp2.fr/~etupoupet/movies.php?s=" + encodeURIComponent(stringFilm);
    requete.open("GET", url, true);
    requete.addEventListener("load", function () {
        callback(requete);
        loadingEnd();
    });
    requete.send(null);
}

function maRequeteAjaxAC(stringFilm) {
    requeteAJAXAC(stringFilm,callback,
        function() {
            loading.style.visibility = 'visible';
        },
        function() {
            loading.style.visibility = 'hidden';
        });
}


function callback(req) {
    let tableau = JSON.parse(req.responseText);
    let tableauFilm = [];
    for (var i = 0; i < 6; i++) {
        tableauFilm[i]=tableau[i]
    }
    afficheFilmAC(tableauFilm);
}

function getNbNotes(id) {
    let nbNotes = 0;
    for(let note of data.notes) {
        if (note.id_membre === Number(id)) {
            nbNotes++;
        }
    }
    return nbNotes;
}

function getMoyenneFilm(idFilm) {
    let moyenne = 0;
    let nbNotes = 0;
    for(let note of data.notes) {
        if (note.id_film === Number(idFilm)) {
            moyenne += note.valeur;
            nbNotes++;
        }
    }
    if (nbNotes === 0) {
        return 0;
    }
    return  (moyenne / nbNotes).toFixed(1);
}

/**
 * Les effets pour mettre à jour les éléments du DOM
 */
function updateSelectList() {
    let res = '';
    for(let membre in data.membres) {
        if(membre === data.user) { //Permet de garder l'utilisateur actuel sélectionné
            res += `<option selected value="${membre}">${data.membres[membre]}</option>`;
        }else{
            res += `<option value="${membre}">${data.membres[membre]}</option>`;
        }
    }
    return res;
}

function updateMemberTable() {
    let htmlRows = '';
    for (const membre of Object.keys(data.membres)) {
        let nbNotes = getNbNotes(membre);
        htmlRows += `
                    <tr data-id="${membre}" data-type="membre" data-index="${membre}">
                        <td data-onclick="data.supprMembre(${membre})"><img alt="icone de croix" src="./img/close.png"></td>
                        <td data-onclick="data.membreInfo(${membre})">${data.membres[membre]}</td>
                        <td>${nbNotes}</td>
                    </tr>`;
    }
    return htmlRows
}

function getNote(idFilm, idMembre) {
    for (let note of data.notes) {
        if (Number(note.id_film) === Number(idFilm) && Number(note.id_membre) === Number(idMembre)) {
            return note.valeur;
        }
    }
    return -1;

}

function updateFilmTable() {
    let htmlRows = '';
    for (const film of Object.keys(data.films)) {
        let moyenne = getMoyenneFilm(film);
            htmlRows += `<tr data-id="${film}" data-type="film" data-index="${film}">
                        <td data-onclick="data.supprFilm(${film})"><img alt="icone de croix" src="./img/close.png"></td>
                        <td data-onclick="data.filmInfo(${film})">${data.films[film]}</td> <!-- Titre du film -->
                        <td>${moyenne}</td> <!-- Moyenne du film -->
                        <td>
                            <select data-change="data.changeNote(${film})">
                                <option value="-1">-</option>`;
            for (let i = 0; i < 6; i++) {
                if(i === Number(getNote(film, data.user))) {
                    htmlRows += `<option selected value="${i}">${i}</option>`;
                }else {
                    htmlRows += `<option value="${i}">${i}</option>`;
                }
            }
            htmlRows += `
                            </select>
                        </td>
                    </tr>`;
    }
   return htmlRows;
}
/** Event listeners */
let overlay = document.getElementById('overlay');

//Pour fermer plus facilement l'overlay en appuyant sur la touche echap
window.addEventListener('keyup', function(event) {
    if (overlay.style.display === 'flex' && event.key === 'Escape') {
        closeOverlay();
    }
});

let input = document.getElementById('titre-nouveau-film');
let timeout = null;

//Event listener pour l'autocomplétion
input.addEventListener('input', function () {
    if (input.value.length > 2) {
        if (timeout !== null) {
            clearTimeout(timeout);
        }
        timeout = setTimeout(function () {
            maRequeteAjaxAC(input.value);
            timeout = null;
        }, 200);
    }
    else {
        videFilmAC();
    }
});

autocompletion.addEventListener('click', function (event) {
    input.value = event.target.textContent;
    videFilmAC();
});


startReactiveDom();
raffraichissement();

