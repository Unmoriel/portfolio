<h1>Projet JS - Cinéclub</h1>
<h3>Lien vers le projet : </h3> 
https://webinfo.iutmontp.univ-montp2.fr/~georgesa/ProjetCineclub/src/

<h3>Lien vers le gitlab</h3>
https://gitlabinfo.iutmontp.univ-montp2.fr/r4.01-developpementweb/etu/wolfa/ProjetCineclub
<h3>Liste des membres du groupe : </h3>
Georges Aurel - 34% <br>
Oucheman Ilias - 33% <br>
Wolf Alexandre - 33% <br>

<h3>Remarques :</h3>
Aprioris tout est en réactif et nous avons réalisé toutes les fonctionnalités bonus.



